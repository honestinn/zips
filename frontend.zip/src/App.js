// routes
import Router from './routes'
// theme
import ThemeProvider from './theme'
// components
import Settings from './components/settings'
import RtlLayout from './components/RtlLayout'
import ScrollToTop from './components/ScrollToTop'
import { ProgressBarStyle } from './components/ProgressBar'
import ThemeColorPresets from './components/ThemeColorPresets'
import MotionLazyContainer from './components/animate/MotionLazyContainer'
import { loadUser } from './actions/auth'
import { Provider } from 'react-redux'
import store from './store'
import 'react-toastify/dist/ReactToastify.css'
import './AutoLogout'
import AutoLogout from './AutoLogout'
// ----------------------------------------------------------------------

export default function App() {
	store.dispatch(loadUser())

	return (
		<Provider store={store}>			
			<ThemeProvider>
				<ThemeColorPresets>
				{localStorage.getItem('token') &&  (<AutoLogout/>)}
					<RtlLayout>
						<MotionLazyContainer>
							<ProgressBarStyle />
							{/* <Settings /> */}
							<ScrollToTop />
							<Router />
						</MotionLazyContainer>
					</RtlLayout>
				</ThemeColorPresets>
			</ThemeProvider>
		</Provider>
	)
}
