import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Button, Box } from '@mui/material';
import { WarningAmber } from '@mui/icons-material';

const AutoLogout = () => {
  const timeoutDuration = 15 * 60 * 1000; // 20 secondes + 8 secondes pour les tests
  const [isSessionExpired, setIsSessionExpired] = useState(false);
  const navigate = useNavigate();

  const updateLastActivity = () => {
    const currentTime = new Date().getTime();
    localStorage.setItem('lastActivity', currentTime.toString());
  };

  useEffect(() => {
    // Fonction qui vérifie le temps écoulé depuis la dernière activité
    const checkSessionTimeout = () => {
      const lastActivity = parseInt(localStorage.getItem('lastActivity'), 10);
      const now = new Date().getTime();
      const timeElapsed = now - lastActivity;

      if (timeElapsed >= timeoutDuration) {
        setIsSessionExpired(true); // Affiche la boîte de dialogue si la session est expirée
      }
    };

    // Mettre à jour lastActivity à chaque mouvement de la souris ou touche du clavier
    const handleUserActivity = () => {
      updateLastActivity();
    };

    // Ajouter les écouteurs d'événements
    window.addEventListener('mousemove', handleUserActivity);
    window.addEventListener('keydown', handleUserActivity);

    // Démarrer un intervalle pour vérifier régulièrement si la session est expirée
    const intervalId = setInterval(checkSessionTimeout, 1000);

    // Nettoyer les écouteurs et l'intervalle lorsque le composant est démonté
    return () => {
      window.removeEventListener('mousemove', handleUserActivity);
      window.removeEventListener('keydown', handleUserActivity);
      clearInterval(intervalId);
    };
  }, [timeoutDuration]);

  const handleGoToLogin = () => {
    setIsSessionExpired(false);

    setTimeout(() => {
      localStorage.removeItem('token');
      localStorage.removeItem('refresh');
      localStorage.removeItem('user');
      window.location.replace('/login');
    }, 200);
  };

  return (
    <>
      <Dialog
        open={isSessionExpired}
        onClose={handleGoToLogin}
        maxWidth="xs"
        fullWidth
        sx={{
          borderRadius: '10px',
          backdropFilter: 'blur(5px)',
          backgroundColor: 'rgba(0, 0, 0, 0.6)',
        }}
      >
        <Box display="flex" flexDirection="column" alignItems="center" justifyContent="center" pt={3} pb={2}>
          <WarningAmber color="warning" sx={{ fontSize: 60, animation: 'shake 1s ease infinite' }} />
          <DialogTitle sx={{ textAlign: 'center', fontWeight: 'bold', fontSize: '1.5rem', color: 'text.primary', mt: 2 }}>
            Session Expirée
          </DialogTitle>
          <DialogContent sx={{ px: 4, pb: 2, textAlign: 'center' }}>
            <DialogContentText sx={{ color: 'text.secondary', fontSize: '1.1rem' }}>
              Votre session a expiré. Veuillez vous reconnecter pour continuer.
            </DialogContentText>
          </DialogContent>
          <DialogActions sx={{ justifyContent: 'center', pb: 3 }}>
            <Button
              onClick={handleGoToLogin}
              color="primary"
              variant="contained"
              sx={{
                fontSize: '1rem',
                fontWeight: 'bold',
                textTransform: 'none',
                padding: '10px 20px',
                borderRadius: '30px',
              }}
            >
              Reconnexion
            </Button>
          </DialogActions>
        </Box>
      </Dialog>
    </>
  );
};

export default AutoLogout;
