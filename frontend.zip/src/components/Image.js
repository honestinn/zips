import React, { useState } from 'react'
import { Box, Skeleton } from '@mui/material'
import { FILES_URL } from 'src/Api'

const Image = ({ src, alt, width, height, ...props }) => {
	const [imageLoaded, setImageLoaded] = useState(false)

	const handleImageLoad = () => {
		setImageLoaded(true)
	}

	return (
		<>
			{!imageLoaded && (
				<Skeleton
					variant="rectangular"
					width="100%"
					sx={{
						minHeight: '100%',
						borderRadius: '5px',
					}}
				/>
			)}
			<img
				src={src}
				alt={alt}
				onLoad={handleImageLoad}
				style={{
					display: imageLoaded ? 'block' : 'none',
					maxWidth: '100%',
					maxHeight: '100%',
					borderRadius: '5px',
				}}
			/>
		</>
	)
}

export default Image
