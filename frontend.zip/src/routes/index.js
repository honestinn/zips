import { Suspense, lazy } from 'react'
import { Navigate, useRoutes, useLocation, Outlet } from 'react-router-dom'
// layouts
import DashboardLayout from '../layouts/dashboard'
import LogoOnlyLayout from '../layouts/LogoOnlyLayout'
// components
import LoadingScreen from '../components/LoadingScreen'
import { useSelector } from 'react-redux'

import HomeLayout from 'src/pages/main/HomeLayout'

import VerifyAccount from 'src/pages/dashboard/accounts/VerifyAccount'

// ----------------------------------------------------------------------

function Auth({ children, ...rest }) {
	const auth = useSelector(state => state.auth)
	if (auth.isAuthenticated) {
		return children
	} else return <Navigate to="/" replace="true" />
}
// function Active({ children, ...rest }) {
// 	const auth = useSelector(state => state.auth)

// 	if (auth.user && auth.user.active) {
// 		return children
// 	} else return <Navigate to="/NotActive" replace="true" />
// }
// function GuardPro({ children, ...rest }) {
// 	const auth = useSelector(state => state.auth)

// 	if (auth.user && auth.user.role == 1) {
// 		return children
// 	} else return <Navigate to="/404" replace="true" />
// }
// function GuardAdmin({ children, ...rest }) {
// 	const auth = useSelector(state => state.auth)

// 	if (auth.user && auth.user.role == 0) {
// 		return children
// 	} else return <Navigate to="/404" replace="true" />
// }

const Loadable = Component => props => {
	// eslint-disable-next-line react-hooks/rules-of-hooks
	const { pathname } = useLocation()

	return (
		<Suspense fallback={<LoadingScreen isDashboard={pathname.includes('/dashboard')} />}>
			<Component {...props} />
		</Suspense>
	)
}
function Home() {
	const auth = useSelector(state => state.auth)
	if (auth.user.role === -1) return <HomeSuperAdmin />
	if (auth.user.role === 0) return <HomeAdmin />
	if (auth.user.role === 1) return <HomePro />
	if (auth.user.role === 2) return <HomeExtra />
}
// function FirstPage() {
// 	const auth = useSelector(state => state.auth)
// 	if (auth.user.role == 1) return 'dashboard/all_missions'
// 	else
// 	 return 'dashboard/all_missions''
// }
function Account() {
	const auth = useSelector(state => state.auth)
	if (auth.user.role === 2) return <AccountExtra />
	else return <Home />
}

export default function Router() {
	const auth = useSelector(state => state.auth)
	const path = auth.user && auth.user.role === 1 ? '/dashboard/all_missions' : '/dashboard/home'
	return useRoutes([
		{
			path: '/notActive',
			element: <NotActive />,
		},
		{
			path: '/dashboard',
			element: (
				<Auth>
					<VerifyAccount>
						<DashboardLayout />
					</VerifyAccount>
				</Auth>
			),
			children: [
				{ element: <Navigate to={path} replace />, index: true },
				{ path: 'home', element: <Home /> },
				{ path: 'clients', element: <Clients /> },
				{ path: 'clients/:id', element: <ClientsInfo /> },
				{ path: 'candidats/:id', element: <CondidatsInfo /> },
				{ path: 'admins', element: <Admins /> },
				{ path: 'cancel_requests', element: <CancelRequests /> },
				{ path: 'cancel_requests_pro', element: <CancelRequestsPro /> },
				{ path: 'candidats', element: <Candidats /> },
				{ path: 'applications', element: <ApplicationsPro /> },
				{ path: 'all_applications', element: <ApplicationsAdmin /> },
				{ path: 'my_applications', element: <ApplicationsExtra /> },
				{ path: 'Settings', element: <Settings /> },
				{ path: 'profile', element: <Profile /> },
				{ path: 'profile_pro', element: <ProfilePro /> },
				// { path: 'payment', element: <Payment /> },
				{ path: 'account', element: <Account /> },
				{ path: 'all_missions', element: <MissionsPro /> },
				{ path: 'all_missions/add', element: <AddMission /> },
				{ path: 'all_missions/edit/:id', element: <EditMission /> },
				{ path: 'admin_missions', element: <MissionsAdmin /> },
				{ path: 'all_invoices', element: <InvoicesPro /> },
				{ path: 'admin_inovices', element: <InvoicesAdmin /> },
				{ path: 'missions', element: <MissionsExtra /> },
				{ path: 'invoices', element: <InvoicesExtra /> },
			],
		},
		{
			path: '/',
			element: (
				<HomeLayout>
					<Suspense fallback={<LoadingScreen />}>
						<Outlet />
					</Suspense>
				</HomeLayout>
			),
			children: [
				{ path: '/', element: <Main /> },
				{ path: 'login', element: <Login /> },
				{ path: 'register', element: <Register /> },

				{ path: 'verify', element: <VerifyEmail /> },
				{ path: 'reset_password', element: <ResetPassword /> },
				{ path: 'register/pro', element: <RegisterOne /> },
				{ path: 'register/ext', element: <RegisterTwo /> },
			],
		},
		{
			path: '*',
			element: <LogoOnlyLayout />,
			children: [
				{ path: '404', element: <NotFound /> },
				{ path: '*', element: <Navigate to="/404" replace /> },
			],
		},
		{ path: '*', element: <Navigate to="/404" replace /> },
	])
}

// Dashboard

const Login = Loadable(lazy(() => import('../pages/main/accounts/Login')))

const HomeSuperAdmin = Loadable(lazy(() => import('../pages/dashboard/home/HomeSuperAdmin')))
const HomeAdmin = Loadable(lazy(() => import('../pages/dashboard/home/HomeAdmin')))
const HomePro = Loadable(lazy(() => import('../pages/dashboard/home/HomePro')))
const HomeExtra = Loadable(lazy(() => import('../pages/dashboard/home/HomeExtra')))
const Main = Loadable(lazy(() => import('../pages/main/Main')))

const Register = Loadable(lazy(() => import('../pages/main/accounts/Register')))
const RegisterOne = Loadable(lazy(() => import('../pages/main/accounts/pro/Register')))
const RegisterTwo = Loadable(lazy(() => import('../pages/main/accounts/extra/Register')))

const VerifyEmail = Loadable(lazy(() => import('../pages/main/accounts/VerifyEmail')))
const ResetPassword = Loadable(lazy(() => import('../pages/main/accounts/ResetPassword')))
const NotFound = Loadable(lazy(() => import('../pages/Page404')))
const NotActive = Loadable(lazy(() => import('../pages/NotActive')))

const Admins = Loadable(lazy(() => import('../pages/dashboard/admin/admins/Admins')))
const Clients = Loadable(lazy(() => import('../pages/dashboard/admin/clients/Clients')))
const ClientsInfo = Loadable(lazy(() => import('../pages/dashboard/admin/clients/ClientInfo')))
const CondidatsInfo = Loadable(
	lazy(() => import('../pages/dashboard/admin/condidats/CondidatsInfo'))
)
const Candidats = Loadable(lazy(() => import('../pages/dashboard/admin/condidats/Condidats')))
const CancelRequests = Loadable(
	lazy(() => import('../pages/dashboard/admin/cancel_requests/CancelRequests'))
)
const CancelRequestsPro = Loadable(
	lazy(() => import('../pages/dashboard/pro/cancel_requests/CancelRequests'))
)
const ApplicationsPro = Loadable(
	lazy(() => import('../pages/dashboard/pro/applications/Applications'))
)
const ApplicationsAdmin = Loadable(
	lazy(() => import('../pages/dashboard/admin/applications/Applications'))
)
const ApplicationsExtra = Loadable(
	lazy(() => import('../pages/dashboard/extra/applications/Applications'))
)
const Settings = Loadable(lazy(() => import('../pages/dashboard/settings/Settings')))

const AccountExtra = Loadable(lazy(() => import('../pages/dashboard/accounts/AccountExtra')))
const Profile = Loadable(lazy(() => import('../pages/dashboard/profiles/Profile')))
const ProfilePro = Loadable(lazy(() => import('../pages/dashboard/profiles/ProfilePro')))
// const Payment = Loadable(lazy(() => import('../pages/dashboard/payment/Payment')))
const MissionsPro = Loadable(lazy(() => import('../pages/dashboard/pro/missions/Missions')))
const AddMission = Loadable(lazy(() => import('../pages/dashboard/pro/missions/AddMission')))
const EditMission = Loadable(lazy(() => import('../pages/dashboard/pro/missions/EditMission')))
const InvoicesPro = Loadable(lazy(() => import('../pages/dashboard/pro/invoices/Invoices')))
const InvoicesAdmin = Loadable(lazy(() => import('../pages/dashboard/admin/invoices/Invoices')))
const InvoicesExtra = Loadable(lazy(() => import('../pages/dashboard/extra/invoices/Invoices')))
const MissionsExtra = Loadable(lazy(() => import('../pages/dashboard/extra/missions/Missions')))
const MissionsAdmin = Loadable(lazy(() => import('../pages/dashboard/admin/missions/Missions')))
