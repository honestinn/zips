import { m } from 'framer-motion'
import { Navigate, Link as RouterLink } from 'react-router-dom'
// @mui
import { styled } from '@mui/material/styles'
import { Box, Button, Typography, Container } from '@mui/material'
// components
import Page from '../components/Page'
import { MotionContainer, varBounce } from '../components/animate'

import { useDispatch, useSelector } from 'react-redux'
import { useState } from 'react'
import axios from 'axios'
import { useEffect } from 'react'
import { logout } from 'src/actions/auth'

// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
	display: 'flex',
	minHeight: '100%',
	alignItems: 'center',
	background: 'black',

	paddingTop: theme.spacing(15),
	paddingBottom: theme.spacing(10),
}))

// ----------------------------------------------------------------------

export default function NotActive() {
	const auth = useSelector(state => state.auth)
	const dispatch = useDispatch()
	const [active, setActive] = useState(false)
	const check = () => {
		axios
			.get('/api/users/check_status/' + auth?.user.id)
			.then(res => {
				setActive(res.data)
				if (!!res.data) dispatch(logout())
			})
			.catch(err => {})
	}
	useEffect(() => {
		if (auth.user) check()
	}, [])
	if (active) return <Navigate to="/login" replace="true" />
	else
		return (
			<Page title="Info" sx={{ height: 1 }}>
				<RootStyle>
					<Container component={MotionContainer}>
						<Box
							sx={{
								maxWidth: 480,
								margin: 'auto',
								textAlign: 'center',
								border: '1px solid #ccc',
								background: '#D69F13',
								p: 2,
							}}
						>
							<m.div variants={varBounce().in}>
								<Typography variant="h3" paragraph>
									Bonjour , {auth.user.name}
								</Typography>
							</m.div>
							<Typography>
								Nous vous remercions d'avoir créé un compte. Votre compte est
								actuellement en attente de confirmation de l'administrateur. Notre
								équipe vous contactera par téléphone pour finaliser le processus
								d'approbation de votre compte.
							</Typography>

							<m.div variants={varBounce().in}>
								<Box
									sx={{
										display: 'flex',
										justifyContent: 'center',
										width: '100%',
										m: 2,
										height: 300,
									}}
								>
									<img
										src="/statics/undraw_personal_email_re_4lx7.svg"
										style={{ maxHeight: '100%', maxWidth: '100%' }}
									/>
								</Box>
							</m.div>

							<Button to="/" size="large" variant="contained" component={RouterLink}>
								Accéder à la page d'accueil
							</Button>
						</Box>
					</Container>
				</RootStyle>
			</Page>
		)
}
