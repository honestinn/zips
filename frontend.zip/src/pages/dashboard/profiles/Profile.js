import { Close, Edit, Email, LocationCity, Phone, Upload, Save } from '@mui/icons-material'
import {
	Button,
	Avatar,
	Typography,
	Tooltip,
	Stack,
	TextField,
	Paper,
	Grid,
	Container,
	IconButton,
	Divider,
	Modal,
	CircularProgress
} from '@mui/material'
import { Box } from '@mui/system'
import * as Yup from 'yup'

import React, { useEffect, useState, useRef } from 'react'
import ReactImageUploading from 'react-images-uploading'
import { useFormik } from 'formik'
import api, { FILES_URL } from 'src/Api'
import { useSelector } from 'react-redux'
import { LoadingButton } from '@mui/lab'
import { toast, ToastContainer } from 'react-toastify'
import AddExperience from './AddExperience'
import AddRefrence from './AddRefrence'
import AddLanguage from './AddLanguage'
import AddDiplome from './AddDiplome'
import AddSoftwares from './AddSoftwares'
import Page from 'src/components/Page'
import moment from 'moment'
import Image from 'src/components/Image'
// import Image from 'src/components/Image'
import * as faceapi from 'face-api.js';
import Webcam from 'react-webcam';
import CameraAltIcon from '@mui/icons-material/CameraAlt';


import Step1 from '../accounts/client_steps/Step1'

export default function Profile() {
	const [loading, setLoading] = useState(false)
	const auth = useSelector(state => state.auth)
	const [user, setUser] = useState(null)
	const [cnxErr, setCnxErr] = useState(null)
	// const [title, setTitle] = useState('')
	const [openExp, setOpenAddExp] = useState(false)
	const [openRef, setOpenAddRef] = useState(false)
	const [openLang, setOpenAddLang] = useState(false)
	const [openDiplome, setOpenAddDiplome] = useState(false)
	const [openSoftware, setOpenAddSoftware] = useState(false)
	const [langs, setLangs] = useState([])
	const [levels, setLevels] = useState([])
	const [picture, setPicture] = useState([])
	const [competences, setCompetences] = useState([])
	const [diplomes, setDiplomes] = useState([])
	const [softwares, setSoftwares] = useState([])
	const [submitingPicture, setSubmittingPicture] = useState(false)

    const webcamRef = useRef(null);
    const [faceDetected, setFaceDetected] = useState(false);
    const [open, setOpen] = useState(false);



	const submitPicture = () => {
		// if (!faceDetected) {
        //     showError("Veuillez télécharger une photo conforme.");
        //     return;
        // }
		const config = {
			headers: {
				'content-type': 'multipart/form-data',
			},
		}
		let body = new FormData()

		if (picture.length > 0) {
			body.append('picture', picture[0]?.file)
		}
		// body.append('title', title)

		setSubmittingPicture(true)
		api.post('/users/upload_avatar/' + auth?.user.id, body, config)
			.then(res => {
				setUser(res.data)
				setSubmittingPicture(false)
				toast.success('Modification réussie. Vos changements ont été enregistrés avec succès.', {
					position: 'bottom-center',
					autoClose: 3000,
					hideProgressBar: false,
					closeOnClick: true,
					pauseOnHover: true,
					draggable: true,
					progress: undefined,
				})
			})
			.catch(err => {
				setSubmittingPicture(false)
				toast.error('Erreur dans react', {
					position: 'bottom-center',
					autoClose: 3000,
					hideProgressBar: false,
					closeOnClick: true,
					pauseOnHover: true,
					draggable: true,
					progress: undefined,
				})
			})
	}
    // Load face-api.js models
    useEffect(() => {
        const loadModels = async () => {
            const MODEL_URL = '/models'; // Adjust the path to your models directory
            await Promise.all([
                faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL),
            ]);
        };

        loadModels();
    }, []);

	const capture = async () => {
		setLoading(true);
		const imageSrc = webcamRef.current.getScreenshot();
		if (imageSrc) {
			const blob = await fetch(imageSrc).then(res => res.blob()); // Convert the data URL to a Blob
			const imageFile = new File([blob], 'capturedImage.jpg', { type: 'image/jpeg' });
	
			const imageList = [{ data_url: imageSrc, file: imageFile }];
			await onPictureChange(imageList); // Reuse onPictureChange for the captured image
			setOpen(false); // Close modal after capturing the photo
		}
		setLoading(false);
	};

    const onPictureChange = async (imageList, addUpdateIndex) => {
        // Check if a face is detected in the uploaded image
        if (imageList.length > 0) {
            // const img = await faceapi.fetchImage(imageList[0].data_url);
            // const detections = await faceapi.detectAllFaces(img);

            // if (detections.length === 0) {
            //     showError("Aucun visage détecté dans l'image téléchargée.");
            // } else if (detections.length > 1) {
            //     showError("Plusieurs visages détectés dans l'image téléchargée.");
            // } else {
                 setPicture(imageList);
            //     showSuccess("L'image est conforme et a été validée avec succès.");
            //     setFaceDetected(detections.length === 1); // Set face detection state
            // }
        }
    };
	const getSoftwaresList = () => {
		api.get('/users/get_softwares_list')
			.then(res => {
				setSoftwares(res.data)
			})
			.catch(err => {})
	}

	const getDiplomesList = () => {
		api.get('/users/get_diplomes_list')
			.then(res => {
				setDiplomes(res.data)
			})
			.catch(err => {})
	}

	const getLanguagesList = () => {
		api.get('/users/get_lang_list')
			.then(res => {
				setLangs(res.data.langs)
				setLevels(res.data.levels)
			})
			.catch(err => {})
	}

	useEffect(() => {
		getUser()
		getDiplomesList()
		getLanguagesList()
		getCompetencesList()
		getSoftwaresList()
	}, [])
    const showError = (msg) => {
        toast.error(msg? msg : 'Erreur', {
            position: 'bottom-center',
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    };
	const showSuccess = (msg) => {
		toast.success(msg ? msg : 'Modification réussie.', {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const getCompetencesList = () => {
		api.get('/users/get_competences_list')
			.then(res => {
				setCompetences(res.data)
			})
			.catch(err => {})
	}
	const GetCV = () => { 
		setLoading(true);
		api.get('/users/download_cv/' + auth?.user.id, { responseType: 'arraybuffer' }) // Ajoutez responseType
		  .then(res => {
			setLoading(false);
			const fileURL = window.URL.createObjectURL(new Blob([res.data], { type: 'application/pdf' }));
			// Ouvrir le PDF dans un nouvel onglet
			const newTab = window.open(fileURL, '_blank');
			if (newTab) {
			  newTab.focus();
			} else {
			  console.error('Impossible d\'ouvrir le PDF dans un nouvel onglet');
			}
		  })
		  .catch(err => {
			console.log(err);
			setCnxErr(true);
			setLoading(false);
		  });
	  };
	const getUser = () => {
		// Headers
		setLoading(true)
		api.get('/users/get')
			.then(res => {
				setUser(res.data)
				// setTitle(res.data.title)
				setLoading(false)
			})
			.catch(err => {
				setCnxErr(true)
				setLoading(false)
			})
	}
	const deleteExperience = id => {
		// Headers

		api.post('/users/delete_experience/' + auth?.user.id, { id })
			.then(res => {
				setUser(res.data)
			})
			.catch(err => {})
	}
	const deleteDiplome = id => {
		// Headers

		api.post('/users/delete_diplome/' + auth?.user.id, { id })
			.then(res => {
				setUser(res.data)
			})
			.catch(err => {})
	}
	const deleteSoftware = id => {
		// Headers

		api.post('/users/delete_software/' + auth?.user.id, { id })
			.then(res => {
				setUser(res.data)
			})
			.catch(err => {})
	}
	const selectCompetence = id => {
		// Headers

		api.post('/users/select_competence/' + auth?.user.id, { id })
			.then(res => {
				setUser(res.data)
			})
			.catch(err => {})
	}
	const deleteReference = id => {
		// Headers

		api.post('/users/delete_reference/' + auth?.user.id, { id })
			.then(res => {
				setUser(res.data)
			})
			.catch(err => {})
	}
	const deleteLanguage = id => {
		// Headers

		api.post('/users/delete_language/' + auth?.user.id, { id })
			.then(res => {
				setUser(res.data)
			})
			.catch(err => {})
	}

	if (cnxErr)
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '60vh',
					border: '1px solid #ccc',
					p: 2,
				}}
			>
				<Typography color={'error'} variant="h6">
				Problème de connexion ...
				</Typography>
			</Box>
		)

	if (loading)
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '60vh',
					border: '1px solid #ccc',
					p: 2,
				}}
			>
				<Typography variant="h6"> Chargement ...</Typography>
			</Box>
		)
	return (
		<>
			<Page title="Profil">
				<Container maxWidth="md">
					<Stack spacing={2}>
						<Paper sx={{ p: 1 }} variant="outlined">
							<Grid container spacing={1}>
								<Grid item xs={12} md={6} lg={4}>
									<ReactImageUploading
										multiple
										value={picture}
										onChange={onPictureChange}
										maxNumber={1}
										dataURLKey="data_url"
										acceptType={['jpg', 'png', 'jpeg']}
									>
										{({
											imageList,
											onImageUpload,
											onImageRemoveAll,
											onImageUpdate,
											onImageRemove,
											isDragging,
											dragProps,
										}) => (
											<>
											<Stack spacing={1} sx={{ display: 'flex', alignItems: 'center' }}>
												<ReactImageUploading
													multiple
													value={picture}
													onChange={onPictureChange}
													maxNumber={1}
													dataURLKey="data_url"
													acceptType={['jpg', 'png', 'jpeg']}
												>
													{({
														imageList,
														onImageUpload,
														onImageUpdate,
													}) => (
														<>
															<Box
																sx={{
																	display: 'flex',
																	justifyContent: 'center',
																	alignItems: 'center',
																	width: 250,
																	height: 250,
																	p: 1,
																}}
															>
																{imageList.length === 0 && (
																	<Image
																		src={user?.avatar.length > 0 ? FILES_URL + user.avatar : '/statics/image-placeholder.png'}
																	/>
																)}
																{imageList.map((image, index) => (
																	<Image key={index} src={image.data_url} />
																))}
															</Box>
															<Box>
																<Tooltip title="Choisir une photo">
																	<Button
																		variant="outlined"
																		onClick={
																			imageList.length > 0
																				? () => onImageUpdate(0)
																				: onImageUpload
																		}
																		startIcon={<Upload />}
																	>
																		Choisir une image
																	</Button>
																</Tooltip>
																<Button variant="outlined" sx={{ ml: 2 }} onClick={() => setOpen(true)}>
																	<CameraAltIcon />
																</Button>
															</Box>
														    <Box>
															<Button
																		variant="outlined"
																		onClick={
																			
																			() => GetCV()
																		}
																		
																	>
																		Générer mon CV
																	</Button>
														    </Box>
														</>
													)}
												</ReactImageUploading>
												<Typography gutterBottom variant="h5">
													{/* {user.name} */}
												</Typography>
												<Typography color="text.secondary" variant="body2">
													{/* {user.email} */}
												</Typography>
												<Typography color="text.secondary" variant="body2">
													{/* {user.phone} */}
												</Typography>
											</Stack>
								
											{/* Modal for Webcam */}
											<Modal open={open} onClose={() => setOpen(false)}>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
														alignItems: 'center',
														height: '100vh',
														backgroundColor: 'rgba(0, 0, 0, 0.8)',
													}}
												>
													<IconButton
														sx={{
															position: 'absolute',
															top: 16,
															right: 16,
															color: 'white', // Close icon color
														}}
														onClick={() => setOpen(false)}
													>
														<Close />
													</IconButton>
													<Box
														sx={{
															display: 'flex',
															flexDirection: 'column',
															justifyContent: 'center',
															alignItems: 'center',
															height: '100vh',
														}}
													>
														<Webcam
															audio={false}
															ref={webcamRef}
															screenshotFormat="image/jpeg"
															style={{
																width: '100%',
																height: 'auto',
																maxWidth: '70%',
															}} 
														/>
														{/* Loading spinner */}
														{loading ? (
															<Stack direction="row" spacing={2} alignItems="center" sx={{ mt: 2 }}>
																<CircularProgress size={24} color="inherit" />
																<Typography color="white">Analyse de la photo...</Typography>
															</Stack>
														) : (
															<Button variant="contained" onClick={capture} sx={{ marginLeft: 2 }}>
																Capturer
															</Button>
														)}
													</Box>
												</Box>
											</Modal>
								
											<ToastContainer
												autoClose={3000}
												hideProgressBar={false}
												newestOnTop={false}
												closeOnClick
												rtl={false}
												pauseOnFocusLoss
												draggable
												pauseOnHover
											/>
										</>
										)}
									</ReactImageUploading>
								</Grid>
								<Grid item xs={12} md={6} lg={8}>
									<Stack spacing={1}>
										<Typography gutterBottom variant="h6">
											{user?.name}
										</Typography>
										<Stack direction="row" spacing={1} alignItems={'center'}>
											<Email sx={{ fontSize: 16 }} />
											<Typography color="text.secondary" variant="subtitle2">
												{user?.email}
											</Typography>
										</Stack>
										<Stack direction="row" spacing={1} alignItems={'center'}>
											<Phone sx={{ fontSize: 16 }} />
											<Typography color="text.secondary" variant="subtitle2">
												{user?.phone}
											</Typography>
										</Stack>
										<Stack direction="row" spacing={1} alignItems={'center'}>
											<LocationCity sx={{ fontSize: 16 }} />
											<Typography color="text.secondary" variant="subtitle2">
												{user?.address + ', ' + user?.postal_code + ' ' + user?.city}
											</Typography>
										</Stack>
										<Stack direction="row" spacing={1} alignItems={'center'}>
										{user?.address2 && (
												<Typography color="text.secondary" variant="subtitle2">
													{user?.address2}
												</Typography>
											)}
										</Stack>

										{/* <Stack spacing={1}>
											<TextField
												size="small"
												fullWidth
												autoComplete="title"
												type="text"
												name="title"
												label="Sous titre"
												onChange={e => setTitle(e.target.value)}
												value={title}
											/>
										</Stack> */}
									</Stack>
								</Grid>
								<Box
									sx={{
										display: 'flex',
										justifyContent: 'flex-end',
										width: '100%',
									}}
								>
									<LoadingButton
										sx={{ minWidth: 220 }}
										loading={submitingPicture}
										variant="contained"
										onClick={() => submitPicture()}
									>
										Sauvegarder
									</LoadingButton>
								</Box>
							</Grid>
						</Paper>
						<Paper sx={{ p: 1 }} variant="outlined">
							<Stack spacing={1}>
								<Typography variant="h6">Expérience </Typography>
								<Typography variant="subtitle2">Métier(s) </Typography>
								{user?.experiences.length == 0 && (
									<Typography color={'error'} variant="body2">
										Veuillez ajouter des métiers
									</Typography>
								)}
								<Stack direction={'row'} spacing={1} flexWrap="wrap">
									{user?.experiences?.length > 0 &&
										user?.experiences?.map(item => (
											<Paper
												variant="outlined"
												sx={{ background: '#919eab3d' }}
											>
												<Stack
													direction={'row'}
													sx={{ ml: 1, p: 1 }}
													spacing={1}
												>
													<Box>
														<Typography variant="body2">
															{item.job?.name}
														</Typography>
														
														<Typography variant="body2">
															{item.company}
														</Typography>
														<Typography
															variant="body2"
															color="text.secondary"
														>
															{moment(item.start_date).format(
																'DD-MM-YYYY'
															) +
																'/' +
																moment(item.end_date).format(
																	'DD-MM-YYYY'
																)}
														</Typography>
													</Box>
													<IconButton
														onClick={() => deleteExperience(item._id)}
													>
														<Close />
													</IconButton>
												</Stack>
											</Paper>
										))}
								</Stack>
								<Box sx={{ display: 'flex', justifyContent: 'end' }}>
									<Button
										onClick={() => setOpenAddExp(true)}
										sx={{ minWidth: 220, textTransform: 'none' }}
										variant="contained"
									>
										Ajouter un métier
									</Button>
								</Box>
								<Divider />
								<Typography variant="subtitle2">Références </Typography>
								{user?.references?.length == 0 && (
									<Typography color={'error'} variant="body2">
										Veuillez ajouter des Références
									</Typography>
								)}
								<Stack direction={'row'} spacing={1} flexWrap="wrap">
									{user?.references?.length > 0 &&
										user?.references?.map(item => (
											<Paper
												variant="outlined"
												sx={{ background: '#919eab3d' }}
											>
												<Stack
													direction={'row'}
													sx={{ ml: 1, p: 1 }}
													spacing={1}
													alignItems={'center'}
												>
													<Typography variant="body2">
														{item.name}
													</Typography>

													<IconButton
														onClick={() => deleteReference(item._id)}
													>
														<Close />
													</IconButton>
												</Stack>
											</Paper>
										))}
								</Stack>
								<Box sx={{ display: 'flex', justifyContent: 'end' }}>
									<Button
										onClick={() => setOpenAddRef(true)}
										sx={{ minWidth: 220, textTransform: 'none' }}
										variant="contained"
									>
										Ajouter une référence
									</Button>
								</Box>
							</Stack>
						</Paper>
						<Paper sx={{ p: 1 }} variant="outlined">
							<Stack spacing={1}>
								<Typography variant="h6">Formation </Typography>

								<Typography variant="subtitle1">Langue(s)</Typography>
								{user?.languages?.length == 0 && (
									<Typography color={'error'} variant="body2">
										Veuillez ajouter une Langue
									</Typography>
								)}
								<Stack direction={'row'} spacing={1} flexWrap="wrap">
									{user?.languages?.length > 0 &&
										user?.languages?.map(item => (
											<Paper
												variant="outlined"
												sx={{ background: '#919eab3d' }}
											>
												<Stack
													direction={'row'}
													sx={{ ml: 1, p: 1 }}
													spacing={1}
												>
													<Box>
														<Typography variant="body2">
															{
																langs.find(e => e.id == item.lang)
																	?.title
															}
														</Typography>
														<Typography
															variant="body2"
															color="text.secondary"
														>
															{
																levels.find(e => e.id == item.level)
																	?.level
															}
														</Typography>
													</Box>
													<IconButton
														onClick={() => deleteLanguage(item.lang)}
													>
														<Close />
													</IconButton>
												</Stack>
											</Paper>
										))}
								</Stack>
								<Box sx={{ display: 'flex', justifyContent: 'end' }}>
									<Button
										onClick={() => setOpenAddLang(true)}
										sx={{ minWidth: 220, textTransform: 'none' }}
										variant="contained"
									>
										Ajouter une langue
									</Button>
								</Box>
								<Divider />
								<Typography variant="subtitle1">Diplôme(s)</Typography>
								{user?.diplomes?.length == 0 && (
									<Typography color={'error'} variant="body2">
										Veuillez ajouter un Diplôme
									</Typography>
								)}
								<Stack direction={'row'} spacing={1} flexWrap="wrap">
									{user?.diplomes?.length > 0 &&
										user?.diplomes?.map(item => (
											<Paper
												variant="outlined"
												sx={{ background: '#919eab3d' }}
											>
												<Stack
													direction={'row'}
													sx={{ ml: 1, p: 1 }}
													spacing={1}
													alignItems={'center'}
												>
													<Typography variant="body2">
														{diplomes.find(e => e.id == item)?.title}
													</Typography>

													<IconButton onClick={() => deleteDiplome(item)}>
														<Close />
													</IconButton>
												</Stack>
											</Paper>
										))}
								</Stack>
								<Box sx={{ display: 'flex', justifyContent: 'end' }}>
									<Button
										onClick={() => setOpenAddDiplome(true)}
										sx={{ minWidth: 220, textTransform: 'none' }}
										variant="contained"
									>
										Ajouter un diplôme
									</Button>
								</Box>
								<Divider />
								<Typography variant="subtitle1">Logiciel(s)</Typography>
								{user?.softwares?.length == 0 && (
									<Typography color={'error'} variant="body2">
										Veuillez ajouter un Logiciel
									</Typography>
								)}
								<Stack direction={'row'} spacing={1} flexWrap="wrap">
									{user?.softwares?.length > 0 &&
										user?.softwares?.map(item => (
											<Paper
												variant="outlined"
												sx={{ background: '#919eab3d' }}
											>
												<Stack
													direction={'row'}
													sx={{ ml: 1, p: 1 }}
													spacing={1}
													alignItems={'center'}
												>
													<Typography variant="body2">
														{softwares.find(e => e.id == item)?.name}
													</Typography>

													<IconButton
														onClick={() => deleteSoftware(item)}
													>
														<Close />
													</IconButton>
												</Stack>
											</Paper>
										))}
								</Stack>
								<Box sx={{ display: 'flex', justifyContent: 'end' }}>
									<Button
										onClick={() => setOpenAddSoftware(true)}
										sx={{ minWidth: 220, textTransform: 'none' }}
										variant="contained"
									>
										Ajouter un logiciel
									</Button>
								</Box>
							</Stack>
						</Paper>
						<Paper sx={{ p: 1 }} variant="outlined">
							<Stack>
								<Typography variant="h6">Mes qualités</Typography>

								<Stack direction={'row'} spacing={1} flexWrap="wrap">
									{competences.length > 0 &&
										competences.map(item => (
											<Stack
												direction={'row'}
												sx={{ ml: 1, p: 1 }}
												spacing={1}
												alignItems={'center'}
											>
												<Button
													onClick={() => selectCompetence(item.id)}
													endIcon={
														user?.competences.includes(item.id) ? (
															<Close />
														) : null
													}
													variant={
														user?.competences.includes(item.id)
															? 'contained'
															: 'outlined'
													}
												>
													{item.name}
												</Button>
											</Stack>
										))}
								</Stack>
							</Stack>
						</Paper>
					</Stack>
				</Container>
				{openExp && (
					<AddExperience
						openAdd={openExp}
						handleCloseAdd={() => setOpenAddExp(false)}
						setUser={setUser}
						showSuccess={showSuccess}
						showError={showError}
						user={user}
					/>
				)}
				{openRef && (
					<AddRefrence
						openAdd={openRef}
						handleCloseAdd={() => setOpenAddRef(false)}
						setUser={setUser}
						showSuccess={showSuccess}
						showError={showError}
						user={user}
					/>
				)}
				{openLang && (
					<AddLanguage
						openAdd={openLang}
						handleCloseAdd={() => setOpenAddLang(false)}
						setUser={setUser}
						showSuccess={showSuccess}
						showError={showError}
						user={user}
						langs={langs}
						levels={levels}
					/>
				)}
				{openDiplome && (
					<AddDiplome
						openAdd={openDiplome}
						handleCloseAdd={() => setOpenAddDiplome(false)}
						setUser={setUser}
						showSuccess={showSuccess}
						showError={showError}
						user={user}
						diplomes={diplomes}
					/>
				)}
				{openSoftware && (
					<AddSoftwares
						openAdd={openSoftware}
						handleCloseAdd={() => setOpenAddSoftware(false)}
						setUser={setUser}
						showSuccess={showSuccess}
						showError={showError}
						user={user}
						softwares={softwares}
					/>
				)}
				<ToastContainer
					position="top-center"
					autoClose={3000}
					hideProgressBar={false}
					newestOnTop={false}
					closeOnClick
					rtl={false}
					pauseOnFocusLoss
					draggable
					pauseOnHover
				/>
			</Page>
		</>
	)
}
