import {
	Alert,
	Button,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	FormControl,
	FormHelperText,
	Grid,
	InputLabel,
	MenuItem,
	Select,
	TextField,
	Typography,
} from '@mui/material'
import api from 'src/Api'
import { useFormik } from 'formik'
import { useEffect, useState } from 'react'

import * as Yup from 'yup'

export default function AddDiplome({
	openAdd,
	handleCloseAdd,
	setUser,
	user,
	showError,
	showSuccess,
	diplomes,
}) {
	const [error, setError] = useState(null)

	const formik = useFormik({
		initialValues: {
			diplome: '',
		},

		validationSchema: Yup.object({
			diplome: Yup.string().required('ce champ est obligatoire *'),
		}),
		onSubmit: function (values) {
			add(values)
		},
	})
	useEffect(() => {
		setError(null)
	}, [openAdd])

	const add = body => {
		api.post('/users/add_diplome/' + user?._id, body)
			.then(res => {
				handleCloseAdd()
				formik.resetForm()
				showSuccess()
				setError(null)
				setUser(res.data)
			})
			.catch(err => {
				showError()
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}
	return (
		<Dialog fullWidth maxWidth="sm" open={openAdd} onClose={handleCloseAdd}>
			<form onSubmit={formik.handleSubmit}>
				<DialogTitle>Ajouter un Diplôme</DialogTitle>
				<DialogContent>
					<Grid container spacing={1}>
						<Grid item xs={12} md={12} lg={12}>
							<FormControl fullWidth sx={{ my: 1 }}>
								<InputLabel id="demo-simple-select-label">Diplôme</InputLabel>
								<Select
									labelId="demo-simple-select-label"
									id="demo-simple-select"
									value={formik.values.diplome}
									label="Diplôme"
									variant="outlined"
									name="diplome"
									onChange={formik.handleChange}
									error={Boolean(formik.touched.diplome && formik.errors.diplome)}
									helperText={formik.touched.diplome && formik.errors.diplome}
								>
									{diplomes.length > 0 &&
										diplomes.map(e => (
											<MenuItem value={e.id}>{e.title}</MenuItem>
										))}
								</Select>
								{formik.touched.diplome && formik.errors.diplome && (
									<FormHelperText sx={{ color: 'red' }}>
										{formik.touched.diplome && formik.errors.diplome}
									</FormHelperText>
								)}
							</FormControl>
						</Grid>
					</Grid>

					{error && <Alert severity="error">{error}</Alert>}
				</DialogContent>

				<DialogActions>
					<Button type="submit">Confimer</Button>
					<Button onClick={handleCloseAdd}>annuler</Button>
				</DialogActions>
			</form>
		</Dialog>
	)
}
