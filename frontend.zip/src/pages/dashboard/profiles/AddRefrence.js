import {
	Alert,
	Button,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	FormControl,
	FormHelperText,
	Grid,
	InputLabel,
	MenuItem,
	Select,
	TextField,
	Typography,
} from '@mui/material'
import api from 'src/Api'
import { useFormik } from 'formik'
import { useEffect, useState } from 'react'

import * as Yup from 'yup'

export default function AddRefrence({
	openAdd,
	handleCloseAdd,
	setUser,
	user,
	showError,
	showSuccess,
}) {
	const [error, setError] = useState(null)

	const formik = useFormik({
		initialValues: {
			company_name: '',
			name: '',
			phone: '',
			email: '',
		},

		validationSchema: Yup.object({
			company_name: Yup.string().required('ce chemp est obligatoire *'),
			name: Yup.string().required('ce chemp est obligatoire *'),
			email: Yup.string().email("Format d'email invalide"),

			phone: Yup.string()
				.matches(
					/^((?:\+|00)?(?:[1-9]\d{0,2})?)?([0-9]{8,11})$/,
					"Le numéro de téléphone n'est pas valide"
				)
				.required('ce chemp est obligatoire *'),
		}),
		onSubmit: function (values) {
			add(values)
		},
	})
	useEffect(() => {
		setError(null)
	}, [openAdd])

	const add = body => {
		api.post('/users/add_reference/' + user?._id, body)
			.then(res => {
				handleCloseAdd()
				formik.resetForm()
				showSuccess()
				setError(null)
				setUser(res.data)
			})
			.catch(err => {
				showError()
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}
	return (
		<Dialog fullWidth maxWidth="sm" open={openAdd} onClose={handleCloseAdd}>
			<form onSubmit={formik.handleSubmit}>
				<DialogTitle>Ajouter une Référence</DialogTitle>
				<DialogContent>
					<Grid container spacing={1}>
						<Grid item xs={12} md={12} lg={12}>
							<FormControl fullWidth sx={{ my: 1 }} variant="standard">
								<TextField
									label="Nom de l'établissement"
									name="company_name"
									onChange={formik.handleChange}
									onBlur={formik.handleBlur}
									value={formik.values.company_name}
									error={
										!!(
											formik.touched.company_name &&
											formik.errors.company_name
										)
									}
									variant="outlined"
									helperText={formik.errors.company_name}
								/>
							</FormControl>
						</Grid>
						<Grid item xs={12} md={12} lg={12}>
							<FormControl fullWidth sx={{ my: 1 }} variant="standard">
								<TextField
									label="Prénom Nom du contact"
									name="name"
									onChange={formik.handleChange}
									onBlur={formik.handleBlur}
									value={formik.values.name}
									error={!!(formik.touched.name && formik.errors.name)}
									variant="outlined"
									helperText={formik.errors.name}
								/>
							</FormControl>
						</Grid>
						<Grid item xs={12} md={12} lg={12}>
							<FormControl fullWidth sx={{ my: 1 }} variant="standard">
								<TextField
									label="Téléphone du contact"
									name="phone"
									onChange={formik.handleChange}
									onBlur={formik.handleBlur}
									value={formik.values.phone}
									error={!!(formik.touched.phone && formik.errors.phone)}
									variant="outlined"
									helperText={formik.errors.phone}
								/>
							</FormControl>
						</Grid>
						<Grid item xs={12} md={12} lg={12}>
							<FormControl fullWidth sx={{ my: 1 }} variant="standard">
								<TextField
									label="Mail du contact (facultatif)"
									name="email"
									onChange={formik.handleChange}
									onBlur={formik.handleBlur}
									value={formik.values.email}
									error={!!(formik.touched.email && formik.errors.email)}
									variant="outlined"
									helperText={formik.errors.email}
								/>
							</FormControl>
						</Grid>
					</Grid>

					{error && <Alert severity="error">{error}</Alert>}
				</DialogContent>

				<DialogActions>
					<Button type="submit">Confimer</Button>
					<Button onClick={handleCloseAdd}>annuler</Button>
				</DialogActions>
			</form>
		</Dialog>
	)
}
