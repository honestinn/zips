import { Close, Edit, Email, LocationCity, Phone, Upload } from '@mui/icons-material'
import {
	Button,
	Avatar,
	Typography,
	Tooltip,
	Stack,
	TextField,
	Grid,
	Container,
	IconButton,
	Divider,
	FormControl,
	InputLabel,
	Select,
	MenuItem,
	FormHelperText,
	Paper,
} from '@mui/material'
import { Box } from '@mui/system'
import * as Yup from 'yup'

import React, { useEffect, useState } from 'react'
import ReactImageUploading from 'react-images-uploading'
import { useFormik } from 'formik'
import api, { FILES_URL } from 'src/Api'
import { useSelector } from 'react-redux'
import { LoadingButton } from '@mui/lab'
import { toast, ToastContainer } from 'react-toastify'
import Page from 'src/components/Page'
import Image from 'src/components/Image'

export default function ProfilePro() {
	const [loading, setLoading] = useState(false)
	const auth = useSelector(state => state.auth)
	const [user, setUser] = useState(null)
	const [cnxErr, setCnxErr] = useState(null)
	// const [title, setTitle] = useState('')
	const [picture, setPicture] = useState([])
	const [submitingPicture, setSubmittingPicture] = useState(false)

	const [jobsCatgories, setJobsCategories] = useState([])

	const checkIbanValidity = async (iban) => {
		try {
			const response = await api.get(`/users/get_iban_infos/${iban}`); // Modifiez ce chemin selon votre API
			return response.data.valid; // Supposons que votre API retourne un champ "valide"
		} catch (error) {
			showError('Erreur lors de la vérification de l\'IBAN');
			return false; // Si l'appel échoue, considérez que l'IBAN n'est pas valide
		}
	};
	const showError = msg => {
        toast.error(msg, {
            position: 'bottom-center',
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        })
    }

    const showSuccess = msg => {
        toast.success(msg, {
            position: 'bottom-center',
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        })
    }
	const formik = useFormik({
		initialValues: {
			category: user?.category || '',
			// title: user?.title || '',
			company_name: user?.company_name || '',
			iban: user?.iban || '',
			description: user?.description || '',
			siret: user?.siret || '',
		},
		enableReinitialize: true,
		validationSchema: Yup.object({
			category: Yup.string().required('ce champ est obligatoire *'),
			description: Yup.string(),

			company_name: Yup.string()
				.matches(
					/^[a-zA-ZàâäéèêëîïôöùûüçÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ\s'-.]+(?:\s[a-zA-ZàâäéèêëîïôöùûüçÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ'-.]+)*$/,
					"Le nom de l'entreprise doit contenir uniquement des lettres, des espaces et éventuellement des caractères spéciaux"
				)
				.required('Ce champ est obligatoire *'),

			siret: Yup.string()
				.matches(
					/^\d{9}(\d{5})?$/,
					'Le SIRET ou le SIREN doit contenir exactement 9 ou 14 chiffres'
				)
				.required('Ce champ est obligatoire *'),

			iban: Yup.string()
				.matches(/^([A-Z]{2})\d{2}(\s?\d{4}){3}\s?[A-Z0-9]{1,16}$/, 'IBAN invalide')
				.required('Ce champ est obligatoire *'),
		}),

		onSubmit: async function (values) {
			const isIbanValid = await checkIbanValidity(values.iban);
			if (!isIbanValid) {
				showError('L\'IBAN que vous avez saisi n\'est pas valide.')
				formik.setFieldValue('iban', user.iban)
				return; // Arrêtez le processus de soumission si l'IBAN n'est pas valide
			}
			saveInfo(values)
		},
	})
	const saveInfo = body => {
		api.post('/users/save_pro_info', body)
			.then(res => {
				setUser(res.data)
				
				toast.success('Modification réussie. Vos changements ont été enregistrés avec succès.', {
					position: 'bottom-center',
					autoClose: 3000,
					hideProgressBar: false,
					closeOnClick: true,
					pauseOnHover: true,
					draggable: true,
					progress: undefined,
				})
			})
			.catch(err => {
				toast.error('Erreur', {
					position: 'bottom-center',
					autoClose: 3000,
					hideProgressBar: false,
					closeOnClick: true,
					pauseOnHover: true,
					draggable: true,
					progress: undefined,
				})
			})
	}
	const onPictureChange = (imageList, addUpdateIndex) => {
		setPicture(imageList)
	}

	useEffect(() => {
		getUser()
		getJobsCategories()
	}, [])

	const getJobsCategories = () => {
		api.get('/admin/get_jobs_categories')
			.then(res => {
				setJobsCategories(res.data)
			})
			.catch(err => {})
	}
	const getUser = () => {
		// Headers
		setLoading(true)
		api.get('/users/get')
			.then(res => {
				setUser(res.data)
				// setTitle(res.data.title)
				setLoading(false)
			})
			.catch(err => {
				setCnxErr(true)
				setLoading(false)
			})
	}

	const submitPicture = () => {
		const config = {
			headers: {
				'content-type': 'multipart/form-data',
			},
		}
		let body = new FormData()

		if (picture.length > 0) {
			body.append('picture', picture[0]?.file)
		}
		// body.append('title', title)

		setSubmittingPicture(true)
		api.post('/users/upload_avatar/' + auth?.user.id, body, config)
			.then(res => {
				setUser(res.data)
				setSubmittingPicture(false)
				toast.success('Modification réussie. Vos changements ont été enregistrés avec succès.', {
					position: 'bottom-center',
					autoClose: 3000,
					hideProgressBar: false,
					closeOnClick: true,
					pauseOnHover: true,
					draggable: true,
					progress: undefined,
				})
			})
			.catch(err => {
				setSubmittingPicture(false)
				toast.error('Erreur', {
					position: 'bottom-center',
					autoClose: 3000,
					hideProgressBar: false,
					closeOnClick: true,
					pauseOnHover: true,
					draggable: true,
					progress: undefined,
				})
			})
	}
	if (cnxErr)
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '60vh',
					border: '1px solid #ccc',
					p: 2,
				}}
			>
				<Typography color={'error'} variant="h6">
					probleme de connexion ...
				</Typography>
			</Box>
		)

	if (loading)
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '60vh',
					border: '1px solid #ccc',
					p: 2,
				}}
			>
				<Typography variant="h6"> Chargement ...</Typography>
			</Box>
		)
	return (
		<>
			<Page title="Profil">
				<Stack spacing={2}>
					<Paper variant="outlined" sx={{ mt: 1, p: 1 }}>
						<Grid container spacing={1}>
							<Grid item xs={12} md={6} lg={4}>
								<ReactImageUploading
									multiple
									value={picture}
									onChange={onPictureChange}
									maxNumber={1}
									dataURLKey="data_url"
									acceptType={['jpg', 'png', 'jpeg']}
								>
									{({
										imageList,
										onImageUpload,
										onImageRemoveAll,
										onImageUpdate,
										onImageRemove,
										isDragging,
										dragProps,
									}) => (
										<>
											<Stack
												sx={{
													display: 'flex',

													alignItems: 'flex-start',
												}}
											>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
														alignItems: 'center',

														width: 200,
														height: 200,
														p: 1,
													}}
												>
													{imageList.length == 0 && (
														<Image
															src={
																user?.avatar.length > 0
																	? FILES_URL + user.avatar
																	: '/statics/image-placeholder.png'
															}
														/>
													)}
													{imageList.map((image, index) => (
														<Image src={image.data_url} />
													))}
												</Box>
												<Tooltip title="Choisir une photo qui représente bien votre société">
													<Button
														sx={{
															backgound: isDragging && 'red',
															textTransform: 'none',
															width: 200,
														}}
														variant="outlined"
														onClick={
															imageList.length > 0
																? () => onImageUpdate(0)
																: onImageUpload
														}
														startIcon={<Upload />}
													>
														Choisir une image
													</Button>
												</Tooltip>
											</Stack>
										</>
									)}
								</ReactImageUploading>
							</Grid>
							<Grid item xs={12} md={6} lg={8}>
								<Stack spacing={1} direction="row" sx={{ display: 'flex', p: 1 }}>
									<Stack spacing={2}>
										<Typography gutterBottom variant="h5">
											{user?.name}
										</Typography>
										<Stack direction="row" spacing={1}>
											<Email />
											<Typography color="text.secondary" variant="body2">
												{user?.email}
											</Typography>
										</Stack>
										<Stack direction="row" spacing={1}>
											<Phone />
											<Typography color="text.secondary" variant="body2">
												{user?.phone}
											</Typography>
										</Stack>
										<Stack direction="row" spacing={1}>
											<LocationCity />
											<Typography color="text.secondary" variant="body2">
												{user?.address}
											</Typography>
										</Stack>
									</Stack>
								</Stack>
							</Grid>
							<Box
								sx={{
									display: 'flex',
									justifyContent: 'flex-end',
									width: '100%',
								}}
							>
								<LoadingButton
									sx={{ minWidth: 220 }}
									loading={submitingPicture}
									variant="contained"
									onClick={() => submitPicture()}
								>
									Sauvgarder
								</LoadingButton>
							</Box>
						</Grid>
					</Paper>
					<Paper variant="outlined" sx={{ mt: 1, p: 1 }}>
						<Stack spacing={1}>
							<Typography variant="h6">Informations : </Typography>
							<form onSubmit={formik.handleSubmit}>
								<Grid container spacing={1}>
									<Grid item xs={12} md={10} lg={10}>
										<FormControl fullWidth>
											<InputLabel id="demo-simple-select-label">
												Catégorie
											</InputLabel>
											<Select
												labelId="demo-simple-select-label"
												id="demo-simple-select"
												value={formik.values.category}
												label="Catégorie"
												variant="outlined"
												name="category"
												onChange={formik.handleChange}
												error={Boolean(
													formik.touched.category &&
														formik.errors.category
												)}
												helperText={
													formik.touched.category &&
													formik.errors.category
												}
											>
												{jobsCatgories.length > 0 &&
													jobsCatgories.map(e => (
														<MenuItem value={e._id}>{e.name}</MenuItem>
													))}
											</Select>
											{formik.touched.category && formik.errors.category && (
												<FormHelperText sx={{ color: 'red' }}>
													{formik.touched.category &&
														formik.errors.category}
												</FormHelperText>
											)}
										</FormControl>
									</Grid>

									<Grid item xs={12} md={5} lg={5}>
										<FormControl fullWidth>
											<TextField
												label="Nom d'établisment"
												name="company_name"
												onChange={formik.handleChange}
												onBlur={formik.handleBlur}
												value={formik.values.company_name}
												error={
													!!(
														formik.touched.company_name &&
														formik.errors.company_name
													)
												}
												variant="outlined"
												helperText={formik.errors.company_name}
											/>
										</FormControl>
									</Grid>
									{/* <Grid item xs={12} md={5} lg={5}>
										<FormControl fullWidth>
											<TextField
												label="Sous-titre"
												name="title"
												onChange={formik.handleChange}
												onBlur={formik.handleBlur}
												value={formik.values.title}
												error={
													!!(formik.touched.title && formik.errors.title)
												}
												variant="outlined"
												helperText={formik.errors.title}
											/>
										</FormControl>
									</Grid> */}

									<Grid item xs={12} md={10} lg={10}>
										<FormControl fullWidth>
											<TextField
												label="SIRET ou SIREN"
												name="siret"
												onChange={formik.handleChange}
												onBlur={formik.handleBlur}
												value={formik.values.siret}
												error={
													!!(formik.touched.siret && formik.errors.siret)
												}
												variant="outlined"
												helperText={formik.errors.siret}
											/>
										</FormControl>
									</Grid>
									<Grid item xs={12} md={10} lg={10}>
										<FormControl fullWidth>
											<TextField
												label="IBAN"
												name="iban"
												onChange={formik.handleChange}
												onBlur={formik.handleBlur}
												value={formik.values.iban}
												error={
													!!(formik.touched.iban && formik.errors.iban)
												}
												variant="outlined"
												helperText={formik.errors.iban}
											/>
										</FormControl>
									</Grid>
									<Grid item xs={12} md={10} lg={10}>
										<FormControl fullWidth>
											<TextField
												label="Description"
												multiline
												rows={4}
												name="description"
												onChange={formik.handleChange}
												onBlur={formik.handleBlur}
												value={formik.values.description}
												error={
													!!(
														formik.touched.description &&
														formik.errors.description
													)
												}
												variant="outlined"
												helperText={formik.errors.description}
											/>
										</FormControl>
									</Grid>
								</Grid>
							</form>
							<Box
								sx={{ display: 'flex', justifyContent: 'flex-end', width: '100%' }}
							>
								<LoadingButton
									sx={{ minWidth: 220 }}
									variant="contained"
									onClick={formik.submitForm}
								>
									Sauvgarder
								</LoadingButton>
							</Box>
						</Stack>
					</Paper>
				</Stack>

				<ToastContainer
					position="top-center"
					autoClose={3000}
					hideProgressBar={false}
					newestOnTop={false}
					closeOnClick
					rtl={false}
					pauseOnFocusLoss
					draggable
					pauseOnHover
				/>
			</Page>
		</>
	)
}
