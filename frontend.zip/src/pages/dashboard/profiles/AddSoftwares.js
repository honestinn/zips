import {
	Alert,
	Button,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	FormControl,
	FormHelperText,
	Grid,
	InputLabel,
	MenuItem,
	Select,
	TextField,
	Typography,
} from '@mui/material'
import api from 'src/Api'
import { useFormik } from 'formik'
import { useEffect, useState } from 'react'

import * as Yup from 'yup'

export default function AddSoftwares({
	openAdd,
	handleCloseAdd,
	setUser,
	user,
	showError,
	showSuccess,
	softwares,
}) {
	const [error, setError] = useState(null)

	const formik = useFormik({
		initialValues: {
			software: '',
		},

		validationSchema: Yup.object({
			software: Yup.string().required('ce chemp est obligatoire *'),
		}),
		onSubmit: function (values) {
			add(values)
		},
	})
	useEffect(() => {
		setError(null)
	}, [openAdd])

	const add = body => {
		api.post('/users/add_software/' + user?._id, body)
			.then(res => {
				handleCloseAdd()
				formik.resetForm()
				showSuccess()
				setError(null)
				setUser(res.data)
			})
			.catch(err => {
				showError()
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}
	return (
		<Dialog fullWidth maxWidth="sm" open={openAdd} onClose={handleCloseAdd}>
			<form onSubmit={formik.handleSubmit}>
				<DialogTitle>Ajouter un Logiciel</DialogTitle>
				<DialogContent>
					<Grid container spacing={1}>
						<Grid item xs={12} md={12} lg={12}>
							<FormControl fullWidth sx={{ my: 1 }}>
								<InputLabel id="demo-simple-select-label">Logiciel</InputLabel>
								<Select
									labelId="demo-simple-select-label"
									id="demo-simple-select"
									value={formik.values.software}
									label="Logiciel"
									variant="outlined"
									name="software"
									onChange={formik.handleChange}
									error={Boolean(
										formik.touched.software && formik.errors.software
									)}
									helperText={formik.touched.software && formik.errors.software}
								>
									{softwares.length > 0 &&
										softwares.map(e => (
											<MenuItem value={e.id}>{e.name}</MenuItem>
										))}
								</Select>
								{formik.touched.software && formik.errors.software && (
									<FormHelperText sx={{ color: 'red' }}>
										{formik.touched.software && formik.errors.software}
									</FormHelperText>
								)}
							</FormControl>
						</Grid>
					</Grid>

					{error && <Alert severity="error">{error}</Alert>}
				</DialogContent>

				<DialogActions>
					<Button type="submit">Confimer</Button>
					<Button onClick={handleCloseAdd}>annuler</Button>
				</DialogActions>
			</form>
		</Dialog>
	)
}
