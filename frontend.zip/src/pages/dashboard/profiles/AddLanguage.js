import {
	Alert,
	Button,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	FormControl,
	FormHelperText,
	Grid,
	InputLabel,
	MenuItem,
	Select,
	TextField,
	Typography,
} from '@mui/material'
import api from 'src/Api'
import { useFormik } from 'formik'
import { useEffect, useState } from 'react'

import * as Yup from 'yup'

export default function AddLanguage({
	openAdd,
	handleCloseAdd,
	setUser,
	user,
	showError,
	showSuccess,
	langs,
	levels,
}) {
	const [error, setError] = useState(null)

	const formik = useFormik({
		initialValues: {
			lang: '',
			level: '',
		},

		validationSchema: Yup.object({
			lang: Yup.string().required('ce chemp est obligatoire *'),
			level: Yup.string().required('ce chemp est obligatoire *'),
		}),
		onSubmit: function (values) {
			add(values)
		},
	})
	useEffect(() => {
		setError(null)
	}, [openAdd])

	const add = body => {
		api.post('/users/add_language/' + user?._id, body)
			.then(res => {
				handleCloseAdd()
				formik.resetForm()
				showSuccess()
				setError(null)
				setUser(res.data)
			})
			.catch(err => {
				showError()
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}
	return (
		<Dialog fullWidth maxWidth="sm" open={openAdd} onClose={handleCloseAdd}>
			<form onSubmit={formik.handleSubmit}>
				<DialogTitle>Ajouter une Langue</DialogTitle>
				<DialogContent>
					<Grid container spacing={1}>
						<Grid item xs={12} md={12} lg={12}>
							<FormControl fullWidth sx={{ my: 1 }}>
								<InputLabel id="demo-simple-select-label">Langues</InputLabel>
								<Select
									labelId="demo-simple-select-label"
									id="demo-simple-select"
									value={formik.values.lang}
									label="Langues"
									variant="outlined"
									name="lang"
									onChange={formik.handleChange}
									error={Boolean(formik.touched.lang && formik.errors.lang)}
									helperText={formik.touched.lang && formik.errors.lang}
								>
									{langs.length > 0 &&
										langs.map(e => <MenuItem value={e.id}>{e.title}</MenuItem>)}
								</Select>
								{formik.touched.lang && formik.errors.lang && (
									<FormHelperText sx={{ color: 'red' }}>
										{formik.touched.lang && formik.errors.lang}
									</FormHelperText>
								)}
							</FormControl>
						</Grid>
						<Grid item xs={12} md={12} lg={12}>
							<FormControl fullWidth sx={{ my: 1 }}>
								<InputLabel id="demo-simple-select-label">Niveau</InputLabel>
								<Select
									labelId="demo-simple-select-label"
									id="demo-simple-select"
									value={formik.values.level}
									label="Niveau de maitrise"
									variant="outlined"
									name="level"
									onChange={formik.handleChange}
									error={Boolean(formik.touched.level && formik.errors.level)}
									helperText={formik.touched.level && formik.errors.level}
								>
									{levels.length > 0 &&
										levels.map(e => (
											<MenuItem value={e.id}>{e.level}</MenuItem>
										))}
								</Select>
								{formik.touched.level && formik.errors.level && (
									<FormHelperText sx={{ color: 'red' }}>
										{formik.touched.level && formik.errors.level}
									</FormHelperText>
								)}
							</FormControl>
						</Grid>
					</Grid>

					{error && <Alert severity="error">{error}</Alert>}
				</DialogContent>

				<DialogActions>
					<Button type="submit">Confimer</Button>
					<Button onClick={handleCloseAdd}>annuler</Button>
				</DialogActions>
			</form>
		</Dialog>
	)
}
