import {
  Alert,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormHelperText,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import api from "src/Api";
import { useFormik } from "formik";
import { useEffect, useState } from "react";

import * as Yup from "yup";
function formatDate(date) {
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const year = date.getFullYear();

  return `${year}-${month}-${day}`;
}
export default function AddExperience({
  openAdd,
  handleCloseAdd,
  setUser,
  user,
  showError,
  showSuccess,
}) {
  const [error, setError] = useState(null);
  const [loadingJobs, setloadingJobs] = useState(false);
  const [loadingCategories, setLoadingCategories] = useState(false);
  const [loadingSubCategories, setLoadingSubCategories] = useState(false);
  const [jobsCatgories, setJobsCategories] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [jobSubCatgories, setJobSubCategories] = useState([]);
  const today = formatDate(new Date());

  const formik = useFormik({
    initialValues: {
      category: "",
      subcategory: "",
      job: "",
      company: "",
      // exp: '',
      start_date: "",
      end_date: "",
    },

    validationSchema: Yup.object({
      category: Yup.string().required("ce champ est obligatoire *"),
      subcategory: Yup.string().required("ce champ est obligatoire *"),
      job: Yup.string().required("ce champ est obligatoire *"),
      company: Yup.string().required("Ce champ est obligatoire *"),
      experience_description : Yup.string().required("Ce champ est obligatoire"),
      // exp: Yup.string().required('ce chemp est obligatoire *'),
      start_date: Yup.string()
        .required("ce champ est obligatoire *")
        .test(
          "startDateTest",
          "La date de début doit être dans le passé",
          function (value) {
            let d1 = new Date(value).setHours(0, 0, 0, 0);
            let d2 = new Date().setHours(0, 0, 0, 0);
            return d1 < d2;
          }
        ),
      end_date: Yup.string()
        .required("ce champ est obligatoire *")
        .test(
          "endDateTest",
          "La date de début doit être valide",
          function (value) {
            let d1 = new Date(value).setHours(0, 0, 0, 0);
            let d2 = new Date().setHours(0, 0, 0, 0);
            return d1 <= d2;
          }
        )
        .test(
          "dateComparison",
          "La date de fin ne peut pas être avant la date de début",
          function (value) {
            const { start_date } = this.parent;
            let d1 = new Date(value).setHours(0, 0, 0, 0);
            let d2 = new Date(start_date).setHours(0, 0, 0, 0);
            return d1 >= d2;
          }
        ),
    }),
    onSubmit: function (values) {
      add(values);
    },
  });
  useEffect(() => {
    setError(null);
    if (openAdd) getJobsCategories();
  }, [openAdd]);

  const getJobsCategories = () => {
    setLoadingCategories(true);
    api
      .get("/admin/get_jobs_categories")
      .then((res) => {
        setJobsCategories(res.data);
        setLoadingCategories(false);
      })
      .catch((err) => {
        setLoadingCategories(false);
        if (err.code === "ERR_NETWORK") {
          setError("le serveur ne répond pas");
        } else setError(err.response?.data.error);
      });
  };

  const getJobs = (id) => {
    setloadingJobs(true);
    api
      .get("/admin/get_jobs/" + id)
      .then((res) => {
        setJobs(res.data);
        setloadingJobs(false);
      })
      .catch((err) => {
        setloadingJobs(false);
        if (err.code === "ERR_NETWORK") {
          setError("le serveur ne répond pas");
        } else setError(err.response?.data.error);
      });
  };
  const getJobSubCategories = (id) => {
    setLoadingSubCategories(true);
    api
      .get("/admin/get_job_sub_categories/" + id)
      .then((res) => {
        setJobSubCategories(res.data);
        setLoadingSubCategories(false);
      })
      .catch((err) => {
        setLoadingSubCategories(false);
        if (err.code === "ERR_NETWORK") {
          setError("le serveur ne répond pas");
        } else setError(err.response?.data.error);
      });
  };

  const add = (body) => {
    api
      .post("/users/add_experience", body)
      .then((res) => {
        handleCloseAdd();
        formik.resetForm();
        showSuccess();
        setError(null);
        setUser(res.data);
      })
      .catch((err) => {
        showError();
        if (err.code === "ERR_NETWORK") {
          setError("le serveur ne répond pas");
        } else setError(err.response?.data.error);
      });
  };
  return (
    <Dialog fullWidth maxWidth="sm" open={openAdd} onClose={handleCloseAdd}>
      <form onSubmit={formik.handleSubmit}>
        <DialogTitle>Ajouter un Métier</DialogTitle>
        <DialogContent>
          <Grid container spacing={1}>
            <Grid item xs={12} md={12} lg={12}>
              <FormControl fullWidth sx={{ my: 1 }}>
                <InputLabel id="demo-simple-select-label">Catégorie</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={formik.values.category}
                  label="Catégorie"
                  variant="outlined"
                  name="category"
                  onChange={(event) => {
                    getJobSubCategories(event.target.value);
                    formik.setFieldValue("category", event.target.value);
                  }}
                  error={Boolean(
                    formik.touched.category && formik.errors.category
                  )}
                  helperText={formik.touched.category && formik.errors.category}
                >
                  {jobsCatgories.length > 0 &&
                    jobsCatgories.map((e) => (
                      <MenuItem value={e._id}>{e.name}</MenuItem>
                    ))}
                </Select>
                {formik.touched.category && formik.errors.category && (
                  <FormHelperText sx={{ color: "red" }}>
                    {formik.touched.category && formik.errors.category}
                  </FormHelperText>
                )}
              </FormControl>
            </Grid>
            {formik.values.category && (
              <Grid item xs={12} md={6} lg={6}>
                <FormControl fullWidth sx={{ my: 1 }}>
                  <InputLabel id="demo-simple-select-label">
                    Sous-Catégorie
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={formik.values.subcategory}
                    label="Sous-Catégorie"
                    variant="outlined"
                    name="subcategory"
                    onChange={(event) => {
                      getJobs(event.target.value);
                      formik.setFieldValue("subcategory", event.target.value);
                    }}
                    error={Boolean(
                      formik.touched.subcategory && formik.errors.subcategory
                    )}
                  >
                    {jobSubCatgories.length > 0 &&
                      jobSubCatgories.map((e) => (
                        <MenuItem value={e._id}>{e.name}</MenuItem>
                      ))}
                  </Select>
                  {formik.touched.subcategory && formik.errors.subcategory && (
                    <FormHelperText sx={{ color: "red" }}>
                      {formik.touched.subcategory && formik.errors.subcategory}
                    </FormHelperText>
                  )}
                </FormControl>
              </Grid>
            )}
            {formik.values.category && formik.values.subcategory && (
              <Grid item xs={12} md={6} lg={6}>
                <FormControl fullWidth sx={{ my: 1 }}>
                  <InputLabel id="demo-simple-select-label">Métier</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={formik.values.job}
                    label="Métier"
                    variant="outlined"
                    name="job"
                    onChange={(event) => {
                      formik.setFieldValue("job", event.target.value);
                    }}
                    error={Boolean(formik.touched.job && formik.errors.job)}
                  >
                    {jobs.length > 0 &&
                      jobs
                        .sort((a, b) => a.name.localeCompare(b.name))
                        .map((e) => (
                          <MenuItem value={e._id}>{e.name}</MenuItem>
                        ))}
                  </Select>
                  {formik.touched.job && formik.errors.job && (
                    <FormHelperText sx={{ color: "red" }}>
                      {formik.touched.job && formik.errors.job}
                    </FormHelperText>
                  )}
                </FormControl>
              </Grid>
            )}
            <Grid item xs={12} md={12} lg={12}>
              <FormControl fullWidth sx={{ my: 1 }}>
                <TextField
                  label="Lieu d'expérience"
                  name="company"
                  type="text"
                  size="small"
                  value={formik.values.company} // Utilisez formik.values.company
                  onChange={formik.handleChange} // Gère la modification du champ
                  onBlur={formik.handleBlur} // Gère la validation quand l'utilisateur quitte le champ
                  variant="outlined"
                  error={formik.touched.company && formik.errors.company} // Affiche une erreur si le champ est touché et contient des erreurs
                  helperText={formik.touched.company && formik.errors.company} // Affiche un message d'erreur
                />
              </FormControl>
            </Grid>

            {/* <Grid item xs={12} md={12} lg={12}>
							<FormControl fullWidth sx={{ my: 1 }} variant="standard">
								<TextField
									label="Années d'expérience"
									name="exp"
									onChange={formik.handleChange}
									onBlur={formik.handleBlur}
									value={formik.values.exp}
									error={!!(formik.touched.exp && formik.errors.exp)}
									variant="outlined"
									helperText={formik.errors.exp}
								/>
							</FormControl>
						</Grid> */}
            <Grid item xs={12} md={6} lg={6}>
              <FormControl fullWidth sx={{ my: 1 }} variant="standard">
                <TextField
                  label="Du"
                  name="start_date"
                  type="date"
                  size="small"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.start_date}
                  error={
                    !!(formik.touched.start_date && formik.errors.start_date)
                  }
                  variant="outlined"
                  helperText={formik.errors.start_date}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6} lg={6}>
              <FormControl fullWidth sx={{ my: 1 }} variant="standard">
                <TextField
                  label="Au"
                  name="end_date"
                  type="date"
                  size="small"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.end_date}
                  error={!!(formik.touched.end_date && formik.errors.end_date)}
                  variant="outlined"
                  helperText={formik.errors.end_date}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </FormControl>
            </Grid>
            <Grid item xs={12} md={12} lg={12}>
              <FormControl fullWidth sx={{ my: 1 }} variant="standard">
                <TextField
                  label="Description de l'expérience"
                  name="experience_description"
                  multiline
                  rows={4} // You can adjust the number of rows for height
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.experience_description}
                  error={
                    !!(
                      formik.touched.experience_description &&
                      formik.errors.experience_description
                    )
                  }
                  variant="outlined"
                  helperText={formik.errors.experience_description}
                />
              </FormControl>
            </Grid>
          </Grid>

          {error && <Alert severity="error">{error}</Alert>}
        </DialogContent>

        <DialogActions>
          <Button type="submit">Confimer</Button>
          <Button onClick={handleCloseAdd}>annuler</Button>
        </DialogActions>
      </form>
    </Dialog>
  );
}
