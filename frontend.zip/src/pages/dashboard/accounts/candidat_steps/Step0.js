import { NavigateNext } from '@mui/icons-material'
import { Avatar, Button, Stack, Typography } from '@mui/material'
import { Box } from '@mui/system'
import React from 'react'
import api from 'src/Api'

export default function Step0({ name, setActiveStep, setUnVerifiedSteps }) {
	const nextStep = () => {
		api.post('/users/submit_step', { step: 0 })
			.then(res => {
				setActiveStep(1)
				setUnVerifiedSteps(res.data.unverified_steps)
			})
			.catch(err => {})
	}
	return (
		<Stack>
			<Stack
				direction="row"
				justifyContent={'space-between'}
				spacing={1}
				sx={{ width: 700, p: 1 }}
			>
				<Typography sx={{ maxWidth: 300 }} variant="Body2">
					Sur notre plateforme, nous vous invitons à compléter la création de votre profil
					afin de garantir une expérience optimale. Votre profil nous permettra de mieux
					vous servir et de vous offrir les fonctionnalités adaptées à vos besoins. Merci
					de prendre le temps de fournir les informations nécessaires pour que nous
					puissions personnaliser votre expérience sur notre plateforme
				</Typography>

				<Box
					sx={{
						display: 'flex',
						justifyContent: 'center',
						alignItems: 'center',
						width: '100%',

						height: 300,
					}}
				>
					<img
						src="/statics/undraw_hello_re_3evm.svg"
						style={{ maxHeight: '100%', maxWidth: '100%' }}
					/>
				</Box>
			</Stack>{' '}
			<Stack direction={'row'} justifyContent="flex-end">
				<Button onClick={nextStep} startIcon={<NavigateNext />}>
					Suivant
				</Button>
			</Stack>
		</Stack>
	)
}
