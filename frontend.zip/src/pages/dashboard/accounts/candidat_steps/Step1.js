import { Edit, Save, Upload } from '@mui/icons-material';
import { Button, Avatar, Typography, Tooltip, Stack, TextField, Modal, CircularProgress } from '@mui/material';
import { Box } from '@mui/system';
import React, { useState, useEffect, useRef } from 'react';
import ReactImageUploading from 'react-images-uploading';
import api, { FILES_URL } from 'src/Api';
import { ToastContainer, toast } from 'react-toastify';
import Image from 'src/components/Image';
import * as faceapi from 'face-api.js';
import Webcam from 'react-webcam';
import CameraAltIcon from '@mui/icons-material/CameraAlt';
import { Close } from '@mui/icons-material';
import { IconButton } from '@mui/material';

export default function Step1({ user, nextStep, setUnVerifiedSteps, setUser }) {
    const [picture, setPicture] = useState([]);
    const webcamRef = useRef(null);
    const [faceDetected, setFaceDetected] = useState(false);
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);

    // Load face-api.js models
    useEffect(() => {
        const loadModels = async () => {
            const MODEL_URL = '/models'; // Adjust the path to your models directory
            await Promise.all([
                faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL),
            ]);
        };

        loadModels();
    }, []);

	const capture = async () => {
		setLoading(true);
		const imageSrc = webcamRef.current.getScreenshot();
		if (imageSrc) {
			const blob = await fetch(imageSrc).then(res => res.blob()); // Convert the data URL to a Blob
			const imageFile = new File([blob], 'capturedImage.jpg', { type: 'image/jpeg' });
	
			const imageList = [{ data_url: imageSrc, file: imageFile }];
			await onPictureChange(imageList); // Reuse onPictureChange for the captured image
			setOpen(false); // Close modal after capturing the photo
		}
		setLoading(false);
	};

    const onPictureChange = async (imageList, addUpdateIndex) => {
        // Check if a face is detected in the uploaded image
        if (imageList.length > 0) {
            // const img = await faceapi.fetchImage(imageList[0].data_url);
            // const detections = await faceapi.detectAllFaces(img);

            // if (detections.length === 0) {
            //     showError("Aucun visage détecté dans l'image téléchargée.");
            // } else if (detections.length > 1) {
            //     showError("Plusieurs visages détectés dans l'image téléchargée.");
            // } else {
            //     setPicture(imageList);
            //     showSuccess("L'image est conforme et a été validée avec succès.");
            //     setFaceDetected(detections.length === 1); // Set face detection state
            // }
            setPicture(imageList)
        }
    };

    const showError = (msg) => {
        toast.error(msg, {
            position: 'bottom-center',
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    };

    const showSuccess = (msg) => {
        toast.success(msg, {
            position: 'bottom-center',
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    };

    const submit = () => {
        // if (!faceDetected) {
        //     showError("Veuillez télécharger une photo conforme.");
        //     return;
        // }
        const config = {
            headers: {
                'content-type': 'multipart/form-data',
            },
        };
        let body = new FormData();
        body.append('picture', picture[0]?.file);
        body.append('step', 1);

        api.post('/users/submit_step', body, config)
            .then(res => {
                setUser(res.data);
                setUnVerifiedSteps(res.data.unverified_steps);
                showSuccess('Opération réussie');
            })
            .catch(err => {
                showError('Quelque chose ne va pas');
            });
    };

    return (
        <>
            <Stack spacing={1} sx={{ display: 'flex', alignItems: 'center' }}>
                <ReactImageUploading
                    multiple
                    value={picture}
                    onChange={onPictureChange}
                    maxNumber={1}
                    dataURLKey="data_url"
                    acceptType={['jpg', 'png', 'jpeg']}
                >
                    {({
                        imageList,
                        onImageUpload,
                        onImageUpdate,
                    }) => (
                        <>
                            <Box
                                sx={{
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    width: 250,
                                    height: 250,
                                    p: 1,
                                }}
                            >
                                {imageList.length === 0 && (
                                    <Image
                                        src={user?.avatar.length > 0 ? FILES_URL + user.avatar : '/statics/image-placeholder.png'}
                                    />
                                )}
                                {imageList.map((image, index) => (
                                    <Image key={index} src={image.data_url} />
                                ))}
                            </Box>
                            <Box>
                                <Tooltip title="Choisir une photo qui représente bien votre société">
                                    <Button
                                        variant="outlined"
                                        onClick={
                                            imageList.length > 0
                                                ? () => onImageUpdate(0)
                                                : onImageUpload
                                        }
                                        startIcon={<Upload />}
                                    >
                                        Choisir une image
                                    </Button>
                                </Tooltip>
                                <Button variant="outlined" sx={{ ml: 2 }} onClick={() => setOpen(true)}>
                                    <CameraAltIcon />
                                </Button>
                            </Box>
                        </>
                    )}
                </ReactImageUploading>
                <Typography gutterBottom variant="h5">
                    {/* {user.name} */}
                </Typography>
                <Typography color="text.secondary" variant="body2">
                    {/* {user.email} */}
                </Typography>
                <Typography color="text.secondary" variant="body2">
                    {/* {user.phone} */}
                </Typography>
                <Button
                    disabled={!picture[0]?.file}
                    variant="contained"
                    startIcon={<Save />}
                    onClick={submit}
                >
                    Sauvegarder
                </Button>
            </Stack>

            {/* Modal for Webcam */}
            <Modal open={open} onClose={() => setOpen(false)}>
                <Box
                    sx={{
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        height: '100vh',
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    }}
                >
                    <IconButton
                        sx={{
                            position: 'absolute',
                            top: 16,
                            right: 16,
                            color: 'white', // Close icon color
                        }}
                        onClick={() => setOpen(false)}
                    >
                        <Close />
                    </IconButton>
                    <Box
                        sx={{
                            display: 'flex',
                            flexDirection: 'column',
                            justifyContent: 'center',
                            alignItems: 'center',
                            height: '100vh',
                        }}
                    >
                        <Webcam
                            audio={false}
                            ref={webcamRef}
                            screenshotFormat="image/jpeg"
                            style={{
                                width: '100%',
                                height: 'auto',
                                maxWidth: '70%',
                            }} 
                        />
                        {/* Loading spinner */}
                        {loading ? (
                            <Stack direction="row" spacing={2} alignItems="center" sx={{ mt: 2 }}>
                                <CircularProgress size={24} color="inherit" />
                                <Typography color="white">Analyse de la photo...</Typography>
                            </Stack>
                        ) : (
                            <Button variant="contained" onClick={capture} sx={{ marginLeft: 2 }}>
                                Capturer
                            </Button>
                        )}
                    </Box>
                </Box>
            </Modal>

            <ToastContainer
                autoClose={3000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
            />
        </>
    );
}
