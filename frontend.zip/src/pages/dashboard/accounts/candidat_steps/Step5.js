import { Close, Edit, Save, Upload } from '@mui/icons-material'
import { LoadingButton } from '@mui/lab'
import {
	Button,
	Avatar,
	Typography,
	Tooltip,
	Stack,
	TextField,
	Divider,
	FormControl,
	InputLabel,
	Select,
	MenuItem,
	Grid,
	IconButton,
	Paper,
} from '@mui/material'
import { Box } from '@mui/system'
import { useFormik } from 'formik'
import api from 'src/Api'

import React, { useEffect, useState } from 'react'
import * as Yup from 'yup'
import { ToastContainer, toast } from 'react-toastify'
import AddExperience from '../../profiles/AddExperience'
import AddRefrence from '../../profiles/AddRefrence'
import AddLanguage from '../../profiles/AddLanguage'

export default function Step5({ user, setUnVerifiedSteps }) {
	const [openLang, setOpenAddLang] = useState(false)
	const [languages, setLanguages] = useState([...user?.languages])
	const [langs, setLangs] = useState([])
	const [levels, setLevels] = useState([])

	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}

	const deleteLanguage = id => {
		// Headers
		api.post('/users/delete_language/' + user._id, { id })
			.then(res => {
				setUnVerifiedSteps([...res.data.unverified_steps])
				setLanguages(res.data?.languages)
			})
			.catch(err => {})
	}
	useEffect(() => {
		getLanguagesList()
	}, [])
	const getLanguagesList = () => {
		api.get('/users/get_lang_list')
			.then(res => {
				setLangs(res.data.langs)
				setLevels(res.data.levels)
			})
			.catch(err => {})
	}
	return (
		<Box>
			<Stack spacing={1}>
				<Typography variant="subtitle1">Langue(s)</Typography>
				{languages?.length < 1 && (
					<Typography color={'error'} variant="body2">
						Veuillez ajouter une Langue
					</Typography>
				)}
				<Stack direction={'row'} spacing={1} flexWrap="wrap">
					{languages?.map(item => (
						<Paper variant="outlined" sx={{ background: '#919eab3d' }}>
							<Stack direction={'row'} sx={{ ml: 1, p: 1 }} spacing={1}>
								<Box>
									<Typography variant="body2">
										{langs.find(e => e.id == item.lang)?.title}
									</Typography>
									<Typography variant="body2" color="text.secondary">
										{levels.find(e => e.id == item.level)?.level}
									</Typography>
								</Box>
								<IconButton onClick={() => deleteLanguage(item.lang)}>
									<Close />
								</IconButton>
							</Stack>
						</Paper>
					))}
				</Stack>
				<Box sx={{ display: 'flex', justifyContent: 'end' }}>
					<Button
						onClick={() => setOpenAddLang(true)}
						sx={{ minWidth: 220, textTransform: 'none' }}
						variant="contained"
					>
						Ajouter une langue
					</Button>
				</Box>
			</Stack>

			{openLang && (
				<AddLanguage
					openAdd={openLang}
					handleCloseAdd={() => setOpenAddLang(false)}
					setUser={user => {
						setUnVerifiedSteps([...user?.unverified_steps])
						setLanguages([...user?.languages])
					}}
					showSuccess={showSuccess}
					showError={showError}
					user={user}
					langs={langs}
					levels={levels}
				/>
			)}
		</Box>
	)
}
