import { Check, CheckCircle, PostAdd } from '@mui/icons-material'
import CancelIcon from '@mui/icons-material/Cancel';
import { LoadingButton } from '@mui/lab'
import {
	Button,
	Avatar,
	Typography,
	Tooltip,
	Stack,
	TextField,
	Divider,
	Paper,
} from '@mui/material'

import { Link as MuiLink } from '@mui/material'

import { Box } from '@mui/system'

import api, { FILES_URL } from 'src/Api'

import React, { useEffect, useState } from 'react'

import { ToastContainer, toast } from 'react-toastify'

import { APP_URL } from 'src/config'

export default function Step2({ user, setUnVerifiedSteps, setDocuments }) {
	const [submitting, setSubmitting] = useState(false)
	const [files, setFiles] = useState([])
	const [selectedFilesCount, setSelectedFilesCount] = useState(0);
	const [uploadingFiles, setUploadingFiles] = useState(false)
	
	const [editDocumentsLoading, setEditDocumentsLoading] = useState(false)

	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
// Fonction pour afficher les documents et initialiser le compteur
const getDocs = () => {
	api.get('/users/get_docs')
		.then(res => {
			const docs = res.data.map(e => ({ ...e, file: null })) ?? [];
			setFiles(docs);

			// Comptez les fichiers déjà validés (is_valid === true)
			const validFilesCount = docs.filter(doc => doc.is_valid === true).length;
			setSelectedFilesCount(validFilesCount); // Initialisez avec le nombre de fichiers validés
		})
		.catch(err => {});
};
	
	useEffect(() => {
		getDocs()
	}, [])
	// const handleFileChange = (event, id) => {
	// 	const newFiles = [...files.filter(e => e.id !== id)]
	// 	let tmp = files.find(e => e.id == id)

	// 	tmp.file = event.target.files[0]

	// 	setFiles([...newFiles, tmp])
	// }
	// Fonction de gestion du changement de fichier
const handleFileChange = (event, id) => {
	const newFiles = [...files.filter(e => e.id !== id)];
	let tmp = files.find(e => e.id == id);
	const previousFile = tmp.file;

	tmp.file = event.target.files[0];
	setFiles([...newFiles, tmp]);

	// Mise à jour du compteur en fonction du changement de fichier
	if (!previousFile && tmp.file) {
		setSelectedFilesCount(prevCount => prevCount + 1);
	} else if (previousFile && !tmp.file) {
		setSelectedFilesCount(prevCount => prevCount - 1);
	}
};
	const submitFiles = (event, id) => {
		const config = {
			headers: {
				'content-type': 'multipart/form-data',
			},
		}

	//	let invalid = files.some(
	//		e => (e.required == true && e.file === null) || (e.file === null && e.path.length == 0)
	//	)
		let invalid = true
		selectedFilesCount == 5 ? invalid = false : invalid = true
		console.log(selectedFilesCount)
		if (invalid) showError('Veuillez fournir les documents obligatoires')
		else {
			const body = new FormData()

			files.forEach(doc => {
				body.append(`file${doc.id}`, doc.file)
			})

			api.post('/users/submit_docs', body, config)
				.then(res => {
					toast.success('Modification réussie. Vos changements ont été enregistrés avec succès.', {
						position: 'bottom-center',
						autoClose: 3000,
						hideProgressBar: false,
						closeOnClick: true,
						pauseOnHover: true,
						draggable: true,
						progress: undefined,
					})
					setEditDocumentsLoading(false)
					setUnVerifiedSteps(res.data.unverified_steps)

					setFiles(
						res.data?.documents?.map(e => {
							return { ...e, file: null }
						})
					)
				})
				.catch(err => {
					toast.error('Erreur', {
						position: 'bottom-center',
						autoClose: 3000,
						hideProgressBar: false,
						closeOnClick: true,
						pauseOnHover: true,
						draggable: true,
						progress: undefined,
					})
					setEditDocumentsLoading(false)
				})
		}
	}
	useEffect(() => {}, [])
	return (
		<>
			<Stack spacing={1} sx={{ minWidth: 700, p: 1 }}>
				<Typography variant="subtitle2">Exige les documents ci-dessous </Typography>
				<Typography variant="caption">
					la taille totale des documents doit être inférieure à 20 Mo.
				</Typography>

				{files
					.sort((a, b) => a.id - b.id)
					.map(doc => (
						<>
							{doc.status == true && (
								<Paper variant="outlined" sx={{ display: 'flex' }}>
									<Stack direction={'row'} alignItems="center" spacing={2}>
										{doc.is_valid == true && (
											<CheckCircle
												sx={{ mx: 1, fontSize: '15px', color: 'green' }}
											/>
										)}

										{doc.is_valid == false && (
												<CancelIcon
												sx={{ mx: 1, fontSize: '15px', color: 'red' }}
												/>
										)}
										<Stack>
											<Typography variant="body2">{doc.name}</Typography>
											{doc.file ? (
												<MuiLink
													href={URL.createObjectURL(doc.file)}
													target="_blank"
													rel="noopener noreferrer"
													color="inherit"
												>
													<Typography
														sx={{
															color: 'blue',
															textDecoration: 'underline',
														}}
														variant="caption"
													>
														{doc.file && doc.file.name}
													</Typography>
													
												</MuiLink>
											) : (
												doc.path.length > 0 && (
													<MuiLink
														href={FILES_URL + doc.path}
														target="_blank"
														rel="noopener noreferrer"
														color="inherit"
													>
														<Typography
															sx={{
																color: 'blue',
																textDecoration: 'underline',
															}}
															variant="caption"
														>
															Consulter le document ..
														</Typography>
													</MuiLink>
												) 
											)}
										</Stack>
										{doc.is_valid == false && (
											<>
												<input
													type="file"
													id={'file' + doc?.id}
													style={{ display: 'none' }}
													accept={doc?.types.map(e => '.' + e).join(', ')}
													onChange={event =>
														handleFileChange(event, doc?.id)
													}
												/>
												<label htmlFor={'file' + doc?.id}>
													<Button
														sx={{
															textTransform: 'none',
														}}
														variant="text"
														component="span"
														size="small"
														startIcon={<PostAdd />}
													>
														<Typography variant="caption">
															Choisir une fichier(
															{doc.types.join(',')})
														</Typography>
													</Button>
												</label>
											</>
										)}
									</Stack>
								</Paper>
							)}
						</>
					))}

				<LoadingButton
					sx={{ width: 200, alignSelf: 'end' }}
					size="miduim"
					onClick={submitFiles}
					variant="contained"
					loading={uploadingFiles}
				>
					sauvgarder
				</LoadingButton>
			</Stack>

			<ToastContainer
				autoClose={3000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
			/>
		</>
	)
}
