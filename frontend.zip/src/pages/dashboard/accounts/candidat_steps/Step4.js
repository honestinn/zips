import { Close, Edit, Save, Upload } from '@mui/icons-material'
import { LoadingButton } from '@mui/lab'
import {
	Button,
	Avatar,
	Typography,
	Tooltip,
	Stack,
	TextField,
	Divider,
	FormControl,
	InputLabel,
	Select,
	MenuItem,
	Grid,
	IconButton,
	Paper,
} from '@mui/material'
import { Box } from '@mui/system'
import { useFormik } from 'formik'
import api from 'src/Api'

import React, { useEffect, useState } from 'react'
import * as Yup from 'yup'
import { ToastContainer, toast } from 'react-toastify'
import AddExperience from '../../profiles/AddExperience'
import AddRefrence from '../../profiles/AddRefrence'

export default function Step4({ user, setUnVerifiedSteps }) {
	const [openRef, setOpenAddRef] = useState(false)
	const [references, setReferences] = useState([...user?.references])

	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const deleteReference = id => {
		// Headers

		api.post('/users/delete_reference/' + user?._id, { id })
			.then(res => {
				setUnVerifiedSteps([...res.data.unverified_steps])
				setReferences([...res.data.references])
			})
			.catch(err => {})
	}
	useEffect(() => {}, [])
	return (
		<Box>
			<Stack spacing={1}>
				<Typography variant="subtitle2">Références </Typography>
				{references?.length < 2 && (
					<Typography color={'error'} variant="body2">
						Veuillez ajouter des Références
					</Typography>
				)}
				<Stack direction={'row'} spacing={1} flexWrap="wrap">
					{references?.map(item => (
						<Paper variant="outlined" sx={{ background: '#919eab3d' }}>
							<Stack
								direction={'row'}
								sx={{ ml: 1, p: 1 }}
								spacing={1}
								alignItems={'center'}
							>
								<Typography variant="body2">{item.name}</Typography>

								<IconButton onClick={() => deleteReference(item._id)}>
									<Close />
								</IconButton>
							</Stack>
						</Paper>
					))}
				</Stack>
				<Box sx={{ display: 'flex', justifyContent: 'end' }}>
					<Button
						onClick={() => setOpenAddRef(true)}
						sx={{ minWidth: 220, textTransform: 'none' }}
						variant="contained"
					>
						Ajouter une référence
					</Button>
				</Box>
			</Stack>

			{openRef && (
				<AddRefrence
					openAdd={openRef}
					handleCloseAdd={() => setOpenAddRef(false)}
					setUser={user => {
						setUnVerifiedSteps([...user?.unverified_steps])
						setReferences([...user?.references])
					}}
					showSuccess={showSuccess}
					showError={showError}
					user={user}
				/>
			)}
		</Box>
	)
}
