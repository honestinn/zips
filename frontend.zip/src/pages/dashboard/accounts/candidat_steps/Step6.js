import { Save } from "@mui/icons-material";
import { LoadingButton } from "@mui/lab";
import {
  Button,
  Typography,
  Stack,
  TextField,
  CircularProgress,
  Autocomplete,
  Grid,
} from "@mui/material";
import { Box } from "@mui/system";
import { useFormik } from "formik";
import api from "src/Api";
import React, { useEffect, useState } from "react";
import * as Yup from "yup";
import { ToastContainer, toast } from "react-toastify";

export default function Step6({ user, setUnVerifiedSteps, setUser }) {
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [addresses, setAddresses] = useState([]);
  const timeoutDuration = 3000; // 3 seconds
  let typingTimeout = null;

  const formik = useFormik({
    initialValues: {
      address: user?.address || "",
      postal_code: user?.postal_code || "",
      city: user?.city || "",
      address2: user?.address2 || "",
      state: user?.state || "",
      location: user?.location || null,
    },
    validationSchema: Yup.object().shape({
      address: Yup.string().required("Adresse est obligatoire *"),
      address2: Yup.string(),
      state: Yup.string(),
      postal_code: Yup.string()
        .required("Code postal est obligatoire *")
        .matches(/^\d{5}$/, "Le code postal doit contenir 5 chiffres"),
      city: Yup.string().required("Ville est obligatoire *"),
    }),
    enableReinitialize: true,
    onSubmit: async (values, helpers) => {
      try {
        submit(values);
      } catch (err) {
        console.error(err);
        helpers.setStatus({ success: false });
        helpers.setErrors({ submit: err.message });
        helpers.setSubmitting(false);
      }
    },
  });

  const submit = (body) => {
    setSubmitting(true);
    api
      .post("/users/submit_step", { ...body, step: 6 })
      .then((res) => {
        setUnVerifiedSteps(res.data.unverified_steps);
        setSubmitting(false);
        showSuccess("Opération réussie");
      })
      .catch((err) => {
        console.log(err);
        setSubmitting(false);
        showError("Quelque chose ne va pas");
      });
  };

  const showError = (msg) => {
    toast.error(msg, {
      position: "bottom-center",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
    });
  };

  const showSuccess = (msg) => {
    toast.success(msg, {
      position: "bottom-right",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
    });
  };

  const autocomplete = (text) => {
    setLoading(true);
    api
      .get("/users/city_autocomplete?text=" + text)
      .then((res) => {
        setAddresses(res.data); // Assumes data contains address, zip_codes, and city
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  };

  const handleKeyUp = (event) => {
    clearTimeout(typingTimeout); // Reset the timer on each keyup

    if (event.key === "Enter") {
      autocomplete(formik.values.address); // Trigger on Enter
    } else {
      typingTimeout = setTimeout(() => {
        autocomplete(formik.values.address); // Trigger after 3 seconds of inactivity
      }, timeoutDuration);
    }
  };

  useEffect(() => {
    // Clear timeout if component is unmounted to avoid memory leaks
    console.log(addresses);
    return () => clearTimeout(typingTimeout);
  }, []);

  return (
    <Box>
      <form autoComplete="off" noValidate onSubmit={formik.handleSubmit}>
        <Stack spacing={2}>
          <Autocomplete
            freeSolo
            options={addresses}
            getOptionLabel={(option) => option.address || ""}
            loading={loading}
            value={
              addresses.find(
                (address) => address.address === formik.values.address
              ) || null
            } // Set the initial value
            isOptionEqualToValue={(option, value) => option.address === value} // Compare options
            onChange={(event, newValue) => {
              if (newValue) {
                // Set the address, postal code, and city
                formik.setFieldValue("address", newValue.address); // Set only address
                formik.setFieldValue("postal_code", newValue.zip_codes); // Set the postal code
                formik.setFieldValue("city", newValue.city); // Set the city directly
                formik.setFieldValue("state", newValue.state);
                formik.setFieldValue("location", newValue.location);
              }
            }}
            renderOption={(props, option) => (
              <Box component="li" {...props}>
                {/* Afficher le label, le code et le téléphone */}
                <Typography variant="body2">
                  {option.label}, {option.state}, France&nbsp;
                </Typography>

                {/* Ajoute une image si nécessaire */}
                {/* <img src={option.img} alt={option.label} style={{ width: 20, height: 20 }} /> */}
              </Box>
            )}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Adresse*"
                variant="outlined"
                name="address"
                error={Boolean(formik.touched.address && formik.errors.address)}
                helperText={formik.touched.address && formik.errors.address}
                onChange={(e) => {
                  formik.setFieldValue("address", e.target.value); // Keep current input
                }}
                value={formik.values.address} // Correctly set the input value
                onKeyUp={handleKeyUp}
              />
            )}
          />
          <TextField
            fullWidth
            type="text"
            disabled={formik.values.address == ""}
            name="address2"
            label="Complément d'adresse (Facultatif)"
            onChange={formik.handleChange}
            value={formik.values.address2}
            error={Boolean(formik.touched.address2 && formik.errors.address2)}
            helperText={formik.touched.address2 && formik.errors.address2}
          />

          <TextField
            fullWidth
            type="text"
            name="postal_code"
            label="Code Postal*"
            onChange={formik.handleChange}
            value={formik.values.postal_code}
            error={Boolean(
              formik.touched.postal_code && formik.errors.postal_code
            )}
            helperText={formik.touched.postal_code && formik.errors.postal_code}
            InputProps={{
              readOnly: true, // Make this input non-editable
            }}
          />

          <Grid container spacing={0}>
            {" "}
            {/* Supprimez le spacing ici pour éviter un espacement supplémentaire */}
            <Grid item xs={12} md={6}>
              <Box sx={{ mr: 2 }}>
                {" "}
                {/* Utilisez un Box pour le margin-right */}
                <TextField
                  fullWidth
                  type="text"
                  name="city"
                  label="Ville*"
                  onChange={formik.handleChange}
                  value={formik.values.city}
                  error={Boolean(formik.touched.city && formik.errors.city)}
                  helperText={formik.touched.city && formik.errors.city}
                  InputProps={{
                    readOnly: true, // Make this input non-editable
                  }}
                />
              </Box>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                type="text"
                name="state"
                label="Région*"
                onChange={formik.handleChange}
                value={formik.values.state}
                error={Boolean(formik.touched.state && formik.errors.state)}
                helperText={formik.touched.state && formik.errors.state}
                InputProps={{
                  readOnly: true, // Make this input non-editable
                }}
              />
            </Grid>
          </Grid>

          <LoadingButton
            type="submit"
            startIcon={<Save />}
            variant="contained"
            loading={submitting}
          >
            Sauvegarder
          </LoadingButton>
        </Stack>
      </form>
      <ToastContainer
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </Box>
  );
}
