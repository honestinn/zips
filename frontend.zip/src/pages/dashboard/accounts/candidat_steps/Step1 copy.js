import { Edit, Save, Upload } from '@mui/icons-material'
import { Button, Avatar, Typography, Tooltip, Stack, TextField } from '@mui/material'
import { Box } from '@mui/system'

import React, { useState } from 'react'
import ReactImageUploading from 'react-images-uploading'
import { next } from 'stylis'
import api, { FILES_URL } from 'src/Api'
import { ToastContainer, toast } from 'react-toastify'
import Image from 'src/components/Image'

export default function Step1({ user, nextStep, setUnVerifiedSteps, setUser }) {
	const [picture, setPicture] = useState([])
	const onPictureChange = (imageList, addUpdateIndex) => {
		// data for submit
		setPicture(imageList)
	}
	console.log( FILES_URL + user.avatar);
	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}

	const submit = () => {
		const config = {
			headers: {
				'content-type': 'multipart/form-data',
			},
		}
		let body = new FormData()

		body.append('picture', picture[0]?.file)
		body.append('step', 1)

		api.post('/users/submit_step', body, config)
			.then(res => {
				setUser(res.data)
				setUnVerifiedSteps(res.data.unverified_steps)
				showSuccess('Opération réussie')
			})
			.catch(err => {
				showError('Quelque chose ne va pas')
			})
	}

	return (
		<>
			<Stack spacing={1} sx={{ display: 'flex', alignItems: 'center' }}>
				<ReactImageUploading
					multiple
					value={picture}
					onChange={onPictureChange}
					maxNumber={1}
					dataURLKey="data_url"
					acceptType={['jpg', 'png', 'jpeg']}
				>
					{({
						imageList,
						onImageUpload,
						onImageRemoveAll,
						onImageUpdate,
						onImageRemove,
						isDragging,
						dragProps,
					}) => (
						<>
							<Box
								sx={{
									display: 'flex',
									justifyContent: 'center',
									alignItems: 'center',

									width: 250,
									height: 250,
									p: 1,
								}}
							>
								{imageList.length == 0 && (
									<Image
										src={
											user?.avatar.length > 0
												? FILES_URL + user.avatar
												: '/statics/image-placeholder.png'
										}
									/>
								)}

								{imageList.map((image, index) => (
									<Image src={image.data_url} />
								))}
							</Box>

							<Tooltip title="Choisir une photo qui représente bien votre société">
								<Button
									sx={{
										backgound: isDragging && 'red',
										textTransform: 'none',
									}}
									variant="outlined"
									onClick={
										imageList.length > 0
											? () => onImageUpdate(0)
											: onImageUpload
									}
									startIcon={<Upload />}
								>
									Choisir une image
								</Button>
							</Tooltip>
						</>
					)}
				</ReactImageUploading>

				<Typography gutterBottom variant="h5">
					{user.name}
				</Typography>
				<Typography color="text.secondary" variant="body2">
					{user.email}
				</Typography>
				<Typography color="text.secondary" variant="body2">
					{user.phone}
				</Typography>
				<Typography color="subtitle2" variant="body2"></Typography>
				<Button
					disabled={!picture[0]?.file && !user.avatar.length}
					variant="contained"
					startIcon={<Save />}
					onClick={submit}
				>
					Sauvgarder
				</Button>
			</Stack>
			<ToastContainer
				autoClose={3000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
			/>
		</>
	)
}
