import { Close, Edit, Save, Upload } from '@mui/icons-material'
import { LoadingButton } from '@mui/lab'
import {
	Button,
	Avatar,
	Typography,
	Tooltip,
	Stack,
	TextField,
	Divider,
	FormControl,
	InputLabel,
	Select,
	MenuItem,
	Grid,
	IconButton,
	Paper,
} from '@mui/material'
import { Box } from '@mui/system'
import { useFormik } from 'formik'
import api from 'src/Api'

import React, { useEffect, useState } from 'react'
import * as Yup from 'yup'
import { ToastContainer, toast } from 'react-toastify'
import AddExperience from '../../profiles/AddExperience'
import moment from 'moment'

export default function Step3({ user, setUnVerifiedSteps }) {
	const [submitting, setSubmitting] = useState(false)
	const [openExp, setOpenAddExp] = useState(false)
	const [experiences, setExperiences] = useState([...user.experiences])
	const deleteExperience = id => {
		// Headers

		api.post('/users/delete_experience/' + user._id, { id })
			.then(res => {
				setUnVerifiedSteps([...res.data.unverified_steps])
				setExperiences([...res.data.experiences])
			})
			.catch(err => {})
	}

	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	useEffect(() => {}, [])
	
	return (
		<Box>
			<Stack spacing={1}>
				<Typography variant="h6">Expérience </Typography>
				<Typography variant="subtitle2">Métier(s) </Typography>
				{experiences.length >= 2 && (
					<Typography color={'success'} sx={{ color: 'green' }} variant="body2">
						Vous pouvez passer à l'étape suivante.
					</Typography>
				)}
				{experiences.length < 2 && (
					<Typography color={'error'} variant="body2">
						Veuillez ajouter des métiers
					</Typography>
				)}
				<Stack direction={'row'} spacing={1} flexWrap="wrap">
					{experiences.map(item => (
						<Paper variant="outlined" sx={{ background: '#919eab3d' }}>
							<Stack direction={'row'} sx={{ ml: 1, p: 1 }} spacing={1}>
								<Box>
									<Typography variant="body2">{item.job?.name}</Typography>
									<Typography variant="body2" color="text.secondary">
										{moment(item.start_date).format('DD-MM-YYYY') +
											'/' +
											moment(item.end_date).format('DD-MM-YYYY')}
									</Typography>
								</Box>
								<IconButton onClick={() => deleteExperience(item._id)}>
									<Close />
								</IconButton>
							</Stack>
						</Paper>
					))}
				</Stack>
				<Box sx={{ display: 'flex', justifyContent: 'end' }}>
					<Button
						onClick={() => setOpenAddExp(true)}
						sx={{ minWidth: 220, textTransform: 'none' }}
						variant="contained"
					>
						Ajouter un métier
					</Button>
				</Box>
			</Stack>
			{openExp && (
				<AddExperience
					openAdd={openExp}
					handleCloseAdd={() => setOpenAddExp(false)}
					setUser={user => {
						setUnVerifiedSteps([...user?.unverified_steps])
						setExperiences([...user?.experiences])
					}}
					showSuccess={showSuccess}
					showError={showError}
					user={user}
				/>
			)}
		</Box>
	)
}
