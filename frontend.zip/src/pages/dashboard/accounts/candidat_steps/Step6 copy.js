import { Edit, Save, Upload } from '@mui/icons-material'
import { LoadingButton } from '@mui/lab'
import {
	Button,
	Avatar,
	Typography,
	Tooltip,
	Stack,
	TextField,
	Divider,
	FormControl,
	InputLabel,
	Select,
	MenuItem,
	Grid,
	Autocomplete,
	CircularProgress,
} from '@mui/material'
import { Box } from '@mui/system'
import { useFormik } from 'formik'
import api from 'src/Api'

import React, { useEffect, useState } from 'react'
import * as Yup from 'yup'
import { ToastContainer, toast } from 'react-toastify'
export default function Step6({ user, setUnVerifiedSteps, setUser }) {
	const [loading, setLoading] = useState(false)
	const [submitting, setSubmitting] = useState(false)
	const [cities, setCities] = useState([])

	const formik = useFormik({
		initialValues: {
			city: '',
			selectedCity: null,
			postal_code: '',
			address: '',
			address2: '',
		},
		validationSchema: Yup.object().shape({
			address: Yup.string().required('Adresse est obligatoire *'),
			address2: Yup.string(),
			postal_code: Yup.string()
				.required('code postal est obligatoire *')
				.test(
					'is-valid-postal-code',
					'Le code postal doit commencer par le code de la ville sélectionnée et contenir 5 chiffres',
					function (value) {
						const { selectedCity } = this.parent
						if (!selectedCity || !selectedCity.city_code || !value) return false
						const cityCode = selectedCity.city_code
						const postalCodePattern = new RegExp(
							`^${cityCode}\\d{${5 - cityCode.length}}$`
						)
						return (
							postalCodePattern.test(value) && selectedCity.zip_codes.includes(value)
						)
					}
				),
			city: Yup.string(),
			selectedCity: Yup.object()
				.shape({
					city: Yup.string().required('ville est obligatoire *'),
				})
				.nullable()
				.required('ville est obligatoire *'),
		}),
		enableReinitialize: true,
		onSubmit: async (values, helpers) => {
			try {
				// console.log(values)
				submit(values)
			} catch (err) {
				console.error(err)
				helpers.setStatus({ success: false })
				helpers.setErrors({ submit: err.message })
				helpers.setSubmitting(false)
			}
		},
	})

	const submit = body => {
		setSubmitting(true)
		api.post('/users/submit_step', { ...body, step: 6 })
			.then(res => {
				setUnVerifiedSteps(res.data.unverified_steps)
				setSubmitting(false)
				showSuccess('Opération réussie')
			})
			.catch(err => {
				console.log(err)
				setSubmitting(false)
				showError('Quelque chose ne va pas')
			})
	}
	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const autocomplete = text => {
		setLoading(true)
		api.get('/users/city_autocomplete?text=' + text)
			.then(res => {
				setCities(res.data)

				setLoading(false)
			})
			.catch(err => {
				setLoading(false)
			})
	}

	useEffect(() => {
		autocomplete(formik.values.city)
	}, [formik.values.city])
	return (
		<Box>
			{/* <Typography color={'error'} sx={{ my: 1 }}>
				{!user.valid_siret && "Le numéro SIREN n'est pas valide"}
			</Typography> */}
			<form autoComplete="off" noValidate onSubmit={formik.handleSubmit}>
				<Stack sx={{ minWidth: 700 }} spacing={2}>
					<Autocomplete
						autoComplete={false}
						freeSolo
						options={cities}
						getOptionLabel={option =>
							option?.city_code + '. ' + option?.city //+' . ' + option?.state
						}
						loading={loading}
						inputValue={formik.values.city}
						onInputChange={(event, newInputValue) => {
							if (
								formik.values.selectedCity &&
								newInputValue !== formik.values.selectedCity.name
							) {
								formik.setFieldValue('selectedCity', null)
								formik.setFieldValue('city', '')
							} else {
								formik.setFieldValue('city', newInputValue)
							}
						}}
						value={formik.values.selectedCity}
						onChange={(event, newValue) => {
							formik.setFieldValue('selectedCity', newValue)
							console.log(newValue)
						}}
						renderInput={params => (
							<TextField
								{...params}
								label="Ville"
								variant="outlined"
								error={
									formik.touched.selectedCity &&
									Boolean(formik.errors.selectedCity)
								}
								helperText={
									formik.touched.selectedCity && formik.errors.selectedCity
								}
								InputProps={{
									...params.InputProps,
									endAdornment: (
										<>
											{loading ? (
												<CircularProgress color="inherit" size={20} />
											) : null}
											{params.InputProps.endAdornment}
										</>
									),
								}}
							/>
						)}
					/>

					<TextField
						fullWidth
						type="text"
						disabled={formik.values.selectedCity == null}
						name="postal_code"
						label="code postal"
						onChange={formik.handleChange}
						value={formik.values.postal_code}
						error={Boolean(formik.touched.postal_code && formik.errors.postal_code)}
						helperText={formik.touched.postal_code && formik.errors.postal_code}
					/>

					<TextField
						fullWidth
						autoComplete="address"
						type="text"
						name="address"
						disabled={formik.values.selectedCity == null}
						label="Adresse*"
						onChange={formik.handleChange}
						value={formik.values.address}
						error={Boolean(formik.touched.address && formik.errors.address)}
						helperText={formik.touched.address && formik.errors.address}
					/>

					<TextField
						fullWidth
						type="text"
						disabled={formik.values.selectedCity == null}
						name="address2"
						label="Complément d'adresse (Facultatif)"
						onChange={formik.handleChange}
						value={formik.values.address2}
						error={Boolean(formik.touched.address2 && formik.errors.address2)}
						helperText={formik.touched.address2 && formik.errors.address2}
					/>

					<LoadingButton
						type="submit"
						startIcon={<Save />}
						// loading={submitting}
						variant="contained"
					>
						Sauvgarder
					</LoadingButton>
				</Stack>
			</form>
			<ToastContainer
				autoClose={3000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
			/>
		</Box>
	)
}
