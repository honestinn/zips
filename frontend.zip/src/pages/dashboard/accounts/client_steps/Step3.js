import { Check, CheckCircle, Close, Edit, PostAdd, Save, Upload } from '@mui/icons-material'
import { LoadingButton } from '@mui/lab'
import {
	Button,
	Avatar,
	Typography,
	Tooltip,
	Stack,
	TextField,
	Divider,
	FormControl,
	InputLabel,
	Select,
	MenuItem,
	Grid,
	Paper,
	IconButton,
} from '@mui/material'

import { Link as MuiLink } from '@mui/material'
import { Box } from '@mui/system'
import { useFormik } from 'formik'
import api, { FILES_URL } from 'src/Api'

import React, { useEffect, useState } from 'react'
import * as Yup from 'yup'
import { ToastContainer, toast } from 'react-toastify'
import ReactImageUploading from 'react-images-uploading'
import { File } from 'react-feather'
import { APP_URL } from 'src/config'

export default function Step3({ user, setUnVerifiedSteps }) {
	const [submitting, setSubmitting] = useState(false)
	const [files, setFiles] = useState(
		user?.documents.map(e => {
			return { ...e, file: null }
		}) ?? []
	)
	const [uploadingFiles, setUploadingFiles] = useState(false)

	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const handleFileChange = (event, id) => {
		const newFiles = [...files.filter(e => e.id !== id)]
		let tmp = files.find(e => e.id == id)

		tmp.file = event.target.files[0]

		setFiles([...newFiles, tmp])
	}
	const submitFiles = (event, id) => {
		// setUploadingFiles(true)
		const config = {
			headers: {
				'content-type': 'multipart/form-data',
			},
		}
		// let invalid = false
		let invalid = false

		if (invalid) showError('Veuillez fournir les documents qui sont obligatoires')
		else {
			const body = new FormData()

			files.forEach(doc => {
				body.append(`file${doc.id}`, doc.file)
			})

			// console.log(body)

			api.post('/users/submit_docs', body, config)
				.then(res => {
					toast.success('Modification réussie. Vos changements ont été enregistrés avec succès.', {
						position: 'bottom-center',
						autoClose: 3000,
						hideProgressBar: false,
						closeOnClick: true,
						pauseOnHover: true,
						draggable: true,
						progress: undefined,
					})

					setUnVerifiedSteps(res.data.unverified_steps)
				})
				.catch(err => {
					toast.error('Erreur', {
						position: 'bottom-center',
						autoClose: 3000,
						hideProgressBar: false,
						closeOnClick: true,
						pauseOnHover: true,
						draggable: true,
						progress: undefined,
					})
				})
		}
	}
	useEffect(() => {}, [])
	return (
		<>
			<Stack spacing={1} sx={{ minWidth: 700, p: 1 }}>
				<Typography variant="subtitle2">Exige les documents ci-dessous </Typography>

				{files
					.sort((a, b) => a.id - b.id)
					.map(doc => (
						<>
							{doc.status == true && (
								<Paper variant="outlined" sx={{ display: 'flex' }}>
									<Stack direction={'row'} alignItems="center" spacing={2}>
										{doc.is_valid == true && (
											<CheckCircle
												sx={{ mx: 1, fontSize: '15px', color: 'green' }}
											/>
										)}

										{doc.is_valid == false && (
											<Box sx={{ m: 1 }}>
												<img
													src="/statics/undraw_add_files_re_v09g.svg"
													alt=""
													style={{
														maxWidth: '50px',
														maxHeight: '50px',
													}}
												/>
											</Box>
										)}
										<Stack>
											<Typography variant="body2">{doc.name}</Typography>
											{doc.file ? (
												<MuiLink
													href={URL.createObjectURL(doc.file)}
													target="_blank"
													rel="noopener noreferrer"
													color="inherit"
												>
													<Typography
														sx={{
															color: 'blue',
															textDecoration: 'underline',
														}}
														variant="caption"
													>
														{doc.file && doc.file.name}
													</Typography>
												</MuiLink>
											) : (
												doc.path.length > 0 && (
													<MuiLink
														href={FILES_URL + doc.path}
														target="_blank"
														rel="noopener noreferrer"
														color="inherit"
													>
														<Typography
															sx={{
																color: 'blue',
																textDecoration: 'underline',
															}}
															variant="caption"
														>
															consulter le document ..
														</Typography>
													</MuiLink>
												)
											)}
										</Stack>
										{doc.is_valid == false && (
											<>
												<input
													type="file"
													id={'file' + doc?.id}
													style={{ display: 'none' }}
													accept={doc?.types.map(e => '.' + e).join(', ')}
													onChange={event =>
														handleFileChange(event, doc?.id)
													}
												/>
												<label htmlFor={'file' + doc?.id}>
													<Button
														sx={{
															textTransform: 'none',
														}}
														variant="text"
														component="span"
														size="small"
														startIcon={<PostAdd />}
													>
														<Typography variant="caption">
															Choisir une fichier(
															{doc.types.join(',')})
														</Typography>
													</Button>
												</label>
											</>
										)}
									</Stack>
								</Paper>
							)}
						</>
					))}

				<LoadingButton
					sx={{ width: 200, alignSelf: 'end' }}
					size="miduim"
					onClick={submitFiles}
					variant="contained"
					loading={uploadingFiles}
				>
					sauvgarder
				</LoadingButton>
			</Stack>

			<ToastContainer
				autoClose={3000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
			/>
		</>
	)
}
