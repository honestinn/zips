import { Edit, Save, Upload } from '@mui/icons-material'
import { LoadingButton } from '@mui/lab'
import {
    Button,
    Avatar,
    Typography,
    Tooltip,
    Stack,
    TextField,
    Divider,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Grid,
} from '@mui/material'
import { Box } from '@mui/system'
import { useFormik } from 'formik'
import api from 'src/Api'
import React, { useEffect, useState } from 'react'
import * as Yup from 'yup'
import { ToastContainer, toast } from 'react-toastify'

export default function Step2({ user, setUnVerifiedSteps }) {
    const [submitting, setSubmitting] = useState(false)
    const [categories, setCategories] = useState([])

    const formik = useFormik({
        initialValues: {
            description: user?.description || '',
            iban: user?.iban || '',
            siret: user?.siret ?? '',
            company_name: user?.company_name || '',
            category: user?.category ?? '',
        },
        validationSchema: Yup.object().shape({
            company_name: Yup.string()
                .matches(
                    /^[a-zA-ZàâäéèêëîïôöùûüçÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ\s'-.]+(?:\s[a-zA-ZàâäéèêëîïôöùûüçÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ'-.]+)*$/,
                    "Le nom de l'entreprise doit contenir uniquement des lettres, des espaces et éventuellement des caractères spéciaux"
                )
                .required('Ce champ est obligatoire *'),
            siret: Yup.string()
                .matches(/^\d{9}(\d{5})?$/, 'Le SIRET ou le SIREN doit contenir exactement 9 ou 14 chiffres')
                .required('Ce champ est obligatoire *'),
            iban: Yup.string()
              //  .matches(/^FR\d{2}\s?\d{5}\s?\d{5}\s?\d{11}[a-zA-Z0-9]{2}$/, 'IBAN invalide')
                .required('Ce champ est obligatoire *'),
            category: Yup.string().required('ce champ est obligatoire *'),
        }),
        enableReinitialize: true,
        onSubmit: async (values, helpers) => {
			// Vérifiez la validité de l'IBAN avant de soumettre
			const isIbanValid = await checkIbanValidity(values.iban);
			if (!isIbanValid) {
				helpers.setSubmitting(false);
				showError('L\'IBAN que vous avez saisi n\'est pas valide.')
				formik.setFieldValue('iban', user.iban)
				return; // Arrêtez le processus de soumission si l'IBAN n'est pas valide
			}
            try {
                submit(values)
            } catch (err) {
                console.error(err)
                helpers.setStatus({ success: false })
                helpers.setErrors({ submit: err.message })
                helpers.setSubmitting(false)
            }
        },
    })

    const submit = body => {
        setSubmitting(true)
        api.post('/users/submit_step', { ...body, step: 2 })
            .then(res => {
                setUnVerifiedSteps(res.data.unverified_steps)
                setSubmitting(false)
                showSuccess('Opération réussie')
            })
            .catch(err => {
                setSubmitting(false)
                showError('Quelque chose ne va pas')
            })
    }

    const showError = msg => {
        toast.error(msg, {
            position: 'bottom-center',
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        })
    }

    const showSuccess = msg => {
        toast.success(msg, {
            position: 'bottom-center',
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        })
    }

    const getCategories = () => {
        api.get('/admin/get_jobs_categories')
            .then(res => {
                setCategories(res.data)
				console.log(res.data)
            })
            .catch(err => {})
    }

    // Fonction pour récupérer le nom de l'entreprise
    const fetchCompanyName = async (siret) => {
        try {
            const response = await api.get(`/users/get_company_infos/${siret}`); // Modifiez ce chemin selon votre API
            if (response.data) {	
				formik.setFieldValue('company_name', response.data.etablissement.uniteLegale.denominationUniteLegale);	
            }
			//showSuccess("Le nom de l'entreprise est " + response.data.etablissement.uniteLegale.denominationUniteLegale)
        } catch (error) {
			if (siret.length === 9) {
				formik.setFieldError('siret', "Le SIREN est invalide."); // Set error for SIREN
			} else if (siret.length === 14) {
				formik.setFieldError('siret', "Le SIRET est invalide."); // Set error for SIRET
			}
		}
    }

    useEffect(() => {
        getCategories()
    }, [])

    // Gestion de la saisie du SIRET/SIREN
	const handleSiretChange = (event) => {
		const { value } = event.target;
		// Supprimer les espaces du SIRET/SIREN
		const sanitizedValue = value.replace(/\s+/g, '');
		formik.setFieldValue('siret', sanitizedValue);
		if (sanitizedValue.length === 9 || sanitizedValue.length === 14) {
			fetchCompanyName(sanitizedValue); // Récupérer le nom de l'entreprise lorsque le SIRET/SIREN est valide
		}else{
			formik.setFieldValue('company_name', '')
		}
	}

	const checkIbanValidity = async (iban) => {
		try {
			const response = await api.get(`/users/get_iban_infos/${iban}`); // Modifiez ce chemin selon votre API
			return response.data.valid; // Supposons que votre API retourne un champ "valide"
		} catch (error) {
			showError('Erreur lors de la vérification de l\'IBAN');
			return false; // Si l'appel échoue, considérez que l'IBAN n'est pas valide
		}
	};


	return (
		<Box>
			<form autoComplete="off" noValidate onSubmit={formik.handleSubmit}>
				<Stack sx={{ minWidth: 700 }} spacing={2}>
					{/* Champ SIRET en haut sur toute la ligne */}
					<TextField
						size="small"
						fullWidth
						type="text"
						name="siret"
						label="SIRET ou SIREN"
						onChange={handleSiretChange} // Utilisation du nouveau gestionnaire
						onBlur={formik.handleBlur}
						value={formik.values.siret}
						error={Boolean(formik.touched.siret && formik.errors.siret)}
						helperText={formik.touched.siret && formik.errors.siret}
					/>
	
					{/* Ligne pour le nom de l'entreprise et l'IBAN */}
					<Grid container spacing={1}>
						<Grid item sx={12} md={6} lg={6}>
							<TextField
								size="small"
								fullWidth
								autoComplete="company_name"
								type="text"
								name="company_name"
								label="Nom de l'entreprise ou société"
								onChange={formik.handleChange}
								onBlur={formik.handleBlur}
								value={formik.values.company_name}
								error={Boolean(formik.touched.company_name && formik.errors.company_name)}
								helperText={formik.touched.company_name && formik.errors.company_name}
								InputProps={{ readOnly: true }}
							/>
						</Grid>
						<Grid item sx={12} md={6} lg={6}>
							<TextField
								size="small"
								fullWidth
								type="text"
								name="iban"
								label="IBAN"
								onChange={formik.handleChange}
								onBlur={formik.handleBlur}
								value={formik.values.iban}
								error={Boolean(formik.touched.iban && formik.errors.iban)}
								helperText={formik.touched.iban && formik.errors.iban}
							/>
						</Grid>
					</Grid>
	
					{/* Champ Description en bas */}
					<TextField
						fullWidth
						multiline
						size="small"
						type="text"
						rows={2}
						name="description"
						label="Description (facultatif)"
						onChange={formik.handleChange}
						onBlur={formik.handleBlur}
						value={formik.values.description}
						error={Boolean(formik.touched.description && formik.errors.description)}
						helperText={formik.touched.description && formik.errors.description}
					/>
	
					<Divider />
					<Typography variant="h4">Services fournis: </Typography>
					<Typography variant="caption">Choisissez votre service principal :</Typography>
					<FormControl fullWidth>
						<InputLabel id="demo-simple-select-label">Catégorie</InputLabel>
						<Select
							labelId="demo-simple-select-label"
							id="demo-simple-select"
							size="small"
							value={formik.values.category}
							label="Catégorie"
							name="category"
							onChange={formik.handleChange}
							error={Boolean(formik.touched.category && formik.errors.category)}
							helperText={formik.touched.category && formik.errors.category}
						>
							{categories.length > 0 &&
								categories.map(e => <MenuItem key={e._id} value={e._id}>{e.name}</MenuItem>)}
						</Select>
					</FormControl>
	
					<LoadingButton
						type="submit"
						startIcon={<Save />}
						loading={submitting}
						variant="contained"
					>
						Sauvegarder
					</LoadingButton>
				</Stack>
			</form>
			<ToastContainer
				autoClose={3000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
			/>
		</Box>
	)
	
}
