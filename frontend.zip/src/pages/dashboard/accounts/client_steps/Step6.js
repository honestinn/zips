import { Save } from "@mui/icons-material";
import { LoadingButton } from "@mui/lab";
import { v4 as uuidv4 } from 'uuid';
import {
  Button,
  Typography,
  Stack,
  TextField,
  CircularProgress,
  Autocomplete,
  Grid,
} from "@mui/material";
import { Box } from "@mui/system";
import { useFormik } from "formik";
import api from "src/Api";
import React, { useEffect, useState, useCallback } from "react";
import * as Yup from "yup";
import { ToastContainer, toast } from "react-toastify";
import debounce from "lodash.debounce";

export default function Step6({ user, setUnVerifiedSteps, setUser }) {
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [addresses, setAddresses] = useState([]);

  const formik = useFormik({
    initialValues: {
      address: user?.address || "",
      postal_code: user?.postal_code || "",
      city: user?.city || "",
      address2: user?.address2 || "",
      state: user?.state || "",
      location: user?.location || null,
    },
    validationSchema: Yup.object().shape({
      address: Yup.string().required("Adresse est obligatoire *"),
      address2: Yup.string(),
      state: Yup.string(),
      postal_code: Yup.string()
        .required("Code postal est obligatoire *")
        .matches(/^\d{5}$/, "Le code postal doit contenir 5 chiffres"),
      city: Yup.string().required("Ville est obligatoire *"),
    }),
    enableReinitialize: true,
    onSubmit: async (values, helpers) => {
      try {
        await submit(values);
      } catch (err) {
        console.error(err);
        helpers.setStatus({ success: false });
        helpers.setErrors({ submit: err.message });
        helpers.setSubmitting(false);
      }
    },
  });

  const submit = async (body) => {
    setSubmitting(true);
    try {
      const res = await api.post("/users/submit_step", { ...body, step: 6 });
      setUnVerifiedSteps(res.data.unverified_steps);
      showSuccess("Opération réussie");
    } catch (err) {
      console.log(err);
      showError("Quelque chose ne va pas");
    } finally {
      setSubmitting(false);
    }
  };

  const showError = (msg) => {
    toast.error(msg, {
      position: "bottom-center",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
    });
  };

  const showSuccess = (msg) => {
    toast.success(msg, {
      position: "bottom-right",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
    });
  };

  const fetchAutocompleteAddresses = async (text) => {
    setLoading(true);
    try {
      const res = await api.get(`/users/city_autocomplete?text=${text}`);
      setAddresses(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const debouncedAutocomplete = useCallback(debounce((text) => {
    if (text.length >= 3) {
      fetchAutocompleteAddresses(text);
    }
  }, 500), []); // 300 ms de délai

  useEffect(() => {
    if (formik.values.address) {
      debouncedAutocomplete(formik.values.address);
    }
    // Cleanup function to cancel any pending debounce calls
    return () => {
      debouncedAutocomplete.cancel();
    };
  }, [formik.values.address, debouncedAutocomplete]);

  return (
    <Box>
      <form autoComplete="off" noValidate onSubmit={formik.handleSubmit}>
        <Stack spacing={2}>
          <Autocomplete
            freeSolo
            options={addresses}
            getOptionLabel={(option) => option.address || ""}
            loading={loading}
            value={addresses.find(address => address.address === formik.values.address) || null}
            isOptionEqualToValue={(option, value) => option.address === value}
            onChange={(event, newValue) => {
              if (newValue) {
                formik.setFieldValue("address", newValue.address);
                formik.setFieldValue("postal_code", newValue.zip_codes);
                formik.setFieldValue("city", newValue.city);
                formik.setFieldValue("state", newValue.state);
                formik.setFieldValue("location", newValue.location);
              }
            }}
            renderOption={(props, option) => (
              <Box component="li" {...props} key={uuidv4()}>
                <Typography variant="body2">
                  {option.address}, {option.zip_codes} {option.city}, {option.state}, France
                </Typography>
              </Box>
            )}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Adresse*"
                variant="outlined"
                name="address"
                error={Boolean(formik.touched.address && formik.errors.address)}
                helperText={formik.touched.address && formik.errors.address}
                onChange={(e) => {
                  formik.setFieldValue("address", e.target.value);
                }}
                value={formik.values.address}
              />
            )}
          />
          <TextField
            fullWidth
            type="text"
            disabled={!formik.values.address}
            name="address2"
            label="Complément d'adresse (Facultatif)"
            onChange={formik.handleChange}
            value={formik.values.address2}
            error={Boolean(formik.touched.address2 && formik.errors.address2)}
            helperText={formik.touched.address2 && formik.errors.address2}
          />

          <TextField
            fullWidth
            type="text"
            name="postal_code"
            label="Code Postal*"
            onChange={formik.handleChange}
            value={formik.values.postal_code}
            error={Boolean(formik.touched.postal_code && formik.errors.postal_code)}
            helperText={formik.touched.postal_code && formik.errors.postal_code}
            InputProps={{
              readOnly: true,
            }}
          />

          <Grid container spacing={0}>
            <Grid item xs={12} md={6}>
              <Box sx={{ mr: 2 }}>
                <TextField
                  fullWidth
                  type="text"
                  name="city"
                  label="Ville*"
                  onChange={formik.handleChange}
                  value={formik.values.city}
                  error={Boolean(formik.touched.city && formik.errors.city)}
                  helperText={formik.touched.city && formik.errors.city}
                  InputProps={{
                    readOnly: true,
                  }}
                />
              </Box>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                type="text"
                name="state"
                label="Région*"
                onChange={formik.handleChange}
                value={formik.values.state}
                error={Boolean(formik.touched.state && formik.errors.state)}
                helperText={formik.touched.state && formik.errors.state}
                InputProps={{
                  readOnly: true,
                }}
              />
            </Grid>
          </Grid>

          <LoadingButton
            type="submit"
            startIcon={<Save />}
            variant="contained"
            loading={submitting}
          >
            Sauvegarder
          </LoadingButton>
        </Stack>
      </form>
      <ToastContainer
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </Box>
  );
}
