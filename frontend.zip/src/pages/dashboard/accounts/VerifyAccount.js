import { Refresh } from '@mui/icons-material'
import {
	Box,
	CircularProgress,
	IconButton,
	Stack,
	Typography,
	Paper,
	Divider,
	Button,
} from '@mui/material'
import { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import { toast, ToastContainer } from 'react-toastify'

import api from 'src/Api'
import { logout } from 'src/actions/auth'
import RouterLink from 'src/hooks/RouterLink'

import ClientStepper from './ClientStepper'
import CandidatStepper from './CandidatStepper'
import Logo from 'src/components/Logo'
export default function VerifyAccount({ children }) {
	const dispatch = useDispatch()
	const [user, setUser] = useState(null)
	const [loading, setLoading] = useState(false)
	const [cnxErr, setCnxErr] = useState(false)
	const [submitting, setSubmitting] = useState(false)
	const [next, setNext] = useState(null)

	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const submit = () => {
		setSubmitting(true)
		api.post('/users/resend_email')
			.then(res => {
				// setUnVerifiedSteps(res.data.unverified_steps)
				setNext(res.data?.next)
				// setSubmitting(false)
				if (res.data.sent) showSuccess('Opération réussie')
			})
			.catch(err => {
				setSubmitting(false)
				showError('Quelque chose ne va pas')
			})
	}
	const getUser = () => {
		// Headers
		setLoading(true)
		api.get('/users/get')
			.then(res => {
				setUser(res.data)
				setLoading(false)
			})
			.catch(err => {
				setCnxErr(true)
				setLoading(false)
			})
	}
	useEffect(() => {
		getUser()
	}, [])
	// useEffect(() => {}, [date])
	if (cnxErr) {
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '80vh',
				}}
			>
				<Stack
					spacing={2}
					display={'flex'}
					justifyContent="center"
					direction="column"
					alignItems="center"
				>
					<IconButton onClick={() => getUser()}>
						<Refresh />
					</IconButton>
					<Typography>probleme de connexion </Typography>
				</Stack>
			</Box>
		)
	}
	if (loading) {
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '80vh',
				}}
			>
				<Stack
					spacing={2}
					display={'flex'}
					justifyContent="center"
					direction="column"
					alignItems="center"
				>
					<CircularProgress />
					<Typography>Chargement</Typography>
				</Stack>
			</Box>
		)
	}
	if (!user?.valid_email) {
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '100vh',
				}}
			>
				<Paper variant="outlined" sx={{ minWidth: 700, maxWidth: 700, p: 2 }}>
					<Stack spacing={2}>
						<Stack direction="row" alignItems={'center'} justifyContent="space-between">
							<Logo sx={{ height: '100%', width: 200, mb: 2 }} />
							<Button
								sx={{ textTransform: 'none' }}
								onClick={() => dispatch(logout())}
							>
								Se déconnecter
							</Button>
						</Stack>
						<Divider />
						<Typography variant="subtitle1">Bonjour {user?.fname},</Typography>
						<>
							<Typography variant="subtitle2">
								L'adresse
								<u>
									<span
										style={{ marginInline: 5, color: 'black', fontWeight: 700 }}
									>
										<bold>{user?.email}</bold>
									</span>
								</u>
								n'est pas encore valide
							</Typography>

							<Typography variant="body2" sx={{ color: 'green' }}>
								Nous avons envoyé un lien de validation. Veuillez vérifier votre
								boîte de réception à cette adresse
								<span style={{ marginInline: 5, color: 'black', fontWeight: 700 }}>
									<bold>{user?.email}</bold>
								</span>
							</Typography>

							<Stack direction="row" spacing={0.2} alignItems={'center'}>
								<Typography variant="subtitle2">
									Si vous n'avez pas reçu l'e-mail, cliquez ici.
								</Typography>

								<CountdownTimer targetDate={next} submit={submit} next={next} />
							</Stack>
						</>
						<Box
							sx={{
								display: 'flex',
								justifyContent: 'end',
								width: '100%',
								m: 2,
								height: 100,
							}}
						>
							<img
								src="/statics/undraw_personal_email_re_4lx7.svg"
								style={{ maxHeight: '100%', maxWidth: '100%' }}
							/>
						</Box>
						<Button
							sx={{ textTransform: 'none' }}
							to="/"
							size="medium"
							variant="contained"
							component={RouterLink}
						>
							Accéder à la page d'accueil
						</Button>
					</Stack>
				</Paper>
				<ToastContainer
					autoClose={3000}
					hideProgressBar={false}
					newestOnTop={false}
					closeOnClick
					rtl={false}
					pauseOnFocusLoss
					draggable
					pauseOnHover
				/>
			</Box>
		)
	}
	if (!user?.active) {
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '100vh',
				}}
			>
				<Paper variant="outlined" sx={{ minWidth: 700, maxWidth: 700, p: 2 }}>
					<Stack spacing={2}>
						<Stack direction="row" alignItems={'center'} justifyContent="space-between">
							<Logo sx={{ height: '100%', width: 200, mb: 2 }} />
							<Button onClick={() => dispatch(logout())}>Se déconnecter</Button>
						</Stack>
						<Divider />
						<Typography color={'error'} variant="h6">
							Bonjour {user?.name},
						</Typography>
						<Typography>
							{user?.disactive_cause == 0 &&
								"Votre compte a été suspendu. Veuillez contacter l'administrateur pour obtenir plus d'informations"}
							{user?.disactive_cause == 1 &&
								"Votre compte a été suspendu en raison d'un nombre excessif d'annulations de missions. Veuillez contacter l'administrateur pour obtenir plus d'informations."}
						</Typography>
						<Box
							sx={{
								display: 'flex',
								justifyContent: 'center',
								width: '100%',
								m: 2,
								height: 300,
							}}
						>
							<img
								src="/statics/undraw_personal_email_re_4lx7.svg"
								style={{ maxHeight: '100%', maxWidth: '100%' }}
							/>
						</Box>
						<Button to="/" size="large" variant="contained" component={RouterLink}>
							Accéder à la page d'accueil
						</Button>
					</Stack>
				</Paper>
			</Box>
		)
	}

	if (!user?.unverified_steps?.includes(-1)) return children
	return (
		<Box
			sx={{
				display: 'flex',
				justifyContent: 'center',
				alignItems: 'center',
				minHeight: '100vh',
			}}
		>
			<Paper variant="outlined" sx={{ minWidth: 700, p: 2 }}>
				<Stack spacing={2}>
					<Stack direction="row" alignItems={'center'} justifyContent="space-between">
						<Logo sx={{ height: '100%', width: 200, mb: 2 }} />
						<Button onClick={() => dispatch(logout())}>Se déconnecter</Button>
					</Stack>
					<Typography variant="caption">
						Vous devez accomplir toutes les étapes pour vous connecter à la plateforme
					</Typography>

					{user?.role == 1 && <ClientStepper user={user} setUser={setUser} />}

					{user?.role == 2 && <CandidatStepper user={user} setUser={setUser} />}
					{/* {user?.role == 2 && <>{children}</>} */}
				</Stack>
			</Paper>
		</Box>
	)
}

const CountdownTimer = ({ targetDate, next, submit }) => {
	const calculateTimeLeft = () => {
		const difference = +new Date(targetDate) - +new Date()
		let timeLeft = {}

		if (difference > 0) {
			timeLeft = {
				days: Math.floor(difference / (1000 * 60 * 60 * 24)),
				hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
				minutes: Math.floor((difference / 1000 / 60) % 60),
				seconds: Math.floor((difference / 1000) % 60),
			}
		} else {
			timeLeft = { minutes: 0, seconds: 0 }
		}

		return timeLeft
	}

	const [timeLeft, setTimeLeft] = useState(calculateTimeLeft())

	useEffect(() => {
		const timer = setInterval(() => {
			setTimeLeft(calculateTimeLeft())
		}, 1000)

		return () => clearInterval(timer)
	}, [targetDate])

	const timerComponents = []

	Object.keys(timeLeft).forEach(interval => {
		if (!timeLeft[interval]) {
			return
		}

		timerComponents.push(
			<span key={interval}>
				{interval == 'minutes' ? timeLeft[interval] + ':' : timeLeft[interval] + 's'}
			</span>
		)
	})
	console.log(timerComponents.length)
	return (
		<div>
			<Button disabled={timerComponents.length} onClick={submit}>
				Renvoyer
			</Button>
			{timerComponents.length ? timerComponents : ''}
		</div>
	)
}
