import {
  Check,
  CheckCircle,
  Close,
  PostAdd,
  Refresh,
  Upload,
  Visibility,
  VisibilityOff,
  WifiOff,
} from "@mui/icons-material";
import { LoadingButton } from "@mui/lab";
import {
  Grid,
  Typography,
  Button,
  Box,
  Stack,
  TextField,
  Link,
  Divider,
  Autocomplete,
  InputAdornment,
  IconButton,
  Alert,
  MenuItem,
  FormControl,
  Select,
  FormHelperText,
  CircularProgress,
  Paper,
} from "@mui/material";
import axios from "axios";
import { useFormik } from "formik";
import { element } from "prop-types";
import React, { useState } from "react";
import { useEffect } from "react";
import ReactImageUploading from "react-images-uploading";
import { useDispatch, useSelector } from "react-redux";
import { Navigate } from "react-router";
import { countries } from "src/_mock/_countries";
import { logout, register } from "src/actions/auth";
import { toast, ToastContainer } from "react-toastify";
import { Link as MuiLink } from "@mui/material";
import { APP_URL } from "src/config";

import api, { FILES_URL } from "src/Api";
import RouterLink from "src/hooks/RouterLink";
import * as Yup from "yup";
export default function AccountExtra() {
  const auth = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const [user, setUser] = useState(null);
  const [error, setError] = useState("");
  const [idcardImg, setIdCardImg] = useState([]);
  const [passportImg, setPassportImg] = useState([]);
  const [files, setFiles] = useState([]);
  const [uploadingFiles, setUploadingFiles] = useState(false);
  const [loading, setLoading] = useState(false);
  const [editInfoLoading, setEditInfoLoading] = useState(false);
  const [editDocumentsLoading, setEditDocumentsLoading] = useState(false);
  const [cnxErr, setCnxErr] = useState(false);
  const onPassportChange = (imageList, addUpdateIndex) => {
    // data for submit
    setPassportImg(imageList);
  };
  const onIdCardChange = (imageList, addUpdateIndex) => {
    // data for submit
    setIdCardImg(imageList);
  };
  const formik = useFormik({
    enableReinitialize: true,
    initialValues: {
      dob: user?.dob.substring(0, 10) || "",
      address: user?.address || "",
      address2: user?.address2 || "",
    },
    validationSchema: Yup.object().shape({
      dob: Yup.string().required("Date de naissance est obligatoire *"),
      address: Yup.string().required("L'adresse est obligatoire *"),
      address2: Yup.string(),
    }),
    onSubmit: async (values, helpers) => {
      try {
        editInfo(values);
      } catch (err) {
        console.error(err);
        helpers.setStatus({ success: false });
        helpers.setErrors({ submit: err.message });
        helpers.setSubmitting(false);
      }
    },
  });
  const showError = (msg) => {
    toast.error(msg, {
      position: "bottom-center",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };
  const showSuccess = (msg) => {
    toast.success(msg, {
      position: "bottom-center",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };
  const getDocs = () => {
    // Headers
    api
      .get("/users/get_docs")
      .then((res) => {
        setFiles(
          res.data.map((e) => {
            return { ...e, file: null };
          }) ?? []
        );
      })
      .catch((err) => {});
  };

  useEffect(() => {
    getUser();
    getDocs();
  }, []);
  const getUser = () => {
    // Headers
    setLoading(true);
    api
      .get("/users/get")
      .then((res) => {
        if (res.data == null) dispatch(logout());

        setUser(res.data);
        setLoading(false);
      })
      .catch((err) => {
        setCnxErr(true);
        setLoading(false);
      });
  };
  const editInfo = (values) => {
    // Headers
    setEditInfoLoading(true);
    api
      .post("/users/edit_info/" + auth?.user.id, values)
      .then((res) => {
        toast.success(
          "Modification réussie. Vos changements ont été enregistrés avec succès.",
          {
            position: "bottom-center",
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          }
        );
        setEditInfoLoading(false);
      })
      .catch((err) => {
        toast.error("Erreur", {
          position: "bottom-center",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        setEditInfoLoading(false);
      });
  };
  const editDocuments = (values) => {
    // Headers
    setEditDocumentsLoading(true);

    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    let body = new FormData();

    if (idcardImg.length > 0) body.append("idcard", idcardImg[0]?.file);
    if (passportImg.length > 0) body.append("passport", passportImg[0]?.file);

    api
      .post("/users/edit_documents/" + auth?.user.id, body, config)
      .then((res) => {
        toast.success(
          "Modification réussie. Vos changements ont été enregistrés avec succès.",
          {
            position: "bottom-center",
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          }
        );
        setEditDocumentsLoading(false);
      })
      .catch((err) => {
        toast.error("Erreur", {
          position: "bottom-center",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        setEditDocumentsLoading(false);
      });
  };

  const submitFiles = (event, id) => {
    // setUploadingFiles(true)
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    // let invalid = false
    let invalid = false;
    // let invalid = files.some(
    // 	e => (e.required == true && e.file === null) || (e.file === null && e.path.length == 0)
    // )
    if (invalid) showError("Veuillez fournir les documents obligatoires");
    else {
      const body = new FormData();

      files.forEach((doc) => {
        body.append(`file${doc.id}`, doc.file);
      });

      // console.log(body)

      api
        .post("/users/submit_docs", body, config)
        .then((res) => {
          toast.success(
            "Modification réussie. Vos changements ont été enregistrés avec succès.",
            {
              position: "bottom-center",
              autoClose: 3000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            }
          );
          setEditDocumentsLoading(false);

          setFiles(
            res.data?.documents?.map((e) => {
              return { ...e, file: null };
            })
          );
        })
        .catch((err) => {
          toast.error("Erreur", {
            position: "bottom-center",
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
          setEditDocumentsLoading(false);
        });
    }
  };
  const handleFileChange = (event, id) => {
    const newFiles = [...files.filter((e) => e.id !== id)];
    let tmp = files.find((e) => e.id == id);

    tmp.file = event.target.files[0];

    setFiles([...newFiles, tmp]);
  };
  if (loading) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "80vh",
        }}
      >
        <Stack
          spacing={2}
          display={"flex"}
          justifyContent="center"
          direction="column"
          alignItems="center"
        >
          <CircularProgress />
          <Typography>Chargement</Typography>
        </Stack>
      </Box>
    );
  }
  if (cnxErr) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "80vh",
        }}
      >
        <Stack
          spacing={2}
          display={"flex"}
          justifyContent="center"
          direction="column"
          alignItems="center"
        >
          <IconButton onClick={() => getUser()}>
            <Refresh />
          </IconButton>
          <Typography>Problème de connexion </Typography>
        </Stack>
      </Box>
    );
  }
  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "100vh",
      }}
    >
      <Grid container spacing={2}>
        <Grid item xs={12} sm={12} md={5} lg={4}>
          <Box>
            <form autoComplete="off" noValidate onSubmit={formik.handleSubmit}>
              <Stack spacing={3} sx={{ border: "1px solid #ccc", p: 2 }}>
                <Typography variant="subtitle1">
                  Informations personnelles
                </Typography>
                <Stack direction="row" spacing={0.2}></Stack>
                <TextField
                  size="small"
                  fullWidth
                  autoComplete="address"
                  type="text"
                  name="address"
                  label="Adresse"
                  onChange={formik.handleChange}
                  value={formik.values.address}
                  error={Boolean(
                    formik.touched.address && formik.errors.address
                  )}
                  helperText={formik.touched.address && formik.errors.address}
                />
                <TextField
                  size="small"
                  fullWidth
                  type="text"
                  name="address2"
                  label="Complément d'adresse (Facultatif)"
                  onChange={formik.handleChange}
                  value={formik.values.address2}
                  error={Boolean(
                    formik.touched.address2 && formik.errors.address2
                  )}
                  helperText={formik.touched.address2 && formik.errors.address2}
                />
                <Box display="flex" gap={2}>
                  <TextField
                    size="small"
                    type="text"
                    name="postal_code"
                    label="Code Postal"
                    onChange={formik.handleChange}
                    value={formik.values.postal_code}
                    error={Boolean(
                      formik.touched.postal_code && formik.errors.postal_code
                    )}
                    helperText={
                      formik.touched.postal_code && formik.errors.postal_code
                    }
					InputProps={{
						readOnly: true, // Make this input non-editable
					}}
                  />
                  <TextField
                    size="small"
                    type="text"
                    name="city"
                    label="Ville"
                    onChange={formik.handleChange}
                    value={formik.values.city}
                    error={Boolean(formik.touched.city && formik.errors.city)}
                    helperText={formik.touched.city && formik.errors.city}
					InputProps={{
						readOnly: true, // Make this input non-editable
					}}
                  />
                </Box>

                {error && (
                  <Alert sx={{ m: 2 }} severity="error">
                    {error}
                  </Alert>
                )}
                <LoadingButton
                  sx={{ width: 200, alignSelf: "end" }}
                  size="miduim"
                  type="submit"
                  variant="contained"
                  loading={editInfoLoading}
                >
                  sauvgarder
                </LoadingButton>
              </Stack>
            </form>
          </Box>
          <Box sx={{ mt: 2 }}>
            <Stack spacing={3} sx={{ border: "1px solid #ccc", p: 2 }}>
              <Typography variant="subtitle1">
                Validation de L'adresse email
              </Typography>

              {!user?.valid_email ? (
                <>
                  <Typography color={"error"} variant="subtitle1">
                    L'adresse
                    <u>
                      <span style={{ marginInline: 5, color: "black" }}>
                        <bold>{user?.email}</bold>
                      </span>
                    </u>
                    n'est pas encore valide
                  </Typography>

                  <Alert severity="success">
                    Nous avons envoyé un lien de validation. Veuillez vérifier
                    votre boîte de réception à cette adresse : {user?.email}.
                  </Alert>

                  <Stack direction="row" spacing={0.2}>
                    <Typography variant="body2">
                      Si vous n'avez pas reçu l'e-mail, cliquez ici.
                    </Typography>

                    <Link
                      component={RouterLink}
                      href={"/register"}
                      variant="subtitle2"
                    >
                      Renvoyer
                    </Link>
                  </Stack>

                  {error && (
                    <Alert sx={{ m: 2 }} severity="error">
                      {error}
                    </Alert>
                  )}
                </>
              ) : (
                <Typography color={"green"} variant="subtitle1">
                  L'adresse
                  <u>
                    <span style={{ marginInline: 5, color: "black" }}>
                      <bold>{user?.email}</bold>
                    </span>
                  </u>
                  est bien validée.
                </Typography>
              )}
            </Stack>
          </Box>
        </Grid>
        <Grid item xs={12} sm={12} md={7} lg={8}>
          <Stack spacing={1} sx={{ minWidth: 700, p: 1 }}>
            <Typography variant="subtitle2">Documents : </Typography>
            <Typography variant="caption">
              la taille totale des documents doit être inférieure à 20 Mo.
            </Typography>

            {files
              .sort((a, b) => a.id - b.id)
              .map((doc) => (
                <>
                  {doc.status == true && (
                    <Paper variant="outlined" sx={{ display: "flex" }}>
                      <Stack direction={"row"} alignItems="center" spacing={2}>
                        {doc.is_valid == true && (
                          <CheckCircle
                            sx={{
                              mx: 1,
                              fontSize: "15px",
                              color: "green",
                            }}
                          />
                        )}

                        {doc.is_valid == false && (
                          <Box sx={{ m: 1 }}>
                            <img
                              src="/statics/undraw_add_files_re_v09g.svg"
                              alt=""
                              style={{
                                maxWidth: "50px",
                                maxHeight: "50px",
                              }}
                            />
                          </Box>
                        )}
                        <Stack>
                          <Typography variant="body2">{doc.name}</Typography>
                          {doc.file ? (
                            <MuiLink
                              href={URL.createObjectURL(doc.file)}
                              target="_blank"
                              rel="noopener noreferrer"
                              color="inherit"
                            >
                              <Typography
                                sx={{
                                  color: "blue",
                                  textDecoration: "underline",
                                }}
                                variant="caption"
                              >
                                {doc.file && doc.file.name}
                              </Typography>
                            </MuiLink>
                          ) : (
                            doc.path.length > 0 && (
                              <MuiLink
                                href={FILES_URL + doc.path}
                                target="_blank"
                                rel="noopener noreferrer"
                                color="inherit"
                              >
                                <Typography
                                  sx={{
                                    color: "blue",
                                    textDecoration: "underline",
                                  }}
                                  variant="caption"
                                >
                                  consulter le document ..
                                </Typography>
                              </MuiLink>
                            )
                          )}
                        </Stack>
                        {doc.is_valid == false && (
                          <>
                            <input
                              type="file"
                              id={"file" + doc?.id}
                              style={{ display: "none" }}
                              accept={doc?.types.map((e) => "." + e).join(", ")}
                              onChange={(event) =>
                                handleFileChange(event, doc?.id)
                              }
                            />
                            <label htmlFor={"file" + doc?.id}>
                              <Button
                                sx={{
                                  textTransform: "none",
                                }}
                                variant="text"
                                component="span"
                                size="small"
                                startIcon={<PostAdd />}
                              >
                                <Typography variant="caption">
                                  Choisir une fichier(
                                  {doc.types.join(",")})
                                </Typography>
                              </Button>
                            </label>
                          </>
                        )}
                      </Stack>
                    </Paper>
                  )}
                </>
              ))}

            <LoadingButton
              sx={{ width: 200, alignSelf: "end" }}
              size="miduim"
              onClick={submitFiles}
              variant="contained"
              loading={uploadingFiles}
            >
              sauvgarder
            </LoadingButton>
          </Stack>
        </Grid>
      </Grid>

      <ToastContainer
        position="top-center"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </Box>
  );
}
