import { ArrowForwardIos } from '@mui/icons-material'
import { Stack, Divider, Button } from '@mui/material'
import { useEffect, useState } from 'react'

import { toast } from 'react-toastify'

import api from 'src/Api'

import Step1 from './client_steps/Step1'
import Step2 from './client_steps/Step2'
import Step3 from './client_steps/Step3'
import { Check } from 'react-feather'
import Step6 from './client_steps/Step6'
export default function ClientStepper({ user, setUser }) {
	const [loading, setLoading] = useState(false)
	const [cnxErr, setCnxErr] = useState(false)
	const [activeStep, setActiveStep] = useState(1)
	const [unVerifiedSteps, setUnVerifiedSteps] = useState([...user?.unverified_steps])
	const [submitting, setSubmitting] = useState(false)
	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	useEffect(() => {}, [])
	const submit = () => {
		if (unVerifiedSteps.length == 1 && unVerifiedSteps.includes(-1)) {
			api.post('/users/submit_step', { step: -1 })
				.then(res => {
					if (res.data.error == 'wait') {
						showSuccess(
							"Vos documents seront vérifiés par l'administration dans un délai de 2 jours ouvrés"
						)
					} else setUser(res.data)
				})
				.catch(err => {
					showError('Quelque chose ne va pas')
				})
		}
	}

	return (
		<Stack spacing={2}>
			{unVerifiedSteps.length == 1 && unVerifiedSteps.includes(-1) && (
				<Button startIcon={<Check />} variant="contained" onClick={submit}>
					Continuer
				</Button>
			)}
			{activeStep !== 0 && (
				<Stack direction={'row'} justifyContent={'space-between'}>
					{(unVerifiedSteps.includes(1) || unVerifiedSteps.includes(-1)) && (
						<Button
							variant={activeStep == 1 ? 'contained' : 'outlined'}
							color={unVerifiedSteps.includes(1) ? 'error' : 'success'}
							onClick={() => {
								if (activeStep == 1) setActiveStep(-1)
								else setActiveStep(1)
							}}
							sx={{ textTransform: 'none' }}
							startIcon={<ArrowForwardIos />}
						>
							Logo de l’entreprise
						</Button>
					)}
					{(unVerifiedSteps.includes(2) || unVerifiedSteps.includes(-1)) && (
						<Button
							variant={activeStep == 2 ? 'contained' : 'outlined'}
							color={unVerifiedSteps.includes(2) ? 'error' : 'success'}
							onClick={() => {
								if (activeStep == 2) setActiveStep(-1)
								else setActiveStep(2)
							}}
							sx={{ textTransform: 'none' }}
							startIcon={<ArrowForwardIos />}
						>
							Informations générales
						</Button>
					)}
					{(unVerifiedSteps.includes(6) || unVerifiedSteps.includes(-1)) && (
						<Button
							variant={activeStep == 6 ? 'contained' : 'outlined'}
							color={unVerifiedSteps.includes(6) ? 'error' : 'success'}
							onClick={() => {
								if (activeStep == 6) setActiveStep(-1)
								else setActiveStep(6)
							}}
							sx={{ textTransform: 'none' }}
							startIcon={<ArrowForwardIos />}
						>
							Adresse
						</Button>
					)}

					{/* {(unVerifiedSteps.includes(3) || unVerifiedSteps.includes(-1)) && (
						<Button
							variant={activeStep == 3 ? 'contained' : 'outlined'}
							color={unVerifiedSteps.includes(3) ? 'error' : 'success'}
							onClick={() => {
								if (activeStep == 3) setActiveStep(-1)
								else setActiveStep(3)
							}}
							sx={{ textTransform: 'none' }}
							startIcon={<ArrowForwardIos />}
						>
							Documents
						</Button>
					)} */}
				</Stack>
			)}
			<Divider />
			{/* {unVerifiedSteps.includes(0) && activeStep == 0 && (
				<Step0
					name={user?.name}
					setUnVerifiedSteps={setUnVerifiedSteps}
					setActiveStep={setActiveStep}
				/>
			)} */}
			{activeStep == 1 && (
				<Step1 user={user} setUser={setUser} setUnVerifiedSteps={setUnVerifiedSteps} />
			)}
			{activeStep == 2 && <Step2 user={user} setUnVerifiedSteps={setUnVerifiedSteps} />}
			{/* {activeStep == 3 && <Step3 user={user} setUnVerifiedSteps={setUnVerifiedSteps} />} */}
			{activeStep == 6 && (
				<Step6 user={user} setUser={setUser} setUnVerifiedSteps={setUnVerifiedSteps} />
			)}

			{/* <Stack direction={'row'} justifyContent="flex-end">
				<Button onClick={nextStep} startIcon={<NavigateNext />}>
					Suivant
				</Button>
			</Stack> */}
			{/* <Button
				disabled={user.unverified_steps.length > 0}
				variant="contained"
				onClick={nextStep}
				startIcon={<NavigateNext />}
			></Button> */}
		</Stack>
	)
}
