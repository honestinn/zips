import {
	AccessTime,
	CalendarMonth,
	Check,
	DoNotDisturbAlt,
	Email,
	ExpandLess,
	ExpandMore,
	LocalOffer,
	Place,
	StarBorder,
} from '@mui/icons-material'
import {
	Box,
	Button,
	Collapse,
	Divider,
	FormControl,
	Grid,
	Paper,
	Stack,
	TextField,
	Typography,
} from '@mui/material'
import moment from 'moment'
import React, { useState } from 'react'
import { FILES_URL } from 'src/Api'
import Image from 'src/components/Image'

function msToHMS(time1, time2, pause) {
	const time1Parts = time1.split(':')
	const time2Parts = time2.split(':')

	const date1 = new Date(0, 0, 0, parseInt(time1Parts[0]), parseInt(time1Parts[1]))
	let date2 = new Date(0, 0, 0, parseInt(time2Parts[0]), parseInt(time2Parts[1]))

	if (date2 < date1) {
		// If time2 is earlier in the day than time1, add 24 hours to date2 to account for next day
		date2.setDate(date2.getDate() + 1)
	}

	const differenceMilliseconds = Math.abs(date2 - date1) - pause * 60000

	const seconds = Math.floor((differenceMilliseconds / 1000) % 60)
	const minutes = Math.floor((differenceMilliseconds / (1000 * 60)) % 60)
	const hours = Math.floor(differenceMilliseconds / (1000 * 60 * 60))

	const formattedTime = `${String(hours).padStart(2, '0')} h :${String(minutes).padStart(
		2,
		'0'
	)} min`
	return formattedTime
}
export default function MissionDetails({ row, user }) {
	return (
		<Paper variant="outlined" sx={{ p: 1 }}>
			<Grid container spacing={1}>
				<Grid item xs={12} md={3} lg={3}>
					<Stack justifyContent="center" alignItems="center" spacing={1} minHeight={200}>
						<Box
							sx={{
								display: 'flex',
								justifyContent: 'center',
								alignItems: 'center',

								width: 150,
								height: 150,
								p: 1,
							}}
						>
							<Image
								src={
									row?.client?.avatar.length > 0
										? FILES_URL + row?.client?.avatar
										: '/statics/image-placeholder.png'
								}
							/>
						</Box>
						<Stack
							sx={{
								color: row.available ? 'green' : 'red',
								typography: 'body2',
							}}
							direction="row"
							alignItems="center"
							spacing={2}
						>
							{row.available ? (
								<>
									<Check fontSize="small" />
									Disponible
								</>
							) : (
								<>
									<DoNotDisturbAlt fontSize="small" />
									Non disponible
								</>
							)}
						</Stack>

						<Typography color={'text.secondary'} variant="body2">
							ID :{row.uid}
						</Typography>
					</Stack>
				</Grid>
				<Grid item xs={12} md={6} lg={6}>
					<Stack sx={{ height: '100%' }} justifyContent={'space-between'} spacing={1}>
						<Stack spacing={1}>
							<Typography variant="h6">{row.title}</Typography>
							<Stack alignItems="center" direction="row" spacing={1}>
								<Typography variant="subtitle2">
									{row.client.company_name}
								</Typography>
								<Stack direction="row" alignItems="center" spacing={0}>
									<StarBorder fontSize="10" />
									<Typography color={'text.secondary'} variant="body2">
										{row.client.title}
									</Typography>
								</Stack>
							</Stack>
						</Stack>

						<Stack
							sx={{
								typography: 'body2',
								color: 'text.secondary',
								p: 1,
							}}
							spacing={1}
						>
							<Stack
								direction="row"
								alignItems="center"
								justifyContent={'space-between'}
								spacing={2}
							>
								<Stack direction="row" spacing={1}>
									<Place fontSize="small" />
									{row.address}
								</Stack>
								<Stack direction="row" alignItems="center" spacing={1}>
									<LocalOffer fontSize="10" />
									<Typography>{row.hour_salary + ' €/H'}</Typography>
								</Stack>
							</Stack>
						</Stack>
						<Stack spacing={1} direction={'row'}>
							<Typography color={'text.secondary'} variant="body2">
								Du
							</Typography>
							<Typography color={'text.secondary'} variant="body2">
								{moment(row.start_date).format('DD-MM-YYYY HH:mm')}
							</Typography>
							<Typography color={'text.secondary'} variant="body2">
								au
							</Typography>
							<Typography color={'text.secondary'} variant="body2">
								{moment(row.end_date).format('DD-MM-YYYY HH:mm')}
							</Typography>
						</Stack>

						{row.periods &&
							row.periods.map((item, index) => (
								<Stack
									sx={{
										p: 0.5,
										mb: 1,
										border: '1px solid #ccc',
										maxWidth: 420,
									}}
									direction="row"
									alignItems={'center'}
									spacing={1}
								>
									<CalendarMonth fontSize="10" />
									<Typography variant="body2">
										{moment(item.date).format('DD-MM-YYYY')}
									</Typography>
									<Typography>|</Typography>
									<Typography variant="body2">{item.from}</Typography>
									<Typography>-</Typography>
									<Typography variant="body2">{item.to}</Typography>
									<Typography>|</Typography>
									<AccessTime fontSize="10" />
									<Typography variant="body2">
										{msToHMS(item.from, item.to, item.pause)}
									</Typography>
								</Stack>
							))}
					</Stack>
				</Grid>
			</Grid>
			<Stack>
				<Divider sx={{ my: 2 }} />
				<Typography variant="subtitle1">Détails</Typography>
				<Typography variant="body1">{row?.details}</Typography>
			</Stack>
		</Paper>
	)
}
