import {
	Alert,
	Button,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	Divider,
	FormControl,
	Stack,
	TextField,
	Typography,
} from '@mui/material'
import api from 'src/Api'

import { useEffect, useState } from 'react'

import { Email, Phone } from '@mui/icons-material'
import { LoadingButton } from '@mui/lab'

import MissionDetails from './MissionDetails'

export default function Apply({
	open,
	close,
	refresh,
	user,
	showError,
	showSuccess,
	mission,
	applied,
	canceled,
}) {
	const [error, setError] = useState(null)
	const [loading, setLoding] = useState(false)
	const [message, setMessage] = useState('')
	const [result, setResult] = useState('')
	useEffect(() => {}, [open])

	const apply = body => {
		setLoding(true)
		api.post('/missions/apply/' + user?._id, { mission: mission._id, message })
			.then(res => {
				refresh()
				close()
				setResult(res.data)
				if (res.data == 'can not apply')
					showError('Vous ne pouvez pas appliquer sur cette mission car vous êtes occupé')
				else
					showSuccess(
						"Votre candidature a été envoyée avec succès, veuillez patienter pour les résultats s'il vous plaît."
					)
				setLoding(false)
			})
			.catch(err => {
				setLoding(false)
				showError('le serveur ne répond pas')
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}
	return (
		<Dialog fullWidth maxWidth="md" open={open} onClose={close}>
			<DialogTitle>Postuler dans la Mission</DialogTitle>
			<DialogContent>
				<MissionDetails user={user} row={mission} />
				<Stack spacing={2}>
					<Divider sx={{ my: 2 }} />
					<Stack direction={'row'} spacing={1}>
						<Email /> <Typography variant="subtitle1">{user.email}</Typography>
					</Stack>
					<Stack direction={'row'} spacing={1}>
						<Phone /> <Typography variant="subtitle1">{user.phone}</Typography>
					</Stack>
					<Typography variant="body1">Mes motivations</Typography>
					<FormControl fullWidth variant="standard">
						<TextField
							label="Mes motivations"
							name="message"
							rows={4}
							multiline
							size="large"
							type="text"
							onChange={event => setMessage(event.target.value)}
							value={message}
							variant="outlined"
						/>
					</FormControl>
					<Typography variant="subtitle2">
						Nb : Votre candidature sera évaluée par l'administration.
						<br />
						Après l'évaluation, un e-mail vous sera envoyé pour les résultats
					</Typography>
				</Stack>
				{error && <Alert severity="error">{error}</Alert>}
			</DialogContent>

			<DialogActions>
				<LoadingButton
					disabled={applied || canceled}
					onClick={apply}
					variant="contained"
					type="submit"
					loading={loading}
				>
					{applied ? 'Postulé' : 'Postuler'}
				</LoadingButton>
				<Button onClick={close}>Annuler</Button>
			</DialogActions>
		</Dialog>
	)
}
