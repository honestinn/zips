import { MyLocation, Refresh } from '@mui/icons-material'
import api from 'src/Api'
import {
	Box,
	Button,
	Container,
	FormControl,
	Grid,
	InputLabel,
	MenuItem,
	Paper,
	Select,
	Skeleton,
	Stack,
	TextField,
	Typography,
} from '@mui/material'
import { useEffect, useState } from 'react'
import Page from 'src/components/Page'

import useSettings from 'src/hooks/useSettings'

import { useSelector } from 'react-redux'

import { ToastContainer, toast } from 'react-toastify'
import MissionCard from './MissionCard'
import Apply from './Apply'
import ChoosePosition from '../../pro/missions/ChoosePosition'

export default function Missions() {
	const { themeStretch } = useSettings()
	const auth = useSelector(state => state.auth)
	const [origin, setOrigin] = useState(null)
	const [originName, setOriginName] = useState('')
	const [search, setSearch] = useState('')
	const [page, setPage] = useState(0)
	const [rowsPerPage, setRowsPerPage] = useState(25)
	const [loading, setLoading] = useState(false)
	const [selected, setSelected] = useState(null)
	const [user, setUser] = useState(null)
	const [missions, setMissions] = useState([])
	const [openApply, setOpenApply] = useState(false)
	const [startDate, setStartDate] = useState('')

	const [subCategory, setSubCategory] = useState('all')
	const [job, setJob] = useState('all')
	const [rayon, setRayon] = useState('50')
	const [jobs, setJobs] = useState([])
	const [subCategories, setSubCategories] = useState([])
	const [published, setPublished] = useState(true)
	const [appliedOn, setAppliedOn] = useState([])

	const [openChoose, setOpenChoose] = useState(false)

	const [canceled, setCanceled] = useState([])

	const [error, setError] = useState(false)

	const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - missions.length) : 0
	const handleChangePage = (event, newPage) => {
		setPage(newPage)
	}

	const setExpanded = mission => {
		// const mission = missions.find(e => e._id == id)
		const expanded = mission.expanded ? false : true

		const updatedData = missions.map(item =>
			item._id === mission._id ? { ...mission, expanded } : item
		)
		setMissions(updatedData)
	}
	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const handleChangeRowsPerPage = event => {
		setRowsPerPage(parseInt(event.target.value, 10))
		setPage(0)
	}

	const getUser = () => {
		// Headers

		api.get('/users/get')
			.then(res => {
				setUser(res.data)
				setOrigin([res.data?.location?.lat ?? 48.8567, res.data?.location?.lng ?? 2.3522])
			})
			.catch(err => {})
	}
	useEffect(() => {
		getUser()
		getMissions()
	}, [])

	const getMissions = () => {
		setPublished(true)
		setStartDate('')
		setSubCategory('all')
		setJob('all')
		setLoading(true)
		api.get('/missions/serach_missions/' + auth?.user.id)
			.then(res => {
				setTimeout(() => {
					setMissions(res.data.missions)
					setAppliedOn(res.data.appliedOn)
					setCanceled(res.data.canceled)

					setLoading(false)
					setError(false)
				}, 1000)
			})
			.catch(err => {
				setLoading(false)
				setError(true)
			})
	}
	const filtred = missions.filter(
		item =>
			((startDate && new Date(item.start_date) >= new Date(startDate).setHours(0, 0, 0, 0)) ||
				!startDate) &&
			(job == item?.job?._id || job == 'all') &&
			!canceled.includes(item._id)
	)
	return (
		<>
			<Page title="Mes missions">
				<Container maxWidth={themeStretch ? false : 'xl'}>
					<Stack direction={'row'} justifyContent={'space-between'} alignItems={'center'}>
						<Typography variant="h6" component="h6" paragraph>
							Mes missions
						</Typography>
						<Stack
							direction={'row'}
							alignItems={'center'}
							sx={{ p: 1, my: 1 }}
							justifyContent={'space-between'}
						>
							<div
								style={{
									overflow: 'hidden',
									textOverflow: 'ellipsis',
									width: '25rem',
								}}
							>
								<Typography noWrap variant="subtitle2">
									{originName}
								</Typography>
							</div>
							<Button
								variant="outlined"
								size="small"
								startIcon={<MyLocation />}
								onClick={() => setOpenChoose(true)}
							>
								Ma Position
							</Button>
						</Stack>
					</Stack>

					<Grid container spacing={1} columns={16}>
						<Grid item xs={16} md={4} lg={4}>
							<TextField
								label="	À partir de"
								name="start_date"
								type="date"
								size="small"
								fullWidth
								onChange={event => {
									setStartDate(event.target.value)
								}}
								variant="outlined"
								InputLabelProps={{
									shrink: true,
								}}
							/>
						</Grid>

						<Grid item xs={16} md={4} lg={4}>
							<FormControl size="small" fullWidth>
								<InputLabel id="demo-simple-select-label">Métier</InputLabel>
								<Select
									labelId="demo-simple-select-label"
									id="demo-simple-select"
									value={job}
									label="Métier"
									size="small"
									variant="outlined"
									name="job"
									onChange={event => {
										setJob(event.target.value)
									}}
								>
									<MenuItem value="all">Tous</MenuItem>
									{user?.experiences.length > 0 &&
										user?.experiences.map(e => (
											<MenuItem value={e.job._id}>{e.job.name}</MenuItem>
										))}
								</Select>
							</FormControl>
						</Grid>
						<Grid item xs={16} md={4} lg={4}>
							<FormControl size="small" fullWidth>
								<InputLabel id="demo-simple-select-label">
									Rayon de recherche
								</InputLabel>
								<Select
									labelId="demo-simple-select-label"
									id="demo-simple-select"
									value={rayon}
									label="Rayon de recherche"
									size="small"
									variant="outlined"
									onChange={event => {
										setRayon(event.target.value)
									}}
								>
									<MenuItem value="50">50 Km</MenuItem>
									<MenuItem value="60">60 Km</MenuItem>
									<MenuItem value="80">80 Km</MenuItem>
									<MenuItem value="100">100 Km</MenuItem>
								</Select>
							</FormControl>
						</Grid>

						<Grid item xs={16} md={4} lg={4}>
							<Stack spacing={1} direction="row" alignItems="center">
								<Button
									sx={{ ml: 2, textTransform: 'none' }}
									variant="outlined"
									size="small"
									fullWidth
									onClick={() => getMissions()}
									startIcon={<Refresh />}
								>
									<Typography variant="body2">Supprimer les filtres</Typography>
								</Button>
							</Stack>
						</Grid>
					</Grid>

					<Container maxWidth="lg">
						{!loading && filtred.length == 0 && (
							<Box
								sx={{
									p: 1,
									display: 'flex',
									border: '1px solid #ccc',
									mt: 1,
									justifyContent: 'center',
									alignItems: 'center',
									minHeight: 200,
								}}
							>
								<Typography>Aucun résultat</Typography>
							</Box>
						)}
						{loading && (
							<Paper sx={{ p: 1, mt: 1 }}>
								<Grid container spacing={1}>
									<Grid item xs={12} md={3} lg={3}>
										<Stack
											justifyContent="center"
											alignItems="center"
											spacing={1}
											minHeight={200}
										>
											<Skeleton
												variant="rectangular"
												width={150}
												height={150}
											/>

											<Skeleton
												variant="rectangular"
												width={120}
												height={20}
											/>
											<Skeleton
												variant="rectangular"
												width={130}
												height={20}
											/>
										</Stack>
									</Grid>
									<Grid item xs={12} md={9} lg={9}>
										<Stack
											sx={{ height: '100%' }}
											justifyContent={'center'}
											spacing={1}
										>
											<Skeleton
												variant="rectangular"
												width={600}
												height={50}
											/>
											<Stack direction={'row'} spacing={1}>
												<Skeleton
													variant="rectangular"
													width={200}
													height={20}
												/>
												<Skeleton
													variant="rectangular"
													width={200}
													height={20}
												/>
											</Stack>
										</Stack>
									</Grid>
								</Grid>
							</Paper>
						)}
						<Stack spacing={1}>
							{filtred.length > 0 &&
								filtred.map((row, index) => {
									return !canceled.includes(row._id) ? (
										<MissionCard
											row={row}
											setExpanded={setExpanded}
											applied={appliedOn.includes(row._id)}
											canceled={canceled.includes(row._id)}
											openApply={() => {
												setSelected(row)
												setOpenApply(true)
											}}
										/>
									) : null
								})}
						</Stack>
					</Container>
					{selected && (
						<Apply
							open={openApply}
							close={() => setOpenApply(false)}
							mission={selected}
							applied={appliedOn.includes(selected._id)}
							canceled={canceled.includes(selected._id)}
							refresh={() => {
								getMissions()
							}}
							showSuccess={showSuccess}
							showError={showError}
							user={user}
						/>
					)}
				</Container>
			</Page>
			{openChoose && (
				<ChoosePosition
					open={openChoose}
					close={() => setOpenChoose(false)}
					default_center={origin}
					setPosition={value => {
						setOrigin(value?.position)
						setOriginName(value?.address)
					}}
				/>
			)}
			<ToastContainer
				position="top-center"
				autoClose={3000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
			/>
		</>
	)
}
