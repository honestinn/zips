import { Info, Refresh, Search, StopCircle, WifiOff } from '@mui/icons-material'
import api from 'src/Api'
import {
	Box,
	Button,
	Chip,
	CircularProgress,
	Container,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	FormControl,
	IconButton,
	InputAdornment,
	OutlinedInput,
	Paper,
	Stack,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	Typography,
} from '@mui/material'
import { useEffect, useState } from 'react'
import Page from 'src/components/Page'

import useSettings from 'src/hooks/useSettings'
import Show from './Show'
import { useSelector } from 'react-redux'
import { ToastContainer, toast } from 'react-toastify'

import moment from 'moment'

function isLessThan24Hours(date) {
	const twelveHoursInMilliseconds = 24 * 60 * 60 * 1000 // 12 hours in milliseconds
	const currentDate = new Date()

	return (
		new Date(date) - currentDate <= twelveHoursInMilliseconds || new Date(date) <= currentDate
	)
}

export default function Applications() {
	const { themeStretch } = useSettings()
	const auth = useSelector(state => state.auth)
	const [search, setSearch] = useState('')
	const [page, setPage] = useState(0)
	const [rowsPerPage, setRowsPerPage] = useState(25)
	const [loading, setLoading] = useState(false)
	const [selected, setSelected] = useState(null)
	const [selectedDate, setSelectedDate] = useState(null)
	const [selectedApplicationId, setSelectedApplicationId] = useState('')
	const [selectedApplicationStatus, setSelectedApplicationStatus] = useState('waiting')
	const [applications, setApplications] = useState([])

	const [openShow, setOpenShow] = useState(false)
	const [cancelWait, setOpenCancelWait] = useState(false)
	const [error, setError] = useState(false)

	const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - applications.length) : 0
	const handleChangePage = (event, newPage) => {
		setPage(newPage)
	}
	const [openConfirmation, setOpenConfirmation] = useState(false)

	const handleChangeRowsPerPage = event => {
		setRowsPerPage(parseInt(event.target.value, 10))
		setPage(0)
	}
	const replace = data => {
		const application = applications.find(e => e._id == data._id)

		const updatedData = applications.map(item =>
			item._id == data._id ? { ...application, status: data.status } : item
		)
		setApplications(updatedData)
		setSelected({ ...application, status: data.status })
	}
	const sendCancel = () => {
		if (selectedApplicationStatus == 'waiting') {
			api.post('/missions/cancel_user_application', { applicationId: selectedApplicationId })
				.then(res => {
					showSuccess('la mission a été annulée avec succès')
					getApplications()
				})
				.catch(err => {
					showError("quelque chose s'est mal passé")
				})
		}
		if (selectedApplicationStatus == 'accepted') {
			api.post('/missions/cancel_mission', { applicationId: selectedApplicationId })
				.then(res => {
					showSuccess('la mission a été annulée avec succès')
					getApplications()
				})
				.catch(err => {
					showError('erreur')
				})
		}
	}
	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	useEffect(() => {
		getApplications()
	}, [])
	const getApplications = () => {
		setLoading(true)

		api.get('/missions/get_all_my_missions/' + auth.user.id)
			.then(res => {
				setApplications(res.data)

				setLoading(false)

				setError(false)
			})
			.catch(err => {
				setLoading(false)
				setError(true)
			})
	}

	const sendCancelRequest = () => {
		api.post('/missions/cancel_user_application', { applicationId: selectedApplicationId })
			.then(res => {
				showSuccess('la mission a été annulée avec succès')
			})
			.catch(err => {
				showError("quelque chose s'est mal passé")
			})
	}

	return (
		<>
			<Page title="Mes Candidatures">
				<Container maxWidth={themeStretch ? false : 'xl'}>
					<Typography variant="h6" component="h6" paragraph>
						Mes Candidatures
					</Typography>

					<Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
						<FormControl sx={{ mx: 1, width: '400px' }} variant="outlined">
							<OutlinedInput
								size="small"
								placeholder="Rechercher"
								type="text"
								onChange={e => {
									setSearch(e.target.value)
								}}
								value={search}
								endAdornment={
									<InputAdornment position="end">
										<IconButton edge="end">
											<Search />
										</IconButton>
									</InputAdornment>
								}
							/>
						</FormControl>
						<Box>
							<Button
								sx={{ ml: 2 }}
								variant="outlined"
								onClick={getApplications}
								startIcon={<Refresh />}
							>
								<Typography sx={{ mx: 2 }}>Actualiser</Typography>
							</Button>
						</Box>
					</Box>
					<Paper variant="outlined" sx={{ mt: 2, p: 1 }}>
						<TableContainer>
							<Table size="small">
								<TableBody>
									{!loading &&
										applications
											.filter(
												e =>
													e.mission._id
														.toLowerCase()
														.includes(search.toLowerCase()) ||
													e.mission.job.subcategory.name
														.toLowerCase()
														.includes(search.toLowerCase()) ||
													e.mission.job.name
														.toLowerCase()
														.includes(search.toLowerCase())
											)
											.map(row => {
												return (
													<TableRow hover key={row._id} tabIndex={-1}>
														<TableCell scope="row" padding="none">
															<Stack
																direction="row"
																alignItems="center"
																spacing={2}
															>
																<Stack>
																	<Typography
																		variant="subtitle2"
																		noWrap
																	>
																		{row.mission.job.subcategory
																			.name +
																			' - ' +
																			row.mission.job.name}
																	</Typography>
																	<Typography variant="body2">
																		ID:
																		{row.mission.uid}
																	</Typography>
																	<Typography variant="body2">
																		{moment(
																			row.mission.start_date
																		).format(
																			'DD-MM-YYYY HH:mm'
																		) +
																			' -> ' +
																			moment(
																				row.mission.end_date
																			).format(
																				'DD-MM-YYYY HH:mm'
																			)}
																	</Typography>
																</Stack>
															</Stack>
														</TableCell>

														<TableCell>
															{row.status == 'waiting' ? (
																<Chip
																	label="En attente"
																	color="warning"
																/>
															) : row.status == 'refused' ? (
																<Chip
																	label="Refusé"
																	color="error"
																/>
															) : row.status == 'accepted' ? (
																<Chip
																	label="Accepté"
																	color="info"
																/>
															) : row.status == 'completed' ? (
																<Chip
																	label="Terminé"
																	color="success"
																/>
															) : row.status == 'canceled' ? (
																<Chip
																	label="Annulé"
																	color="cancel"
																/>
															) : null}
														</TableCell>
														<TableCell>
															{row.status == 'waiting' && (
																<Button
																	color="error"
																	fullWidth
																	variant="text"
																	size="small"
																	onClick={() => {
																		setSelectedApplicationId(
																			row._id
																		)
																		setSelectedApplicationStatus(
																			row.status
																		)
																		setSelectedDate(
																			row.mission.start_date
																		)

																		setOpenCancelWait(true)

																		// cancel(row._id)
																	}}
																>
																	me désengager
																</Button>
															)}
															{row.status == 'accepted' && (
																<Button
																	color="error"
																	fullWidth
																	variant="text"
																	size="small"
																	onClick={() => {
																		setSelectedApplicationId(
																			row._id
																		)
																		setSelectedApplicationStatus(
																			row.status
																		)
																		setSelectedDate(
																			row.mission.start_date
																		)
																		setOpenConfirmation(true)

																		// cancel(row._id)
																	}}
																>
																	Annuler
																</Button>
															)}
														</TableCell>
														<TableCell>
															{moment(row.created_at).format(
																'DD-MM-YYYY / HH:MM'
															)}
														</TableCell>
														<TableCell sx={{ textAlign: 'center' }}>
															<IconButton
																onClick={() => {
																	setSelected(row)

																	setOpenShow(true)
																}}
															>
																<Info />
															</IconButton>
														</TableCell>
													</TableRow>
												)
											})}
									{!loading && emptyRows > 0 && (
										<TableRow style={{ height: 53 * emptyRows }}>
											<TableCell colSpan={4} />
										</TableRow>
									)}
									{!loading && error && (
										<TableRow style={{ height: 53 * emptyRows }}>
											<TableCell colSpan={7}>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
													}}
												>
													<WifiOff />
												</Box>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
													}}
												>
													<Typography variant="h6" color="#383737">
														Vérifier votre connexion internet et
														réessayer.
													</Typography>
												</Box>
											</TableCell>
										</TableRow>
									)}
									{loading && (
										<TableRow style={{ height: 53 * emptyRows }}>
											<TableCell colSpan={7}>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
														pt: 3,
														pb: 1,
														px: 1,
													}}
												>
													<CircularProgress />
												</Box>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
														pb: 3,
														px: 1,
													}}
												>
													<Typography variant="h6" color="#383737">
														Chargement de contenu.
													</Typography>
												</Box>
											</TableCell>
										</TableRow>
									)}
									{!loading && applications.length === 0 && !error && (
										<TableRow>
											<TableCell colSpan={7}>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
														mb: 2,
														mt: 2,
													}}
												>
													<StopCircle />
												</Box>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
													}}
												>
													<Typography variant="h6" color="#383737">
														Aucune candidatures.
													</Typography>
												</Box>
											</TableCell>
										</TableRow>
									)}
								</TableBody>
							</Table>
						</TableContainer>
					</Paper>

					{selected && (
						<Show open={openShow} close={() => setOpenShow(false)} row={selected} />
					)}
				</Container>
				<Dialog
					fullWidth
					maxWidth="sm"
					open={cancelWait}
					onClose={() => setOpenCancelWait(false)}
				>
					<DialogTitle>Êtes-vous sûr(e) ?</DialogTitle>
					<DialogContent>
						<Typography variant="body1" sx={{ p: 2 }}>
							Êtes-vous sûr de vouloir vous désengager de votre candidature ?
						</Typography>
						<Typography variant="caption" sx={{ p: 2 }}>
							Vous ne pouvez vous désengager que 24 heures avant le début de la
							mission.
						</Typography>
					</DialogContent>
					<DialogActions>
						<Button
							color="error"
							disabled={
								selectedApplicationStatus == 'waiting' &&
								isLessThan24Hours(selectedDate)
							}
							onClick={() => {
								sendCancel()
								setOpenCancelWait(false)
							}}
						>
							Oui
						</Button>
						<Button color="info" onClick={() => setOpenCancelWait(false)} autoFocus>
							Quitter
						</Button>
					</DialogActions>
				</Dialog>
				<Dialog
					fullWidth
					maxWidth="sm"
					open={openConfirmation}
					onClose={() => setOpenConfirmation(false)}
				>
					<DialogTitle>Êtes-vous sûr(e) ?</DialogTitle>
					<DialogContent>
						{selectedApplicationStatus == 'waiting' && (
							<>
								<Typography variant="body2" sx={{ color: 'red', p: 2 }}>
									Attention, vous allez annuler cette mission et vous ne pourrez
									pas postuler à nouveau.
								</Typography>
							</>
						)}
						{selectedApplicationStatus == 'accepted' && (
							<>
								<Typography variant="body2" sx={{ color: 'red', p: 2 }}>
									Attention, vous allez annuler cette mission et vous ne pourrez
									pas postuler à nouveau.
								</Typography>
								<Typography variant="caption" sx={{ p: 2 }}>
									La mission ne peut être annulée que 24 heures avant le début
									prévu.
								</Typography>
							</>
						)}
					</DialogContent>
					<DialogActions>
						<Button
							color="error"
							disabled={
								selectedApplicationStatus == 'accepted' &&
								isLessThan24Hours(selectedDate)
							}
							onClick={() => {
								sendCancel()
								setOpenConfirmation(false)
							}}
						>
							Oui
						</Button>
						<Button color="info" onClick={() => setOpenConfirmation(false)} autoFocus>
							Quitter
						</Button>
					</DialogActions>
				</Dialog>
				<ToastContainer
					position="top-center"
					autoClose={3000}
					hideProgressBar={false}
					newestOnTop={false}
					closeOnClick
					rtl={false}
					pauseOnFocusLoss
					draggable
					pauseOnHover
				/>
			</Page>
		</>
	)
}
