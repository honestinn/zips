import {
	Box,
	Button,
	Chip,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	Typography,
} from '@mui/material'

import { useEffect, useState } from 'react'

import MissionDetails from './MissionDetails'

export default function Show({ open, close, row }) {
	useEffect(() => {}, [open])

	return (
		<>
			<Dialog fullWidth maxWidth="lg" open={open} onClose={close}>
				<DialogTitle sx={{ display: 'flex', justifyContent: 'space-between' }}>
					<Typography>Information :</Typography>
				</DialogTitle>
				{row.status == 'waiting' ? (
					<Chip label="En attente" color="warning" />
				) : row.status == 'refused' ? (
					<Chip label="Refusé" color="error" />
				) : row.status == 'accepted' ? (
					<Chip label="Accepté" color="info" />
				) : row.status == 'canceled' ? (
					<Chip label="Annulé" color="cancel" />
				) : row.status == 'completed' ? (
					<Chip label="Terminé" color="success" />
				) : null}
				<DialogContent>
					<Box>
						<MissionDetails client={row?.client} row={row?.mission} />
					</Box>
				</DialogContent>
				<DialogActions>
					<Button onClick={close}>Quitter</Button>
				</DialogActions>
			</Dialog>
		</>
	)
}
