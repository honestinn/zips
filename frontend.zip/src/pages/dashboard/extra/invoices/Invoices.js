import { Info, Print, Refresh, Search, StopCircle, WifiOff } from '@mui/icons-material'
import api from 'src/Api'
import {
	Box,
	Button,
	Chip,
	CircularProgress,
	Container,
	FormControl,
	IconButton,
	InputAdornment,
	OutlinedInput,
	Stack,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableRow,
	Typography,
} from '@mui/material'
import { useEffect, useState } from 'react'
import Page from 'src/components/Page'

import Show from './Show'
import { useSelector } from 'react-redux'
import { ToastContainer, toast } from 'react-toastify'

import moment from 'moment'

export default function Invoices() {
	const auth = useSelector(state => state.auth)
	const [search, setSearch] = useState('')
	const [page, setPage] = useState(0)
	const [rowsPerPage, setRowsPerPage] = useState(25)
	const [loading, setLoading] = useState(false)
	const [selected, setSelected] = useState(null)

	const [invoices, setInvoices] = useState([])

	const [openShow, setOpenShow] = useState(false)
	const [error, setError] = useState(false)

	const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - invoices.length) : 0
	const handleChangePage = (event, newPage) => {
		setPage(newPage)
	}

	const handleChangeRowsPerPage = event => {
		setRowsPerPage(parseInt(event.target.value, 10))
		setPage(0)
	}

	useEffect(() => {
		getInvoices()
	}, [])
	const getInvoices = () => {
		setLoading(true)

		api.get('/missions/get_user_invoices/' + auth.user.id)
			.then(res => {
				setInvoices(res.data)

				setLoading(false)

				setError(false)
			})
			.catch(err => {
				setLoading(false)
				setError(true)
			})
	}
	const downloadInvoicePdf = id => {
		setLoading(true)
		api.get('/missions/download_invoice_pdf/' + id, {
			responseType: 'blob', // Important
		})
			.then(res => {
				const url = window.URL.createObjectURL(new Blob([res.data]))
				const link = document.createElement('a')
				link.href = url
				link.setAttribute('download', 'facture.pdf') // File name
				document.body.appendChild(link)
				link.click()
				document.body.removeChild(link)
				setLoading(false)
				setError(false)
			})
			.catch(err => {
				setLoading(false)
				setError(true)
			})
	}
	return (
		<>
			<Page title="Mes factures">
				<Container>
					<Typography variant="h6" component="h6" paragraph>
						Mes factures
					</Typography>

					<Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
						<FormControl sx={{ mx: 1, width: '400px' }} variant="outlined">
							<OutlinedInput
								size="small"
								placeholder="Rechercher"
								type="text"
								onChange={e => {
									setSearch(e.target.value)
								}}
								value={search}
								endAdornment={
									<InputAdornment position="end">
										<IconButton edge="end">
											<Search />
										</IconButton>
									</InputAdornment>
								}
							/>
						</FormControl>
						<Box>
							<Button
								sx={{ ml: 2 }}
								variant="outlined"
								onClick={getInvoices}
								startIcon={<Refresh />}
							>
								<Typography sx={{ mx: 2 }}>Actualiser</Typography>
							</Button>
						</Box>
					</Box>

					<TableContainer sx={{ width: '100%', mt: 1 }}>
						<Table size="small">
							<TableBody>
								{!loading &&
									invoices
										.filter(
											e =>
												e.mission._id
													.toLowerCase()
													.includes(search.toLowerCase()) ||
												e.mission.job.subcategory.name
													.toLowerCase()
													.includes(search.toLowerCase()) ||
												e.mission.job.name
													.toLowerCase()
													.includes(search.toLowerCase())
										)
										.map(row => {
											return (
												<TableRow hover key={row._id} tabIndex={-1}>
													<TableCell scope="row" padding="none">
														<Stack
															direction="row"
															alignItems="center"
															spacing={2}
														>
															<Stack>
																<Typography
																	variant="subtitle2"
																	noWrap
																>
																	{row.mission.job.subcategory
																		.name +
																		' - ' +
																		row.mission.job.name}
																</Typography>
																<Typography variant="body2">
																	ID:
																	{row.mission.uid}
																</Typography>
																<Typography variant="body2">
																	{moment(
																		row.mission.start_date
																	).format('DD-MM-YYYY HH:mm') +
																		' -> ' +
																		moment(
																			row.mission.end_date
																		).format(
																			'DD-MM-YYYY HH:mm'
																		)}
																</Typography>
															</Stack>
														</Stack>
													</TableCell>

													<TableCell>
														<Stack spacing={1}>
															{row.status == 'unpaid' ? (
																<Chip
																	label="non payé"
																	color="error"
																/>
															) : row.status == 'paid' ? (
																<Chip
																	label="payé"
																	color="success"
																/>
															) : null}
														</Stack>
													</TableCell>

													<TableCell sx={{ textAlign: 'center' }}>
														{row?.total.toFixed(2) + ' €'}
													</TableCell>

													<TableCell>
														{moment(row?.created_at).format(
															'DD-MM-YYYY HH:MM'
														)}
													</TableCell>
													<TableCell sx={{ textAlign: 'center' }}>
														<IconButton
															onClick={() => {
																setSelected(row)

																setOpenShow(true)
															}}
														>
															<Info />
														</IconButton>
														<IconButton
															onClick={() => {
																downloadInvoicePdf(row._id)
															}}
														>
															<Print />
														</IconButton>
													</TableCell>
												</TableRow>
											)
										})}
								{!loading && emptyRows > 0 && (
									<TableRow style={{ height: 53 * emptyRows }}>
										<TableCell colSpan={4} />
									</TableRow>
								)}
								{!loading && error && (
									<TableRow style={{ height: 53 * emptyRows }}>
										<TableCell colSpan={7}>
											<Box
												sx={{
													display: 'flex',
													justifyContent: 'center',
												}}
											>
												<WifiOff />
											</Box>
											<Box
												sx={{
													display: 'flex',
													justifyContent: 'center',
												}}
											>
												<Typography variant="h6" color="#383737">
													Vérifier votre connexion internet et réessayer.
												</Typography>
											</Box>
										</TableCell>
									</TableRow>
								)}
								{loading && (
									<TableRow style={{ height: 53 * emptyRows }}>
										<TableCell colSpan={7}>
											<Box
												sx={{
													display: 'flex',
													justifyContent: 'center',
													pt: 3,
													pb: 1,
													px: 1,
												}}
											>
												<CircularProgress />
											</Box>
											<Box
												sx={{
													display: 'flex',
													justifyContent: 'center',
													pb: 3,
													px: 1,
												}}
											>
												<Typography variant="h6" color="#383737">
													Chargement de contenu.
												</Typography>
											</Box>
										</TableCell>
									</TableRow>
								)}
								{!loading && invoices.length === 0 && !error && (
									<TableRow>
										<TableCell colSpan={7}>
											<Box
												sx={{
													display: 'flex',
													justifyContent: 'center',
													mb: 2,
													mt: 2,
												}}
											>
												<StopCircle />
											</Box>
											<Box
												sx={{
													display: 'flex',
													justifyContent: 'center',
												}}
											>
												<Typography variant="h6" color="#383737">
													Aucun résultat.
												</Typography>
											</Box>
										</TableCell>
									</TableRow>
								)}
							</TableBody>
						</Table>
					</TableContainer>

					{selected && (
						<Show open={openShow} close={() => setOpenShow(false)} row={selected} />
					)}
				</Container>
				<ToastContainer
					position="top-center"
					autoClose={3000}
					hideProgressBar={false}
					newestOnTop={false}
					closeOnClick
					rtl={false}
					pauseOnFocusLoss
					draggable
					pauseOnHover
				/>
			</Page>
		</>
	)
}
