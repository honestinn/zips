import { LoadingButton, TabContext, TabList, TabPanel } from '@mui/lab'
import {
	Alert,
	Box,
	CircularProgress,
	Container,
	Grid,
	IconButton,
	Stack,
	Tab,
	TextField,
	Typography,
} from '@mui/material'
import React, { useEffect, useState } from 'react'
import Page from 'src/components/Page'
import * as Yup from 'yup'
import api from 'src/Api'
import useSettings from 'src/hooks/useSettings'
import { Delete, Edit, WifiTethering } from '@mui/icons-material'
import { useFormik } from 'formik'
import { ToastContainer, toast } from 'react-toastify'

export default function Payment() {
	const { themeStretch } = useSettings()
	const [loading, setloading] = useState(false)
	const [editInfoLoading, setEditInfoLoading] = useState(false)
	const [error, setError] = useState(false)
	const [settings, setSettings] = useState(null)
	const formik = useFormik({
		enableReinitialize: true,
		initialValues: {
			tva: settings?.tva || 0,
			commission: settings?.commission || 0,
			max_mission_hours: settings?.max_mission_hours || 0,
			min_hour_salary: settings?.min_hour_salary || 0,
		},
		validationSchema: Yup.object().shape({
			tva: Yup.string().required('TVA est obligatoire *'),
			commission: Yup.string().required('commission est obligatoire *'),
			max_mission_hours: Yup.string().required('Total des heure  est obligatoire *'),
			min_hour_salary: Yup.string().required('Total des heure  est obligatoire *'),
		}),
		onSubmit: async (values, helpers) => {
			try {
				editSettings(values)
			} catch (err) {
				console.error(err)
				helpers.setStatus({ success: false })
				helpers.setErrors({ submit: err.message })
				helpers.setSubmitting(false)
			}
		},
	})
	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	useEffect(() => {
		getSettings()
	}, [])
	const getSettings = () => {
		setloading(true)
		api.get('/users/get_settings')
			.then(res => {
				setSettings(res.data)
				setloading(false)
			})
			.catch(err => {
				setloading(false)
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}
	const editSettings = values => {
		setEditInfoLoading(true)
		api.post('/admin/edit_settings', values)
			.then(res => {
				showSuccess('modifié avec succès')
				setEditInfoLoading(false)
			})
			.catch(err => {
				setEditInfoLoading(false)
				showError('erreur')
			})
	}
	if (loading)
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					height: '60vh',
				}}
			>
				<Stack alignItems={'center'} direction={'row'} spacing={1}>
					<CircularProgress /> <Typography>Chargement...</Typography>
				</Stack>
			</Box>
		)
	if (error)
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					height: '60vh',
				}}
			>
				<Stack sx={{ color: 'red' }} alignItems={'center'} direction={'row'} spacing={1}>
					<WifiTethering /> <Typography>Problem de connexion...</Typography>
				</Stack>
			</Box>
		)

	return (
		<Container maxWidth={themeStretch ? false : 'xl'}>
			{/* <Box sx={{ width: '100%', height: '100vh', display: 'flex' }}></Box> */}
			<Box sx={{ mt: 2 }}>
				<form autoComplete="off" noValidate onSubmit={formik.handleSubmit}>
					<Stack spacing={3} sx={{ border: '1px solid #ccc', p: 2 }}>
						<Typography variant="subtitle1">Paiement : </Typography>

						<Stack spacing={3}>
							<TextField
								size="large"
								fullWidth
								type="number"
								name="tva"
								label="TVA (%)"
								onChange={formik.handleChange}
								value={formik.values.tva}
								error={Boolean(formik.touched.tva && formik.errors.tva)}
								helperText={formik.touched.tva && formik.errors.tva}
							/>
							<TextField
								size="large"
								fullWidth
								type="number"
								name="commission"
								label="Commission (%)"
								onChange={formik.handleChange}
								value={formik.values.commission}
								error={Boolean(
									formik.touched.commission && formik.errors.commission
								)}
								helperText={formik.touched.commission && formik.errors.commission}
							/>

							<TextField
								size="large"
								fullWidth
								type="number"
								name="max_mission_hours"
								label="Total des heure par mission"
								onChange={formik.handleChange}
								value={formik.values.max_mission_hours}
								error={Boolean(
									formik.touched.max_mission_hours &&
										formik.errors.max_mission_hours
								)}
								helperText={
									formik.touched.max_mission_hours &&
									formik.errors.max_mission_hours
								}
							/>

							<TextField
								size="large"
								fullWidth
								type="number"
								name="min_hour_salary"
								label="Tarif horaire minimum"
								onChange={formik.handleChange}
								value={formik.values.min_hour_salary}
								error={Boolean(
									formik.touched.min_hour_salary && formik.errors.min_hour_salary
								)}
								helperText={
									formik.touched.min_hour_salary && formik.errors.min_hour_salary
								}
							/>
						</Stack>
						{error && (
							<Alert sx={{ m: 2 }} severity="error">
								{error}
							</Alert>
						)}
						<LoadingButton
							sx={{ width: 200, alignSelf: 'end' }}
							size="miduim"
							type="submit"
							variant="contained"
							loading={editInfoLoading}
						>
							sauvgarder
						</LoadingButton>
					</Stack>
				</form>
			</Box>{' '}
			<ToastContainer
				autoClose={3000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
			/>
		</Container>
	)
}
