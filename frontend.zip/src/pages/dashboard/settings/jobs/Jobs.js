import { TabContext, TabList, TabPanel } from '@mui/lab'
import { Box, Container, Grid, IconButton, Stack, Tab, Typography, Button, Dialog, DialogActions, DialogContent, DialogTitle, TextField } from '@mui/material'
import React, { useEffect, useState } from 'react'
import Page from 'src/components/Page'
import api from 'src/Api'
import useSettings from 'src/hooks/useSettings'
import { Delete, Edit } from '@mui/icons-material'

export default function Jobs() {
	const { themeStretch } = useSettings()
	const [loadingJobs, setloadingJobs] = useState(false)
	const [loadingCategories, setLoadingCategories] = useState(false)
	const [loadingSubCategories, setLoadingSubCategories] = useState(false)
	const [error, setError] = useState(false)

	const [selectedJob, setSelectedJob] = useState(null)
	const [selectedJobCatgory, setSelectedJobCategory] = useState(null)
	const [selectedJobSubCatgory, setSelectedJobSubCategory] = useState(null)
	const [jobsCatgories, setJobsCategories] = useState([])
	const [jobs, setJobs] = useState([])
	const [jobSubCatgories, setJobSubCategories] = useState([])

	// Dialog State
	const [openDialog, setOpenDialog] = useState(false)
	const [jobName, setJobName] = useState('')

	useEffect(() => {
		getJobsCategories()
	}, [])

	const getJobsCategories = () => {
		setLoadingCategories(true)
		api.get('/admin/get_jobs_categories')
			.then(res => {
				setJobsCategories(res.data)
				setLoadingCategories(false)
			})
			.catch(err => {
				setLoadingCategories(false)
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}

	const getJobs = id => {
		setloadingJobs(true)
		api.get('/admin/get_jobs/' + id)
			.then(res => {
				console.log(res.data)
				setJobs(res.data)
				setloadingJobs(false)
			})
			.catch(err => {
				setloadingJobs(false)
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}

	const getJobSubCategories = id => {
		setLoadingSubCategories(true)
		api.get('/admin/get_job_sub_categories/' + id)
			.then(res => {
				setJobSubCategories(res.data)
				setLoadingSubCategories(false)
			})
			.catch(err => {
				setLoadingSubCategories(false)
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}

	// Open dialog to add a new job
	const handleDialogOpen = () => {
		setOpenDialog(true)
	}

	// Close dialog
	const handleDialogClose = () => {
		setOpenDialog(false)
		setJobName('')
	}

	// Handle job creation
	const handleAddJob = () => {
		console.log("Job Name:", jobName)
		if (jobName && selectedJobSubCatgory) {
			const data = {
				name: jobName,
				subCategoryId: selectedJobSubCatgory._id 
			};
	
			api.post('/admin/add_job', data)
				.then(response => {
					// Traitement après succès, actualisation de la liste de métiers de la sous-catégorie
					getJobs(selectedJobSubCatgory._id)
				})
				.catch(error => {
					// Traitement en cas d'erreur
					console.error('Erreur lors de l\'ajout du métier', error);
				});
		} else {
			// Vous pouvez afficher un message d'erreur si les champs sont vides
			alert('Veuillez remplir tous les champs');
		}
		handleDialogClose() // Close dialog after job is created
	}

	return (
		<Container maxWidth={themeStretch ? false : 'xl'}>
			<Grid container spacing={2}>
				<Grid item xs={12} sm={12} md={4} lg={4}>
					<Stack spacing={1}>
						<Typography variant="h6">Catégories</Typography>

						{loadingCategories && <Typography>Chargement ...</Typography>}

						{!loadingCategories &&
							jobsCatgories.length > 0 &&
							jobsCatgories.map(row => (
								<Stack
									onClick={() => {
										getJobSubCategories(row._id)
										setSelectedJobCategory(row)
									}}
									direction="row"
									sx={{
										display: 'flex',
										justifyContent: 'space-between',
										alignItems: 'center',
										border: '1px solid #ccc',
										background: row._id == selectedJobCatgory?._id && '#a7abae',
										px: 1,
										mb: 1,
										cursor: 'pointer',
										transition: 'background-color 0.3s ease',
										'&:hover': {
											backgroundColor: '#a7abae',
										},
									}}
								>
									<Typography>{row.name}</Typography>
									<Stack
										direction="row"
										sx={{
											display: 'flex',
											justifyContent: 'center',
											alignItems: 'center',
										}}
									>
										<IconButton>
											<Edit />
										</IconButton>
										<IconButton>
											<Delete />
										</IconButton>
									</Stack>
								</Stack>
							))}
					</Stack>
				</Grid>

				<Grid item xs={12} sm={12} md={4} lg={4}>
					<Stack spacing={1}>
						<Typography variant="h6">Sous-Catégories</Typography>

						{loadingSubCategories && <Typography>Chargement ...</Typography>}

						{!loadingSubCategories &&
							jobSubCatgories.length > 0 &&
							jobSubCatgories.map(row => (
								<Stack
									onClick={() => {
										getJobs(row._id)
										setSelectedJobSubCategory(row)
									}}
									direction="row"
									sx={{
										display: 'flex',
										justifyContent: 'space-between',
										alignItems: 'center',
										border: '1px solid #ccc',
										background: row._id == selectedJobSubCatgory?._id && '#a7abae',
										px: 1,
										mb: 1,
										cursor: 'pointer',
										transition: 'background-color 0.3s ease',
										'&:hover': {
											backgroundColor: '#a7abae',
										},
									}}
								>
									<Typography>{row.name}</Typography>
									<Stack
										direction="row"
										sx={{
											display: 'flex',
											justifyContent: 'center',
											alignItems: 'center',
										}}
									>
										<IconButton>
											<Edit />
										</IconButton>
										<IconButton>
											<Delete />
										</IconButton>
									</Stack>
								</Stack>
							))}
					</Stack>
				</Grid>

				<Grid item xs={12} sm={12} md={4} lg={4}>

					<Stack spacing={1}>
						<Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 2 }}>
							<Typography variant="h6">Métiers</Typography>
							{/* Button to open Add Job Dialog only when category and sub-category are selected */}
							<Button
								variant="outlined"
								color="primary"
								onClick={handleDialogOpen}
								disabled={!selectedJobCatgory || !selectedJobSubCatgory} // Disable button if category or sub-category is not selected
							>
								Ajouter un métier
							</Button>
						</Stack>
						

						{loadingJobs && <Typography>Chargement ...</Typography>}

						{!loadingJobs &&
							jobs.length > 0 &&
							jobs.map(row => (
								<Stack
									direction="row"
									sx={{
										display: 'flex',
										justifyContent: 'space-between',
										alignItems: 'center',
										border: '1px solid #ccc',
										px: 1,
										mb: 1,
									}}
								>
									<Typography>{row.name}</Typography>
									<Stack
										direction="row"
										sx={{
											display: 'flex',
											justifyContent: 'center',
											alignItems: 'center',
										}}
									>
										<IconButton>
											<Edit />
										</IconButton>
										<IconButton>
											<Delete />
										</IconButton>
									</Stack>
								</Stack>
							))}
					</Stack>


				</Grid>
			</Grid>

			{/* Add Job Dialog */}
			<Dialog open={openDialog} onClose={handleDialogClose}>
				<DialogTitle>Ajouter un métier</DialogTitle>
				<DialogContent>
					<TextField
						autoFocus
						margin="dense"
						label="Nom du métier"
						type="text"
						fullWidth
						value={jobName}
						onChange={(e) => setJobName(e.target.value)}
					/>
				</DialogContent>
				<DialogActions>
					<Button onClick={handleDialogClose} color="primary">
						Annuler
					</Button>
					<Button onClick={handleAddJob} color="primary" disabled={!jobName}>
						Ajouter
					</Button>
				</DialogActions>
			</Dialog>
		</Container>
	)
}
