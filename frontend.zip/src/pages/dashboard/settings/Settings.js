import { TabContext, TabList, TabPanel } from '@mui/lab'
import { Box, Container, Tab, Typography } from '@mui/material'
import React from 'react'
import Page from 'src/components/Page'
import useSettings from 'src/hooks/useSettings'
import Jobs from './jobs/Jobs'
import Payment from './payment/Payment'

export default function Settings() {
	const { themeStretch } = useSettings()
	const [value, setValue] = React.useState('1')

	const handleChange = (event, newValue) => {
		setValue(newValue)
	}

	return (
		<Page title="Configuration">
			<Container maxWidth={themeStretch ? false : 'xl'}>
				<Typography variant="h4" component="h4" paragraph>
					Configuration
				</Typography>
				<Box sx={{ width: '100%', typography: 'body1' }}>
					<TabContext value={value}>
						<Box sx={{ borderBottom: 1, borderColor: 'divider', marginBottom:5 }}>
							<TabList onChange={handleChange} aria-label="lab API tabs example">
								<Tab label="configuration du paiement" value="1" />
								<Tab label="Gestion des métiers" value="2" />
							</TabList>
						</Box>
						<TabPanel value="1">
							<Payment />
						</TabPanel>
						<TabPanel value="2">
							<Jobs />
						</TabPanel>
					</TabContext>
				</Box>
			</Container>
		</Page>
	)
}
