import { Info, PlusOne, Refresh, Search, StopCircle, WifiOff } from '@mui/icons-material'
import api, { FILES_URL } from 'src/Api'
import {
	Avatar,
	Box,
	Button,
	Card,
	CardMedia,
	Chip,
	CircularProgress,
	Container,
	FormControl,
	IconButton,
	InputAdornment,
	OutlinedInput,
	Stack,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	Typography,
} from '@mui/material'
import { useEffect, useState } from 'react'
import Page from 'src/components/Page'

import useSettings from 'src/hooks/useSettings'
import Show from './Show'

import { ToastContainer, toast } from 'react-toastify'
import moment from 'moment'
import Image from 'src/components/Image'

export default function CancelRequests() {
	const { themeStretch } = useSettings()

	const [search, setSearch] = useState('')
	const [page, setPage] = useState(0)
	const [rowsPerPage, setRowsPerPage] = useState(25)
	const [loading, setLoading] = useState(false)
	const [selected, setSelected] = useState(null)

	const [applications, setApplications] = useState([])

	const [openShow, setOpenShow] = useState(false)
	const [error, setError] = useState(false)

	const [competences, setCompetences] = useState([])
	const [diplomes, setDiplomes] = useState([])
	const [softwares, setSoftwares] = useState([])
	const [langs, setLangs] = useState([])
	const [levels, setLevels] = useState([])
	const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - applications.length) : 0
	const handleChangePage = (event, newPage) => {
		setPage(newPage)
	}

	const handleChangeRowsPerPage = event => {
		setRowsPerPage(parseInt(event.target.value, 10))
		setPage(0)
	}
	const replace = data => {
		const application = applications.find(e => e._id == data._id)

		const updatedData = applications.map(item =>
			item._id == data._id ? { ...application, status: data.status } : item
		)
		setApplications(updatedData)
		setSelected({ ...application, status: data.status })
	}
	const getSoftwaresList = () => {
		api.get('/users/get_softwares_list')
			.then(res => {
				setSoftwares(res.data)
			})
			.catch(err => {})
	}
	const getCompetencesList = () => {
		api.get('/users/get_competences_list')
			.then(res => {
				setCompetences(res.data)
			})
			.catch(err => {})
	}
	const getDiplomesList = () => {
		api.get('/users/get_diplomes_list')
			.then(res => {
				setDiplomes(res.data)
			})
			.catch(err => {})
	}

	const getLanguagesList = () => {
		api.get('/users/get_lang_list')
			.then(res => {
				setLangs(res.data.langs)
				setLevels(res.data.levels)
			})
			.catch(err => {})
	}
	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	useEffect(() => {
		getApplications()
		getDiplomesList()
		getLanguagesList()
		getCompetencesList()
		getSoftwaresList()
	}, [])
	const getApplications = () => {
		setLoading(true)

		api.get('/missions/get_cancel_requests_pro')
			.then(res => {
				setApplications(res.data)

				setLoading(false)

				setError(false)
			})
			.catch(err => {
				setLoading(false)
				setError(true)
			})
	}
	return (
		<>
			<Page title="Gestion des demandes d’annulation">
				<Container maxWidth={themeStretch ? false : 'xl'}>
					<Typography variant="h6" component="h6" paragraph>
						Gestion des demandes d’annulation
					</Typography>

					<Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
						<FormControl sx={{ mx: 1, width: '400px' }} variant="outlined">
							<OutlinedInput
								size="small"
								placeholder="Rechercher"
								type="text"
								onChange={e => {
									setSearch(e.target.value)
								}}
								value={search}
								endAdornment={
									<InputAdornment position="end">
										<IconButton edge="end">
											<Search />
										</IconButton>
									</InputAdornment>
								}
							/>
						</FormControl>
						<Box>
							<Button
								sx={{ ml: 2 }}
								variant="outlined"
								onClick={getApplications}
								startIcon={<Refresh />}
							>
								<Typography sx={{ mx: 2 }}>Actualiser</Typography>
							</Button>
						</Box>
					</Box>
					<Card sx={{ borderRadius: 1, mt: 3 }}>
						<TableContainer sx={{ width: '100%' }}>
							<Table size="small">
								<TableHead>
									<TableRow>
										<TableCell sx={{ textAlign: 'start' }}>
											Collaborateur
										</TableCell>
										<TableCell sx={{ textAlign: 'start' }}>Mission</TableCell>
										<TableCell sx={{ textAlign: 'start' }}>Statut</TableCell>
										<TableCell sx={{ textAlign: 'start' }}>Date</TableCell>
										<TableCell sx={{ textAlign: 'center' }}>Options</TableCell>
									</TableRow>
								</TableHead>
								<TableBody>
									{!loading &&
										applications.map(row => {
											return (
												<TableRow hover key={row._id} tabIndex={-1}>
													<TableCell scope="row" padding="none">
														<Stack
															direction="row"
															alignItems="center"
															spacing={2}
														>
															<Box
																sx={{
																	display: 'flex',
																	justifyContent: 'center',
																	alignItems: 'center',

																	width: 80,
																	height: 80,
																	p: 1,
																}}
															>
																<Image
																	src={
																		row?.user?.avatar.length > 0
																			? FILES_URL +
																			  row?.user?.avatar
																			: '/statics/image-placeholder.png'
																	}
																/>
															</Box>
															<Stack>
																<Typography
																	variant="subtitle2"
																	noWrap
																>
																	{row.user.name}
																</Typography>
																<Typography variant="body2" noWrap>
																	{row.user.phone}
																</Typography>
																<Typography variant="body2" noWrap>
																	{row.user.email}
																</Typography>
															</Stack>
														</Stack>
													</TableCell>
													<TableCell scope="row" padding="none">
														<Stack
															direction="row"
															alignItems="center"
															spacing={2}
														>
															<Stack>
																<Typography
																	variant="subtitle2"
																	noWrap
																>
																	{row.mission.job.subcategory
																		.name +
																		' - ' +
																		row.mission.job.name}
																</Typography>
																<Typography variant="body2">
																	ID:
																	{row.mission.uid}
																</Typography>
																<Typography variant="body2">
																	{moment(
																		row.mission.start_date
																	).format('DD-MM-YYYY HH:mm') +
																		' -> ' +
																		moment(
																			row.mission.end_date
																		).format(
																			'DD-MM-YYYY HH:mm'
																		)}
																</Typography>
															</Stack>
														</Stack>
													</TableCell>

													<TableCell>
														<Stack spacing={1}>
															{/* {row.status == 'waiting' ? (
																<Chip
																	label="En attente"
																	color="warning"
																/>
															) : row.status == 'refused' ? (
																<Chip
																	label="Refusé"
																	color="error"
																/>
															) : row.status == 'accepted' ? (
																<Chip
																	label="Accepté"
																	color="info"
																/>
															) : row.status == 'canceled' ? (
																<Chip
																	label="Annulé"
																	color="cancel"
																/>
															) : row.status == 'completed' ? (
																<Chip
																	label="Terminé"
																	color="success"
																/>
															) : null} */}

															{row.cancel_request && (
																<>
																	<Chip
																		label={
																			row.cancel_request_status ==
																			'pending'
																				? "demande d'annulation En attente"
																				: row.cancel_request_status ==
																				  'accepted'
																				? "demande d'annulation accepté"
																				: row.cancel_request_status ==
																				  'refused'
																				? "demande d'annulation refusé"
																				: "pas d'action"
																		}
																		color={
																			row.cancel_request_status ==
																			'pending'
																				? 'warning'
																				: row.cancel_request_status ==
																				  'accepted'
																				? 'info'
																				: row.cancel_request_status ==
																				  'refused'
																				? 'error'
																				: 'secondary'
																		}
																	/>
																</>
															)}
														</Stack>
													</TableCell>
													<TableCell>
														{row.created_at
															.substring(0, 16)
															.replace('T', ' ')}
													</TableCell>
													<TableCell sx={{ textAlign: 'center' }}>
														<IconButton
															onClick={() => {
																setSelected(row)

																setOpenShow(true)
															}}
														>
															<Info />
														</IconButton>
													</TableCell>
												</TableRow>
											)
										})}
									{!loading && emptyRows > 0 && (
										<TableRow style={{ height: 53 * emptyRows }}>
											<TableCell colSpan={4} />
										</TableRow>
									)}
									{!loading && error && (
										<TableRow style={{ height: 53 * emptyRows }}>
											<TableCell colSpan={7}>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
													}}
												>
													<WifiOff />
												</Box>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
													}}
												>
													<Typography variant="h6" color="#383737">
														Vérifier votre connexion internet et
														réessayer.
													</Typography>
												</Box>
											</TableCell>
										</TableRow>
									)}
									{loading && (
										<TableRow style={{ height: 53 * emptyRows }}>
											<TableCell colSpan={7}>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
														pt: 3,
														pb: 1,
														px: 1,
													}}
												>
													<CircularProgress />
												</Box>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
														pb: 3,
														px: 1,
													}}
												>
													<Typography variant="h6" color="#383737">
														Chargement de contenu.
													</Typography>
												</Box>
											</TableCell>
										</TableRow>
									)}
									{!loading && applications.length === 0 && !error && (
										<TableRow>
											<TableCell colSpan={7}>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
														mb: 2,
														mt: 2,
													}}
												>
													<StopCircle />
												</Box>
												<Box
													sx={{
														display: 'flex',
														justifyContent: 'center',
													}}
												>
													<Typography variant="h6" color="#383737">
														Aucun résultat.
													</Typography>
												</Box>
											</TableCell>
										</TableRow>
									)}
								</TableBody>
							</Table>
						</TableContainer>
					</Card>

					{selected && (
						<Show
							open={openShow}
							close={() => setOpenShow(false)}
							langs={langs}
							levels={levels}
							competences={competences}
							diplomes={diplomes}
							showError={showError}
							showSuccess={showSuccess}
							softwares={softwares}
							row={selected}
							replace={data => {
								replace(data)
							}}
						/>
					)}
				</Container>
				<ToastContainer
					position="top-center"
					autoClose={3000}
					hideProgressBar={false}
					newestOnTop={false}
					closeOnClick
					rtl={false}
					pauseOnFocusLoss
					draggable
					pauseOnHover
				/>
			</Page>
		</>
	)
}
