import {
	Alert,
	Autocomplete,
	Avatar,
	Box,
	Button,
	Card,
	CardActions,
	CardContent,
	Checkbox,
	Chip,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	Divider,
	FormControl,
	FormControlLabel,
	Grid,
	Rating,
	Stack,
	Switch,
	TextField,
	Typography,
} from '@mui/material'
import api, { FILES_URL } from 'src/Api'
import { useFormik } from 'formik'
import { useEffect, useState } from 'react'

import * as Yup from 'yup'
import { Check, Close, ThumbUp, Upload } from '@mui/icons-material'
import { LoadingButton } from '@mui/lab'
import { confirmAlert } from 'react-confirm-alert'

import './style.css' // Import css
import MissionDetails from './MissionDetails'
import { StarIcon } from 'src/theme/overrides/CustomIcons'
import moment from 'moment'
import Image from 'src/components/Image'
const labels = {
	0.5: 'Useless',
	1: 'Useless+',
	1.5: 'Poor',
	2: 'Poor+',
	2.5: 'Ok',
	3: 'Ok+',
	3.5: 'Good',
	4: 'Good+',
	4.5: 'Excellent',
	5: 'Excellent+',
}
function getLabelText(value) {
	return `${value} Star${value !== 1 ? 's' : ''}, ${labels[value]}`
}

export default function Show({
	open,
	close,
	replace,
	row,
	langs,
	levels,
	competences,
	diplomes,
	softwares,
	showError,
	showSuccess,
}) {
	const [openRating, setOpenRating] = useState(false)
	const [value, setValue] = useState(2)
	const [hover, setHover] = useState(-1)
	const [recommended, setRecommended] = useState(false)
	const [comment, setComment] = useState('')
	const handleClickOpen = () => {
		setOpenRating(true)
	}

	const handleClose = () => {
		setOpenRating(false)
	}

	useEffect(() => {}, [open])
	const dialog = (onClose, submit, id, msg) => (
		<Card sx={{ minWidth: 500, p: 2 }}>
			<CardContent>
				<Typography variant="h6">Êtes-vous sûr(e) ?</Typography>

				<Typography sx={{ m: 2 }} variant="subtitle2" color="error">
					{msg}
				</Typography>
			</CardContent>
			<Stack direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }}>
				<Button
					onClick={() => {
						submit(id)
						onClose()
					}}
					variant="outlined"
					size="large"
				>
					Oui
				</Button>
				<Button onClick={onClose} size="large">
					Quitter
				</Button>
			</Stack>
		</Card>
	)

	const accept = id => {
		let msg =
			"Votre action annulera la candidature et informera le collaborateur que la demande d'annulation est accepté."

		confirmAlert({
			customUI: ({ onClose }) => dialog(onClose, sendAccept, id, msg),
			closeOnEscape: true,
			closeOnClickOutside: true,
			overlayClassName: 'overlay',
		})
	}

	const sendAccept = id => {
		api.post('/missions/accept_cancel_request/' + row?.user?._id, { id })
			.then(res => {
				showSuccess('la demande a été acceptée')

				replace(res.data)
			})
			.catch(err => {
				showError('erreur')
			})
	}

	const refuse = id => {
		let msg =
			"Votre action enverra un e-mail au collaborateur pour l'informer que la demande d'annulation est refusé"

		confirmAlert({
			customUI: ({ onClose }) => dialog(onClose, sendRefuse, id, msg),
			closeOnEscape: true,
			closeOnClickOutside: true,
			overlayClassName: 'overlay',
		})
	}

	const sendRefuse = id => {
		api.post('/missions/refuse_cancel_request/' + row?.user?._id, { id })
			.then(res => {
				showSuccess('la demande a été refusée')

				replace(res.data)
			})
			.catch(err => {
				showError('erreur')
			})
	}

	return (
		<>
			<Dialog fullWidth maxWidth="lg" open={open} onClose={close}>
				<DialogTitle sx={{ display: 'flex', justifyContent: 'space-between' }}>
					<Typography variant="substitle2">Information :</Typography>
				</DialogTitle>
				<DialogContent>
					<Stack spacing={1} my={1}>
						<Typography variant="subtitle1" color={'error'}>
							{row.cancel_request &&
								"Le collaborateur a demandé d'annuler cette candidature."}
						</Typography>
						{row.cancel_request && (
							<Typography>Motif d'annulation : {row.cancel_motif} </Typography>
						)}
					</Stack>
					<Divider />
					<Box sx={{ m: 2 }}>
						<Grid container spacing={2}>
							<Grid item xs={12} sm={12} md={8} lg={8}>
								<Stack spacing={1}>
									<Stack alignItems={'center'} direction="row" spacing={2}>
										<Typography variant="subtitle1">Nom et prenom :</Typography>
										<Typography variant="body2">
											{row?.user?.name.toUpperCase()}
										</Typography>
									</Stack>
									<Stack alignItems={'center'} direction="row" spacing={2}>
										<Typography variant="subtitle1"> Téléphone:</Typography>
										<Typography variant="body2"> {row?.user?.phone}</Typography>
									</Stack>
									<Stack alignItems={'center'} direction="row" spacing={2}>
										<Typography variant="subtitle1"> Email:</Typography>
										<Typography
											color={!row?.user?.valid_email && 'error'}
											variant="body2"
										>
											{row?.user?.email}{' '}
											{!row?.user?.valid_email && '| non valide'}{' '}
										</Typography>
									</Stack>
									<Stack alignItems={'center'} direction="row" spacing={2}>
										<Typography variant="subtitle1">
											Date de naissance :
										</Typography>
										<Typography variant="body2">
											{' '}
											{moment(row?.user?.dob).format('DD-MM-YYYY')}
										</Typography>
									</Stack>
									<Stack alignItems={'center'} direction="row" spacing={2}>
										<Typography variant="subtitle1"> Adresse:</Typography>
										<Typography variant="body2">
											{row?.user?.address}
										</Typography>
									</Stack>
									<Stack alignItems={'center'} direction="row" spacing={2}>
										<Typography variant="subtitle1">
											Complément d'adresse :
										</Typography>
										<Typography variant="body2">
											{row?.user?.address2}
										</Typography>
									</Stack>
								</Stack>
							</Grid>

							<Grid item xs={12} sm={12} md={4} lg={4}>
								<Stack
									spacing={2}
									sx={{
										display: 'flex',

										alignItems: 'center',

										width: '100%',
									}}
								>
									<Box
										sx={{
											display: 'flex',
											justifyContent: 'center',
											alignItems: 'center',

											width: 150,
											height: 150,
											p: 1,
										}}
									>
										<Image
											src={
												row?.user?.avatar.length > 0
													? FILES_URL + row?.user?.avatar
													: '/statics/image-placeholder.png'
											}
										/>
									</Box>
									<Rating
										name="read-only"
										value={Number(row?.user?.rating)}
										readOnly
									/>
									<Stack spacing={1} direction="row">
										<ThumbUp sx={{ color: 'green' }} />
										<Typography variant="subtitle1">
											{row?.user?.nb_recommendation}
										</Typography>
									</Stack>
								</Stack>
							</Grid>
							<Grid item xs={12} sm={12} md={12} lg={12}>
								<Stack spacing={2}>
									<Typography variant="subtitle2">Métier(s)</Typography>
									<Stack direction={'row'} spacing={1} flexWrap="wrap">
										{row?.user?.experiences?.length > 0 &&
											row?.user?.experiences?.map(item => (
												<Stack
													direction={'row'}
													sx={{ ml: 1, p: 1, background: '#ededed' }}
													spacing={1}
												>
													<Box>
														<Typography variant="subtitle2">
															{item.job?.name}
														</Typography>
														<Typography variant="subtitle2">
															{item.company}
														</Typography>
														<Typography
															variant="body2"
															color="text.secondary"
														>
															{moment(item.start_date).format(
																'DD-MM-YYYY'
															) +
																'/' +
																moment(item.end_date).format(
																	'DD-MM-YYYY'
																)}
														</Typography>
													</Box>
												</Stack>
											))}
									</Stack>
								</Stack>
							</Grid>
							<Grid item xs={12} sm={12} md={12} lg={12}>
								<Typography variant="subtitle2">Références</Typography>

								<Stack direction={'row'} spacing={1} flexWrap="wrap">
									{row?.user?.references?.length > 0 &&
										row?.user?.references?.map(item => (
											<Stack
												sx={{ ml: 1, p: 1, background: '#ededed' }}
												spacing={1}
											>
												<Typography variant="subtitle2">
													{item.company_name}
												</Typography>
												<Typography variant="subtitle2">
													{item.name}
												</Typography>
												<Typography variant="body2" color="text.secondary">
													{item.phone}
												</Typography>
												<Typography variant="body2" color="text.secondary">
													{item.email}
												</Typography>
											</Stack>
										))}
								</Stack>
							</Grid>
							<Grid item xs={12} sm={12} md={12} lg={12}>
								<Stack spacing={2}>
									<Typography variant="subtitle2">Diplôme(s)</Typography>
									<Stack direction={'row'} spacing={1} flexWrap="wrap">
										{row?.user?.diplomes?.length > 0 &&
											row?.user?.diplomes?.map(item => (
												<Stack
													direction={'row'}
													sx={{ ml: 1, p: 1, background: '#ededed' }}
													spacing={1}
													alignItems={'center'}
												>
													<Typography variant="subtitle2">
														{diplomes.find(e => e.id == item)?.title}
													</Typography>
												</Stack>
											))}
									</Stack>
								</Stack>
							</Grid>
							<Grid item xs={12} sm={12} md={6} lg={6}>
								<Stack spacing={2}>
									<Typography variant="subtitle2">Logiciels</Typography>
									<Stack direction={'row'} spacing={1} flexWrap="wrap">
										{row?.user?.softwares?.length > 0 &&
											row?.user?.softwares?.map(item => (
												<Stack
													direction={'row'}
													sx={{ ml: 1, p: 1, background: '#ededed' }}
													spacing={1}
													alignItems={'center'}
												>
													<Typography variant="subtitle2">
														{softwares.find(e => e.id == item)?.name}
													</Typography>
												</Stack>
											))}
									</Stack>
								</Stack>
							</Grid>

							<Grid item xs={12} sm={12} md={6} lg={6}>
								<Stack spacing={2}>
									<Typography variant="subtitle2">langues</Typography>
									<Stack direction={'row'} flexWrap="wrap">
										{row?.user?.languages?.length > 0 &&
											row?.user?.languages?.map(item => (
												<Stack
													direction={'row'}
													sx={{ ml: 1, p: 1, background: '#ededed' }}
													spacing={1}
													alignItems={'center'}
												>
													<Typography variant="subtitle2">
														{langs.find(e => e.id == item.lang)?.title}
													</Typography>
												</Stack>
											))}
									</Stack>
								</Stack>
							</Grid>

							<Grid
								item
								xs={12}
								sm={12}
								md={12}
								lg={12}
								sx={{ border: '1px solid #ccc', m: 1, p: 1 }}
							>
								<Typography variant="subtitle2">Mes motivations</Typography>
								<Typography variant="paragraph"> {row.message}</Typography>
							</Grid>

							<Grid item xs={12} sm={12} md={12} lg={12}>
								<MissionDetails client={row?.client} row={row?.mission} />
							</Grid>
						</Grid>
					</Box>
				</DialogContent>
				<DialogActions>
					{['accepted'].includes(row.status) &&
						row.cancel_request &&
						row.cancel_request_status == 'pending' && (
							<>
								<Button
									sx={{ textTransform: 'none' }}
									onClick={() => {
										accept(row._id)
									}}
									variant="contained"
									color="warning"
								>
									Accepter la demande
								</Button>

								<Button
									sx={{ textTransform: 'none' }}
									onClick={() => {
										refuse(row._id)
									}}
									variant="contained"
									color="error"
								>
									Refuser la demande
								</Button>
							</>
						)}

					<Button onClick={close}>Quitter</Button>
				</DialogActions>
			</Dialog>
		</>
	)
}
