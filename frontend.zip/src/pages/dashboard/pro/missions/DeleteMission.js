import { Button, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material'
import api from 'src/Api'

import { useEffect, useState } from 'react'

import { LoadingButton } from '@mui/lab'

export default function DeleteMission({
	open,
	close,
	refresh,
	user,
	showError,
	showSuccess,
	mission,
}) {
	useEffect(() => {}, [open])

	const deleteMission = body => {
		api.post('/missions/delete_mission/' + mission?._id)
			.then(res => {
				showSuccess('Mission supprimé')

				refresh()
			})
			.catch(err => {
				if (err.response.data?.error == 'can not delete')
					showError(
						'Vous ne pouvez pas le supprimer car cette mission est déjà occupée par des candidats'
					)
				else showError('le serveur ne répond pas')
			})
	}
	return (
		<Dialog fullWidth maxWidth="sm" open={open} onClose={close}>
			<DialogTitle>Supprimer la Mission</DialogTitle>
			<DialogContent>
				Êtes-vous sûr que cette mission sera supprimée définitivement ?
			</DialogContent>

			<DialogActions>
				<LoadingButton color="error" onClick={deleteMission}>
					Supprimer
				</LoadingButton>
				<Button onClick={close}>annuler</Button>
			</DialogActions>
		</Dialog>
	)
}
