import { createRef, forwardRef, useCallback, useEffect, useMemo, useState } from 'react'

// material
import {
	Card,
	Table,
	Stack,
	Avatar,
	Button,
	TableRow,
	TableBody,
	TableCell,
	Typography,
	TableContainer,
	TablePagination,
	Box,
	TableHead,
	useMediaQuery,
	CircularProgress,
	Container,
	useTheme,
	Divider,
	OutlinedInput,
	InputAdornment,
	IconButton,
	FormControl,
	Autocomplete,
	TextField,
	InputLabel,
	Select,
	MenuItem,
	DialogActions,
	DialogTitle,
	DialogContent,
	Dialog,
	Chip,
} from '@mui/material'

import {
	CircleOutlined,
	PlusOne,
	Refresh,
	RefreshRounded,
	Search,
	CircleRounded,
	MobileScreenShare,
} from '@mui/icons-material'
import L from 'leaflet'
import { useSelector } from 'react-redux'
import api from 'src/Api'
import { renderToString } from 'react-dom/server'
import { CircleMarker, MapContainer, Marker, Popup, Circle, TileLayer, useMap } from 'react-leaflet'

import { useRef } from 'react'

import 'leaflet/dist/leaflet.css'
import moment from 'moment'
import { position } from 'stylis'
import './style.css'
import { LoadingButton } from '@mui/lab'
import { toast } from 'react-toastify'
// import { position } from 'stylis'
import axios from 'axios'
const normalizeProvince = (province = '') =>
	province
		.replace('Province', '')
		.replace('Province of')
		.replace('Wilaya de', '')
		.replace("Wilaya d'", '')
		.replace('Algiers', 'Alger')
		.normalize('NFD')
		.replace(/[\u0300-\u036f]/g, '')
		.replace('Algerie', 'Alger')
		.replace('Daira', '')
		.replace("d'", '')
		.replace(/\s+/g, ' ')
		.trim()
function ChangeView({ center, zoom }) {
	const map = useMap()
	map.setView(center, zoom)
	return null
}
const GetCoordinates = ({ setPosition }) => {
	const map = useMap()

	const [loading, setLoading] = useState(false)
	useEffect(() => {
		if (!map) return

		const legend = L.control({ position: 'bottomleft' })

		map.on('dragend zoomend', async () => {
			const { lat, lng } = map.getCenter()
			const zoom = map.getZoom()
			let address = {
				name: '',
				state: '',
				county: '',
			}
			let province = ''

			setLoading(true)
			try {
				let originAddress = await axios.get(
					`https://nominatim.openstreetmap.org/reverse?lat=${lat.toFixed(
						5
					)}&lon=${lng.toFixed(5)}&format=json&accept-language=fr`
				)
				setLoading(false)
				address.name = originAddress.data.display_name
				address.state = normalizeProvince(originAddress.data.address.state)
				address.county = normalizeProvince(
					originAddress.data.address.town ||
						originAddress.data.address.city ||
						originAddress.data.address.county
				)
				setPosition({
					position: [lat.toFixed(5), lng.toFixed(5)],
					address: address,
				})
			} catch (err) {
				setLoading(false)
			}
		})
	}, [map])

	return null
}

export default function ChoosePosition({ open, close, setPosition, default_center }) {
	const [zoom, setZoom] = useState(22)
	const [center, setCenter] = useState(default_center)
	const [address, setAddress] = useState('')
	const [addressList, setAddressList] = useState([])
	const [lodingPosition, setLoadingPosition] = useState([])
	const [addressPosition, setAddressPosition] = useState([])
	const [selected, setSelected] = useState(null)
	useEffect(async () => {}, [])
	const suggestionClick = value => {
		setAddressPosition(value.position)
		setAddress(value.name)
		setCenter(value.position)
		setSelected({ position: value.position, address: value.name })
	}
	const handelAddressChange = event => {
		const text = event.target.value

		if (text.length >= 2) {
			getAddressList(text, 'origin')
		}
	}
	const getAddressList = text => {
		setLoadingPosition(true)
		api.get(`/users/city_autocomplete`, { params: { text: text } })
			.then(res => {
				setAddressList(res.data)
				console.log(res.data)
				setLoadingPosition(false)
			})
			.catch(err => {
				setLoadingPosition(false)
			})
	}
	return (
		<>
			<Dialog fullWidth open={open} maxWidth="md" onClose={close}>
				<DialogTitle>Position de la mission</DialogTitle>
				<DialogContent>
					<Box sx={{ display: 'flex' }}>
						<Autocomplete
							sx={{ width: 400, my: 2 }}
							freeSolo
							disableClearable
							getOptionLabel={option => option.name}
							size="small"
							onChange={(event, newValue) => suggestionClick(newValue)}
							options={addressList}
							renderInput={params => (
								<TextField
									{...params}
									onChange={handelAddressChange}
									label="Adresse"
									InputProps={{
										...params.InputProps,
										type: 'search',
									}}
								/>
							)}
						/>
					</Box>
					<MapContainer
						className="center-of-map"
						style={{ height: '50vh', width: '100%', zIndex: 1, margin: 1 }}
						center={center}
						zoom={zoom}
					>
						<TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

						<GetCoordinates
							setPosition={value => {
								setCenter(value?.position)
								setAddress(value?.address?.name)
								setSelected({
									position: value?.position,
									address: value?.address?.name,
								})
							}}
						/>
						<ChangeView center={center} />
					</MapContainer>
					<Box sx={{ py: 1 }}>
						<Typography sx={{ mr: 2 }} variant="subtitle1" display="inline">
							position :
						</Typography>
						<Typography display="inline">{center[0] + ',' + center[1]}</Typography>
					</Box>
					<Box sx={{ py: 1 }}>
						<Typography sx={{ mr: 2 }} variant="subtitle1" display="inline">
							Addresee :
						</Typography>
						<Typography display="inline">{address}</Typography>
					</Box>
					<Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
						<Button
							onClick={() => {
								close()
							}}
						>
							quitter
						</Button>
						<Button
							onClick={() => {
								setPosition(selected)
								close()
							}}
						>
							valider
						</Button>
					</Box>
				</DialogContent>
			</Dialog>
		</>
	)
}
