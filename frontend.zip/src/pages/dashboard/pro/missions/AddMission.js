import {
	Alert,
	Autocomplete,
	Box,
	Button,
	Checkbox,
	CircularProgress,
	Divider,
	FormControl,
	FormControlLabel,
	FormHelperText,
	Grid,
	IconButton,
	InputLabel,
	MenuItem,
	Paper,
	Radio,
	RadioGroup,
	Select,
	Stack,
	TextField,
	Typography,
} from '@mui/material'
import api from 'src/Api'
import { useFormik } from 'formik'
import { useEffect, useState } from 'react'

import * as Yup from 'yup'
import { Close, Refresh, Today, Upload } from '@mui/icons-material'
import { LoadingButton } from '@mui/lab'
import { useSelector } from 'react-redux'
import moment from 'moment'

import axios from 'axios'
import ChoosePosition from './ChoosePosition'
import { ToastContainer, toast } from 'react-toastify'

function formatDate(date) {
	const month = String(date.getMonth() + 1).padStart(2, '0')
	const day = String(date.getDate()).padStart(2, '0')
	const year = date.getFullYear()

	return `${year}-${month}-${day}`
}
// function msToHMS(time1, time2, pause) {
// 	const time1Parts = time1.split(':')
// 	const time2Parts = time2.split(':')
// 	if (!pause) {
// 		pause = 0
// 	}
// 	const date1 = new Date(0, 0, 0, parseInt(time1Parts[0]), parseInt(time1Parts[1]))
// 	const date2 = new Date(0, 0, 0, parseInt(time2Parts[0]), parseInt(time2Parts[1]))

// 	const differenceMilliseconds = Math.abs(date2 - date1) - Number(pause * 60000)

// 	const seconds = Math.floor((differenceMilliseconds / 1000) % 60)
// 	const minutes = Math.floor((differenceMilliseconds / (1000 * 60)) % 60)
// 	const hours = Math.floor(differenceMilliseconds / (1000 * 60 * 60))

// 	const formattedTime = `${String(hours).padStart(2, '0')} h :${String(minutes).padStart(
// 		2,
// 		'0'
// 	)} min`
// 	return formattedTime
// }
function msToHMS(time1, time2, pause = 0) {
	const time1Parts = time1.split(':')
	const time2Parts = time2.split(':')

	const date1 = new Date(0, 0, 0, parseInt(time1Parts[0]), parseInt(time1Parts[1]))
	let date2 = new Date(0, 0, 0, parseInt(time2Parts[0]), parseInt(time2Parts[1]))

	if (date2 < date1) {
		// If time2 is earlier in the day than time1, add 24 hours to date2 to account for next day
		date2.setDate(date2.getDate() + 1)
	}

	const differenceMilliseconds = Math.abs(date2 - date1) - pause * 60000

	const seconds = Math.floor((differenceMilliseconds / 1000) % 60)
	const minutes = Math.floor((differenceMilliseconds / (1000 * 60)) % 60)
	const hours = Math.floor(differenceMilliseconds / (1000 * 60 * 60))

	const formattedTime = `${String(hours).padStart(2, '0')} h :${String(minutes).padStart(
		2,
		'0'
	)} min`
	return formattedTime
}
// function Hours(time1, time2, pause) {
// 	const time1Parts = time1.split(':')
// 	const time2Parts = time2.split(':')
// 	if (!pause) {
// 		pause = 0
// 	}
// 	const date1 = new Date(0, 0, 0, parseInt(time1Parts[0]), parseInt(time1Parts[1]))
// 	const date2 = new Date(0, 0, 0, parseInt(time2Parts[0]), parseInt(time2Parts[1]))

// 	const differenceMilliseconds = Math.abs(date2 - date1) - Number(pause * 60000)

// 	const seconds = Math.floor((differenceMilliseconds / 1000) % 60)
// 	const minutes = Math.floor((differenceMilliseconds / (1000 * 60)) % 60)
// 	const hours = Math.floor(differenceMilliseconds / (1000 * 60 * 60))

// 	return hours
// }
function customSort(a, b) {
	const dateComparison = a.date.localeCompare(b.date)
	if (dateComparison !== 0) {
		return dateComparison
	}

	const timeA = getTimeInMinutes(a.from)
	const timeB = getTimeInMinutes(b.from)
	return timeB - timeA
}

// Helper function to convert time to minutes
function getTimeInMinutes(timeString) {
	const [hours, minutes] = timeString.split(':').map(Number)
	return hours * 60 + minutes
}

function Hours(time1, time2, pause = 0) {
	const time1Parts = time1.split(':')
	const time2Parts = time2.split(':')

	const date1 = new Date(0, 0, 0, parseInt(time1Parts[0]), parseInt(time1Parts[1]))
	const date2 = new Date(0, 0, 0, parseInt(time2Parts[0]), parseInt(time2Parts[1]))

	let differenceMilliseconds

	if (date2 < date1) {
		// If time2 is earlier in the day than time1, add 24 hours to date2 to account for next day
		date2.setDate(date2.getDate() + 1)
	}

	differenceMilliseconds = Math.abs(date2 - date1) - pause * 60000

	const seconds = Math.floor((differenceMilliseconds / 1000) % 60)
	const minutes = Math.floor((differenceMilliseconds / (1000 * 60)) % 60)
	const hours = Math.floor(differenceMilliseconds / (1000 * 60 * 60))

	return hours
}

export default function AddMission({}) {
	const [user, setUser] = useState(null)
	const [loading, setLoading] = useState(false)
	const [cnxErr, setCnxErr] = useState(false)
	const [cities, setCities] = useState([])
	const [error, setError] = useState(null)

	const [startDate, setStartDate] = useState(null)

	const [endDate, setEndDate] = useState(null)

	const today = formatDate(new Date())
	const mindate = new Date().toISOString().split('T')[0]

	const [loadingJobs, setloadingJobs] = useState(false)
	const [loadingCategories, setLoadingCategories] = useState(false)
	const [loadingSubCategories, setLoadingSubCategories] = useState(false)
	const [jobsCatgories, setJobsCategories] = useState([])
	const [jobs, setJobs] = useState([])
	const [jobSubCatgories, setJobSubCategories] = useState([])
	const [settings, setSettings] = useState(null)
	const [periods, setPeriods] = useState([])
	const [loadingAddress, setLoadingAddress] = useState(false)

	const formik = useFormik({
		initialValues: {
			category: user?.category || '',
			subcategory: '',
			status: 'publish',
			start_date: today,
			available_positions: 1,
			job: '',
			hour_salary: '',
			details: '',
			publish_at: '',
			use_default_address: true,
			city: '',
			selectedCity: null,
			postal_code: '',
			address: '',
			address2: '',
		},
		enableReinitialize: true,
		validationSchema: Yup.object().shape({
			category: Yup.string().required('Ce champ est obligatiore'),
			subcategory: Yup.string().required('Ce champ est obligatiore'),
			job: Yup.string().required('Ce champ est obligatiore'),
			status: Yup.string().required('Ce champ est obligatiore'),
			hour_salary: Yup.number()
				.min(
					settings?.min_hour_salary ?? 1,
					'Tarif horaire minimum est ' + settings?.min_hour_salary || 1
				)
				.required('Ce champ est obligatiore'),
			available_positions: Yup.number().min(1).required('Ce champ est obligatiore'),
			publish_at: Yup.string()
				.nullable()
				.when('status', {
					is: val => val === 'publish_at',
					then: Yup.string()
						.required('Ce champ est obligatiore')
						.test(
							'dateComparison',
							"Cette date doit être supérieure à Aujourd'hui",
							function (value) {
								let d1 = new Date(value).setHours(0, 0, 0, 0)
								let d2 = new Date().setHours(0, 0, 0, 0)

								return d1 >= d2
							}
						),
					otherwise: Yup.string(),
				}),

			start_date: Yup.string()
				.required('Ce champ est obligatiore')
				.test(
					'dateComparison',
					"Cette date doit être supérieure à Aujourd'hui",
					function (value) {
						let d1 = new Date(value).setHours(0, 0, 0, 0)
						let d2 = new Date().setHours(0, 0, 0, 0)

						return d1 >= d2
					}
				),
			address: Yup.string().when('use_default_address', {
				is: false,
				then: Yup.string().required('Adresse est obligatoire *'),
				otherwise: Yup.string(),
			}),
			address2: Yup.string(),
			postal_code: Yup.string().when('use_default_address', {
				is: false,
				then: Yup.string()
					.required('code postal est obligatoire *')
					.test(
						'is-valid-postal-code',
						'Le code postal doit commencer par le code de la ville sélectionnée et contenir 5 chiffres',
						function (value) {
							const { selectedCity } = this.parent
							if (!selectedCity || !selectedCity.city_code || !value) return false
							const cityCode = selectedCity.city_code
							const postalCodePattern = new RegExp(
								`^${cityCode}\\d{${5 - cityCode.length}}$`
							)
							return (
								postalCodePattern.test(value) &&
								selectedCity.zip_codes.includes(value)
							)
						}
					),
				otherwise: Yup.string(),
			}),

			city: Yup.string(),
			selectedCity: Yup.object().when('use_default_address', {
				is: false,
				then: Yup.object()
					.shape({
						city: Yup.string().required('ville est obligatoire *'),
					})
					.nullable()
					.required('ville est obligatoire *'),
				otherwise: Yup.object().nullable(),
			}),
		}),
		onSubmit: function (values) {
			if (periods.length > 0) add(values)
			else showError('Vous devez ajouter au moins une période de temps')
		},
	})
	const formikPeriods = useFormik({
		initialValues: {
			date: today,
			from: '08:00',
			to: '17:00',
			pause: 60,
		},

		validationSchema: Yup.object().shape({
			date: Yup.string()
				.required('Ce champ est obligatiore')
				.test(
					'dateComparison',
					"Cette date doit être supérieure à Aujourd'hui ou dernier period",
					function (value) {
						let d1 = new Date(value).setHours(0, 0, 0, 0)
						let d2 = new Date().setHours(0, 0, 0, 0)
						let d3 = new Date(endDate).setHours(0, 0, 0, 0)

						return d1 >= d2 && d1 >= d3
					}
				),

			from: Yup.string()
				.required('Ce champ est obligatiore')
				.test(
					'dateComparison',
					'Cette date doit être supérieure à la date du dernier période créé',
					function (value) {
						const { date } = this.parent // Get endDate from parent object
						const currentDate = new Date() // Get current date

						// Parse the 'from' value into hours and minutes
						const [hours, minutes] = value.split(':').map(Number)

						// Create a new Date object using the parent date and 'from' value
						const fromDate = new Date(date)
						fromDate.setHours(hours, minutes)
						// console.log(fromDate > endDate)

						// Check if fromDate is greater than endDate or current date
						return fromDate > endDate
					}
				),

			to: Yup.string().required('Ce champ est obligatiore'),
		}),
		onSubmit: function (values) {
			// console.log(values)
			// today.setDate(today.getDate() + 1);
			const time1Parts = values.from.split(':')
			const time2Parts = values.to.split(':')
			const date = new Date(values.date)

			const date1 = new Date(
				date.getFullYear(),
				date.getMonth(),
				date.getDate(),
				parseInt(time1Parts[0]),
				parseInt(time1Parts[1])
			)

			let date2 = new Date(
				date.getFullYear(),
				date.getMonth(),
				date.getDate(),
				parseInt(time2Parts[0]),
				parseInt(time2Parts[1])
			)

			if (date2 < date1) {
				date2.setDate(date2.getDate() + 1)

				addPeriod({ ...values, next_day: formatDate(date2) })
			} else {
				addPeriod({ ...values, next_day: null })
			}
		},
	})
	const addPeriod = period => {
		let list = [...periods]

		list.push({ ...period, id: new Date().getTime() })

		let sorted = list.sort((a, b) => {
			const date1 = new Date(`${a.date}T${a.from}`)
			const date2 = new Date(`${b.date}T${b.from}`)

			return date1 - date2
		})

		if (sorted.length) {
			setStartDate(new Date(`${sorted[0].date}T${sorted[0].from}`))
			let end = sorted[[sorted.length - 1]]

			if (!end.next_day) {
				setEndDate(
					new Date(`${sorted[[sorted.length - 1]].date}T${sorted[sorted.length - 1].to}`)
				)
			} else {
				setEndDate(
					new Date(
						`${sorted[[sorted.length - 1]].next_day}T${sorted[sorted.length - 1].to}`
					)
				)
			}
		}
		setPeriods(sorted)
	}
	const calculateTotal = () => {
		const price = periods.reduce((acc, item) => {
			const time1Parts = item.from.split(':')
			const time2Parts = item.to.split(':')

			// Convert time parts to integers
			const fromHour = parseInt(time1Parts[0])
			const fromMinute = parseInt(time1Parts[1])
			const toHour = parseInt(time2Parts[0])
			const toMinute = parseInt(time2Parts[1])

			// Create Date objects with midnight set to the next day if 'to' is before 'from'
			const date1 = new Date(0, 0, 0, fromHour, fromMinute)
			const date2 = new Date(0, 0, 0, toHour, toMinute)
			if (toHour < fromHour || (toHour === fromHour && toMinute < fromMinute)) {
				date2.setDate(date2.getDate() + 1)
			}

			let pause = item.pause || 0 // Set pause to 0 if undefined

			const differenceMilliseconds = Math.abs(date2 - date1) - Number(pause * 60000)
			const hours = Math.floor(differenceMilliseconds / 3600000)
			const minutes = Math.floor((differenceMilliseconds % 3600000) / 60000) // 1 minute = 60000 milliseconds
			let tarif_min = Number(formik.values.hour_salary) / 60

			return acc + Number(formik.values.hour_salary) * hours + tarif_min * minutes
		}, 0)
		return price
	}
	const calculateHours = () => {
		const nb_hours = periods.reduce((acc, item) => {
			const time1Parts = item.from.split(':')
			const time2Parts = item.to.split(':')

			// Convert time parts to integers
			const fromHour = parseInt(time1Parts[0])
			const fromMinute = parseInt(time1Parts[1])
			const toHour = parseInt(time2Parts[0])
			const toMinute = parseInt(time2Parts[1])

			const date1 = new Date(0, 0, 0, fromHour, fromMinute)
			const date2 = new Date(0, 0, 0, toHour, toMinute)
			if (toHour < fromHour || (toHour === fromHour && toMinute < fromMinute)) {
				date2.setDate(date2.getDate() + 1)
			}

			let pause = item.pause || 0 // Set pause to 0 if undefined

			const differenceMilliseconds = Math.abs(date2 - date1) - Number(pause * 60000)

			const minutes = Math.floor(differenceMilliseconds / 60000) // 1 minute = 60000 milliseconds

			return acc + minutes
		}, 0)
		return `${String(Math.floor(nb_hours / 60)).padStart(2, '0')} h :${String(
			nb_hours % 60
		).padStart(2, '0')} min`
	}
	const getUser = () => {
		setLoading(true)

		api.get('/users/get')
			.then(res => {
				setUser(res.data)
				getSettings()
				getJobsCategories()
				getJobSubCategories(res.data?.category)
				setLoading(false)
			})
			.catch(err => {
				setCnxErr(true)
				setLoading(false)
			})
	}

	const deletePeriod = period => {
		let list = [...periods]

		list = list.filter(element => element.id !== period.id)

		let sorted = list.sort((a, b) => {
			// Concatenate date and to time for comparison

			const date1 = new Date(`${a.date}T${a.from}`)
			const date2 = new Date(`${b.date}T${b.from}`)

			return date1 - date2
		})
		if (sorted.length) {
			setStartDate(new Date(`${sorted[0].date}T${sorted[0].from}:00`))
			let end = sorted[[sorted.length - 1]]

			if (!end.next_day) {
				setEndDate(
					new Date(
						`${sorted[[sorted.length - 1]].date}T${sorted[sorted.length - 1].to}:00`
					)
				)
			} else {
				setEndDate(
					new Date(
						`${sorted[[sorted.length - 1]].next_day}T${sorted[sorted.length - 1].to}:00`
					)
				)
			}
		} else {
			setStartDate(null)
			setEndDate(null)
		}
		setPeriods(sorted)
	}
	const getSettings = () => {
		api.get('/users/get_settings')
			.then(res => {
				setSettings(res.data)
			})
			.catch(err => {})
	}
	useEffect(() => {
		getUser()
	}, [])

	const getJobsCategories = () => {
		setLoadingCategories(true)
		api.get('/admin/get_jobs_categories')
			.then(res => {
				setJobsCategories(res.data)
				setLoadingCategories(false)
			})
			.catch(err => {
				setLoadingCategories(false)
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}
	const getJobs = id => {
		setloadingJobs(true)
		api.get('/admin/get_jobs/' + id)
			.then(res => {
				setJobs(res.data)
				setloadingJobs(false)
			})
			.catch(err => {
				setloadingJobs(false)
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}

	const getJobSubCategories = id => {
		setLoadingSubCategories(true)
		api.get('/admin/get_job_sub_categories/' + id)
			.then(res => {
				setJobSubCategories(res.data)
				setLoadingSubCategories(false)
			})
			.catch(err => {
				setLoadingSubCategories(false)
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}

	const add = body => {
		api.post('/missions/add_mission', {
			...body,
			periods,
		})
			.then(res => {
				formik.resetForm()
				formikPeriods.resetForm()
				setStartDate(null)
				setEndDate(null)
				setPeriods([])
				showSuccess('Mission Ajouté')
				setError(null)
			})
			.catch(err => {
				showError('le serveur ne répond pas')
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}
	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const autocomplete = text => {
		setLoadingAddress(true)
		api.get('/users/city_autocomplete?text=' + text)
			.then(res => {
				setCities(res.data)

				setLoadingAddress(false)
			})
			.catch(err => {
				setLoadingAddress(false)
			})
	}

	if (loading) {
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '80vh',
				}}
			>
				<Stack
					spacing={2}
					display={'flex'}
					justifyContent="center"
					direction="column"
					alignItems="center"
				>
					<CircularProgress />
					<Typography>Chargement</Typography>
				</Stack>
			</Box>
		)
	}
	if (cnxErr) {
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '80vh',
				}}
			>
				<Stack
					spacing={2}
					display={'flex'}
					justifyContent="center"
					direction="column"
					alignItems="center"
				>
					<IconButton onClick={() => getUser()}>
						<Refresh />
					</IconButton>
					<Typography>probleme de connexion </Typography>
				</Stack>
			</Box>
		)
	}
	return (
		<Box>
			<form onSubmit={formik.handleSubmit}>
				<Stack direction={'row'} justifyContent={'space-between'}>
					<Typography variant="h5">Ajouter une mission</Typography>
					<LoadingButton variant="contained" type="submit" loading={loading}>
						Valider
					</LoadingButton>
				</Stack>
				<Grid sx={{ mt: 2 }} container spacing={1}>
					<Grid
						item
						xs={12}
						md={6}
						lg={6}
						container
						spacing={1}
						sx={{ borderRight: '2px solid #ccc', pr: 1 }}
					>
						<Grid item xs={12} md={12} lg={12}>
							<FormControl size="small" fullWidth>
								<InputLabel id="demo-simple-select-label">Catégorie</InputLabel>
								<Select
									labelId="demo-simple-select-label"
									id="demo-simple-select"
									value={formik.values.category}
									label="Catégorie"
									variant="outlined"
									size="small"
									name="category"
									onChange={event => {
										getJobSubCategories(event.target.value)
										formik.setFieldValue('category', event.target.value)
									}}
									error={Boolean(
										formik.touched.category && formik.errors.category
									)}
									helperText={formik.touched.category && formik.errors.category}
								>
									{jobsCatgories.length > 0 &&
										jobsCatgories.map(e => (
											<MenuItem value={e._id}>{e.name}</MenuItem>
										))}
								</Select>
								{formik.touched.category && formik.errors.category && (
									<FormHelperText sx={{ color: 'red' }}>
										{formik.touched.category && formik.errors.category}
									</FormHelperText>
								)}
							</FormControl>
						</Grid>
						{formik.values.category && (
							<Grid item xs={12} md={6} lg={6}>
								<FormControl size="small" fullWidth>
									<InputLabel id="demo-simple-select-label">
										Sous-Catégorie
									</InputLabel>
									<Select
										labelId="demo-simple-select-label"
										id="demo-simple-select"
										value={formik.values.subcategory}
										label="Sous-Catégorie"
										size="small"
										variant="outlined"
										name="subcategory"
										onChange={event => {
											getJobs(event.target.value)
											formik.setFieldValue('subcategory', event.target.value)
										}}
										error={Boolean(
											formik.touched.subcategory && formik.errors.subcategory
										)}
									>
										{jobSubCatgories.length > 0 &&
											jobSubCatgories.map(e => (
												<MenuItem value={e._id}>{e.name}</MenuItem>
											))}
									</Select>
									{formik.touched.subcategory && formik.errors.subcategory && (
										<FormHelperText sx={{ color: 'red' }}>
											{formik.touched.subcategory &&
												formik.errors.subcategory}
										</FormHelperText>
									)}
								</FormControl>
							</Grid>
						)}
						<Grid item xs={12} md={6} lg={6}>
							<FormControl size="small" fullWidth>
								<InputLabel id="demo-simple-select-label">Métier</InputLabel>
								<Select
									labelId="demo-simple-select-label"
									id="demo-simple-select"
									value={formik.values.job}
									label="Métier"
									size="small"
									variant="outlined"
									name="job"
									onChange={event => {
										formik.setFieldValue('job', event.target.value)
									}}
									error={Boolean(formik.touched.job && formik.errors.job)}
								>
									{jobs.length > 0 &&
										jobs
											.sort((a, b) => a.name.localeCompare(b.name))
											.map(e => <MenuItem value={e._id}>{e.name}</MenuItem>)}
								</Select>
								{formik.touched.job && formik.errors.job && (
									<FormHelperText sx={{ color: 'red' }}>
										{formik.touched.job && formik.errors.job}
									</FormHelperText>
								)}
							</FormControl>
						</Grid>
						<Grid item xs={12} md={6} lg={6}>
							<FormControl fullWidth variant="standard">
								<TextField
									label="Tarif/heure"
									name="hour_salary"
									size="small"
									min={1}
									type="number"
									onChange={formik.handleChange}
									onBlur={formik.handleBlur}
									value={formik.values.hour_salary}
									error={
										!!(formik.touched.hour_salary && formik.errors.hour_salary)
									}
									variant="outlined"
									helperText={formik.errors.hour_salary}
								/>
							</FormControl>
						</Grid>
						<Grid item xs={12} md={6} lg={6}>
							<FormControl fullWidth variant="standard">
								<TextField
									label="nombre de postes disponibles."
									name="available_positions"
									size="small"
									type="number"
									min={1}
									onChange={formik.handleChange}
									onBlur={formik.handleBlur}
									value={formik.values.available_positions}
									error={
										!!(
											formik.touched.available_positions &&
											formik.errors.available_positions
										)
									}
									variant="outlined"
									helperText={formik.errors.available_positions}
								/>
							</FormControl>
						</Grid>

						<Grid item xs={12} md={12} lg={12}>
							<FormControl fullWidth sx={{ my: 1 }} variant="standard">
								<TextField
									multiline
									rows={3}
									size="small"
									label="Détails du mission"
									name="details"
									onChange={formik.handleChange}
									onBlur={formik.handleBlur}
									value={formik.values.details}
									error={!!(formik.touched.details && formik.errors.details)}
									variant="outlined"
									helperText={formik.errors.details}
								/>
							</FormControl>
						</Grid>
						<Grid item xs={12} md={12} lg={12}>
							<Divider />
						</Grid>
						<Grid item xs={12} md={12} lg={12}>
							<Typography variant="subtitle1">Publication de la mission</Typography>

							<FormControl
								component="fieldset"
								error={formik.touched.status && Boolean(formik.errors.status)}
							>
								<RadioGroup
									aria-label="status"
									name="status"
									value={formik.values.status}
									onChange={formik.handleChange}
								>
									<FormControlLabel
										value="publish"
										control={<Radio />}
										label="Publier maintenant"
									/>
									<FormControlLabel
										value="draft"
										control={<Radio />}
										label="Enregistrer comme brouillon"
									/>
									<FormControlLabel
										value="publish_at"
										control={<Radio />}
										label="Programmer la publication"
									/>
									{formik.values.status == 'publish_at' && (
										<FormControl fullWidth sx={{ my: 1 }} variant="standard">
											<TextField
												label="Publier le "
												name="publish_at"
												type="date"
												size="small"
												onChange={formik.handleChange}
												onBlur={formik.handleBlur}
												value={formik.values.publish_at}
												error={
													!!(
														formik.touched.publish_at &&
														formik.errors.publish_at
													)
												}
												variant="outlined"
												helperText={formik.errors.publish_at}
												InputLabelProps={{
													shrink: true,
												}}
											/>
										</FormControl>
									)}
								</RadioGroup>
								{formik.touched.status && formik.errors.status ? (
									<FormHelperText>{formik.errors.status}</FormHelperText>
								) : null}
							</FormControl>
						</Grid>
						<Grid item xs={12} md={12} lg={12}>
							<Divider />
						</Grid>
						<Grid item xs={12} md={6} lg={6}>
							<FormControlLabel
								control={
									<Checkbox
										checked={formik.values.use_default_address}
										onChange={event => {
											formik.setFieldValue(
												'use_default_address',
												event.target.checked
											)
										}}
										inputProps={{ 'aria-label': 'controlled' }}
									/>
								}
								label="Utiliser l'adresse de l'établissement"
							/>
						</Grid>
						{formik.values.use_default_address ? (
							<Grid item xs={12} md={12} lg={12}>
								<Stack spacing={2} direction={'row'}>
									<Typography variant="subtitle2">
										Adresse actuelle :
										<address>
											{user?.address +
												', ' +
												user?.postal_code +
												' ,' +
												user?.city +
												' ,' +
												user?.state}
										</address>
									</Typography>
								</Stack>
							</Grid>
						) : (
							<Grid item xs={12} md={12} lg={12}>
								<Stack spacing={2}>
									<Autocomplete
										size="small"
										autoComplete={false}
										freeSolo
										options={cities}
										getOptionLabel={option =>
											option?.city_code +
											'-' +
											option?.city +
											' | ' +
											option?.state
										}
										loading={loadingAddress}
										inputValue={formik.values.city}
										onInputChange={(event, newInputValue) => {
											if (
												formik.values.selectedCity &&
												newInputValue !== formik.values.selectedCity.name
											) {
												formik.setFieldValue('selectedCity', null)
												formik.setFieldValue('city', '')
											} else {
												formik.setFieldValue('city', newInputValue)
												autocomplete(newInputValue)
											}
										}}
										value={formik.values.selectedCity}
										onChange={(event, newValue) => {
											formik.setFieldValue('selectedCity', newValue)
										}}
										renderInput={params => (
											<TextField
												{...params}
												label="Ville"
												variant="outlined"
												error={
													formik.touched.selectedCity &&
													Boolean(formik.errors.selectedCity)
												}
												helperText={
													formik.touched.selectedCity &&
													formik.errors.selectedCity
												}
												InputProps={{
													...params.InputProps,
													endAdornment: (
														<>
															{loadingAddress ? (
																<CircularProgress
																	color="inherit"
																	size={20}
																/>
															) : null}
															{params.InputProps.endAdornment}
														</>
													),
												}}
											/>
										)}
									/>

									<TextField
										fullWidth
										size="small"
										type="text"
										disabled={formik.values.selectedCity == null}
										name="postal_code"
										label="code postal"
										onChange={formik.handleChange}
										value={formik.values.postal_code}
										error={Boolean(
											formik.touched.postal_code && formik.errors.postal_code
										)}
										helperText={
											formik.touched.postal_code && formik.errors.postal_code
										}
									/>

									<TextField
										fullWidth
										size="small"
										autoComplete="address"
										type="text"
										name="address"
										disabled={formik.values.selectedCity == null}
										label="Adresse*"
										onChange={formik.handleChange}
										value={formik.values.address}
										error={Boolean(
											formik.touched.address && formik.errors.address
										)}
										helperText={formik.touched.address && formik.errors.address}
									/>

									<TextField
										fullWidth
										type="text"
										size="small"
										disabled={formik.values.selectedCity == null}
										name="address2"
										label="Complément d'adresse (Facultatif)"
										onChange={formik.handleChange}
										value={formik.values.address2}
										error={Boolean(
											formik.touched.address2 && formik.errors.address2
										)}
										helperText={
											formik.touched.address2 && formik.errors.address2
										}
									/>
								</Stack>
							</Grid>
						)}
					</Grid>
					<Grid container spacing={1} item xs={12} md={6} lg={6}>
						<Grid item xs={12} md={12} lg={12}>
							<Stack spacing={1}>
								<Typography variant="subtitle1">Durée du mission :</Typography>
								{periods.length == 0 && (
									<Typography variant="body2">
										Veuillez ajouter au moins une période ,<br />
										Le candidat ne devra pas dépasser{' '}
										{settings?.max_mission_hours}h de travail par jour
									</Typography>
								)}

								<form onSubmit={formikPeriods.handleSubmit}>
									<Grid mt={1} container spacing={2} columns={12}>
										<Grid item xs={12} md={8} lg={8}>
											<FormControl fullWidth variant="standard">
												<TextField
													label="Date"
													name="date"
													type="date"
													size="small"
													onChange={formikPeriods.handleChange}
													onBlur={formikPeriods.handleBlur}
													value={formikPeriods.values.date}
													error={
														!!(
															formikPeriods.touched.date &&
															formikPeriods.errors.date
														)
													}
													variant="outlined"
													helperText={formikPeriods.errors.date}
													InputLabelProps={{
														shrink: true,
													}}
													InputProps={{
														inputProps: {
															min: mindate,
														},
													}}
												/>
											</FormControl>
										</Grid>

										<Grid item xs={12} md={4} lg={4}></Grid>
										<Grid item xs={12} md={4} lg={4}>
											<FormControl fullWidth variant="standard">
												<TextField
													label="Du"
													name="from"
													size="small"
													step="3600"
													type="time"
													onChange={formikPeriods.handleChange}
													onBlur={formikPeriods.handleBlur}
													value={formikPeriods.values.from}
													error={
														!!(
															formikPeriods.touched.from &&
															formikPeriods.errors.from
														)
													}
													variant="outlined"
													helperText={formikPeriods.errors.from}
													InputLabelProps={{
														shrink: true,
													}}
												/>
											</FormControl>
										</Grid>
										<Grid item xs={12} md={4} lg={4}>
											<FormControl fullWidth variant="standard">
												<TextField
													label="Au"
													name="to"
													size="small"
													type="time"
													step="3600"
													onChange={formikPeriods.handleChange}
													onBlur={formikPeriods.handleBlur}
													value={formikPeriods.values.to}
													error={
														!!(
															formikPeriods.touched.to &&
															formikPeriods.errors.to
														)
													}
													variant="outlined"
													helperText={formikPeriods.errors.to}
													InputLabelProps={{
														shrink: true,
													}}
												/>
											</FormControl>
										</Grid>
										<Grid item xs={12} md={4} lg={4}>
											<FormControl fullWidth>
												<InputLabel>Pause</InputLabel>
												<Select
													size="small"
													name="pause"
													value={formikPeriods.values.pause}
													label="Select Time"
													onChange={formikPeriods.handleChange}
												>
													<MenuItem value={0}>pas de pause</MenuItem>
													<MenuItem value={15}>15 min</MenuItem>
													<MenuItem value={30}>30 min</MenuItem>
													<MenuItem value={45}>45 min</MenuItem>
													<MenuItem value={60}>1H</MenuItem>
													<MenuItem value={120}>2H</MenuItem>
												</Select>
											</FormControl>
										</Grid>
										<Grid item xs={12} md={6} lg={6}>
											<Paper variant="outlined">
												<Stack
													sx={{ height: 40, p: 1 }}
													direction={'row'}
													spacing={1}
													alignItems={'center'}
												>
													<Typography variant="subtitle2">
														Total :
													</Typography>
													<Typography
														color={
															Hours(
																formikPeriods.values.from,
																formikPeriods.values.to,
																formikPeriods.values.pause
															) > settings?.max_mission_hours
																? 'error'
																: 'standard'
														}
														variant="body2"
													>
														{msToHMS(
															formikPeriods.values.from,
															formikPeriods.values.to,
															formikPeriods.values.pause
														)}
													</Typography>
												</Stack>
											</Paper>
										</Grid>
										<Grid item xs={12} md={6} lg={6}>
											<FormControl fullWidth variant="standard">
												<Button
													disabled={
														Hours(
															formikPeriods.values.from,
															formikPeriods.values.to,
															formikPeriods.values.pause
														) > settings?.max_mission_hours
													}
													onClick={() => formikPeriods.submitForm()}
													color="primary"
													variant="contained"
												>
													{/* <PlusCircle /> */}
													Ajouter
												</Button>
											</FormControl>
										</Grid>
									</Grid>
								</form>
								<Divider />

								<Paper variant="outlined" sx={{ p: 2 }}>
									<Stack spacing={1}>
										{periods.length > 0 && (
											<Stack direction={'row'} spacing={2}>
												<Typography variant="subtitle2">
													De &nbsp;
													{moment(startDate?.toString()).format(
														'DD-MM-YYYY HH:mm'
													)}{' '}
													&nbsp;à &nbsp;
													{moment(endDate?.toString()).format(
														'DD-MM-YYYY HH:mm'
													)}
												</Typography>
												<Typography variant="subtitle2">
													&nbsp;|&nbsp; Heurs Total = &nbsp;
													{calculateHours()}
												</Typography>
											</Stack>
										)}
										<Divider />
										<Stack
											direction={'row'}
											spacing={2}
											justifyContent={'space-between'}
										>
											<Stack direction={'row'} spacing={1}>
												<Typography variant="subtitle2">
													Commission:
												</Typography>
												<Typography variant="body2">
													{settings?.commission * 100} %
												</Typography>
											</Stack>
											<Stack direction={'row'} spacing={1}>
												<Typography variant="subtitle2">TVA:</Typography>
												<Typography variant="body2">
													{settings?.tva * 100} %
												</Typography>
											</Stack>
											<Stack direction={'row'} spacing={1}>
												<Typography variant="subtitle2">
													TOTAL HT=
												</Typography>
												<Typography variant="body2">
													{calculateTotal().toFixed(2)}
												</Typography>
											</Stack>
										</Stack>
									</Stack>
								</Paper>

								<Divider />
								{periods &&
									periods.map((row, index) => (
										<Paper variant="outlined">
											<Stack
												direction="row"
												alignItems={'center'}
												justifyContent={'center'}
												spacing={3}
											>
												<Typography variant="subtitle2">
													<Today />
												</Typography>
												<Typography variant="subtitle2">
													{moment(row.date).format('DD-MM-YYYY')}
												</Typography>
												<Typography>|</Typography>
												<Typography variant="subtitle2">
													{row.from}
												</Typography>
												<Typography>|</Typography>
												<Typography variant="subtitle2">
													{row.to}
												</Typography>
												<Typography>|</Typography>
												<Typography variant="subtitle2">
													{msToHMS(row.from, row.to, row.pause)}
												</Typography>
												<IconButton onClick={() => deletePeriod(row)}>
													<Close />
												</IconButton>
											</Stack>
										</Paper>
									))}
							</Stack>
						</Grid>

						<Grid item xs={12} md={12} lg={12}></Grid>
					</Grid>
				</Grid>
			</form>
			<ToastContainer
				position="top-center"
				autoClose={3000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
			/>

			{error && <Alert severity="error">{error}</Alert>}
		</Box>
	)
}
