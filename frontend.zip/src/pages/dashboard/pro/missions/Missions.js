import { Refresh } from '@mui/icons-material'
import api from 'src/Api'
import {
	Button,
	Checkbox,
	Container,
	FormControl,
	FormControlLabel,
	Grid,
	InputLabel,
	MenuItem,
	Paper,
	Select,
	Skeleton,
	Stack,
	TextField,
	Typography,
} from '@mui/material'
import { useEffect, useState } from 'react'
import Page from 'src/components/Page'

import useSettings from 'src/hooks/useSettings'

import { useSelector } from 'react-redux'
import { Plus } from 'react-feather'
import { ToastContainer, toast } from 'react-toastify'
import MissionCard from './MissionCard'
import DeleteMission from './DeleteMission'
import { useNavigate } from 'react-router'

export default function Missions() {
	const { themeStretch } = useSettings()
	const auth = useSelector(state => state.auth)

	const [page, setPage] = useState(0)
	const [rowsPerPage, setRowsPerPage] = useState(25)
	const [loading, setLoading] = useState(false)
	const [selected, setSelected] = useState(null)
	const [user, setUser] = useState(null)
	const [missions, setMissions] = useState([])

	const [startDate, setStartDate] = useState('')

	const [subCategory, setSubCategory] = useState('all')
	const [job, setJob] = useState('all')
	const [jobs, setJobs] = useState([])
	const [subCategories, setSubCategories] = useState([])
	const [published, setPublished] = useState(true)

	const [err, set] = useState(false)

	const [openDelete, setOpenDelete] = useState(false)
	const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - missions.length) : 0
	const handleChangePage = (event, newPage) => {
		setPage(newPage)
	}
	const getJobs = id => {
		if (id !== 'all')
			api.get('/admin/get_jobs/' + id)
				.then(res => {
					setJobs(res.data)
				})
				.catch(err => {})
	}
	const getJobSubCategories = id => {
		if (id !== 'all')
			api.get('/admin/get_job_sub_categories/' + id)
				.then(res => {
					setSubCategories(res.data)
				})
				.catch(err => {})
	}
	const setExpanded = mission => {
		const expanded = mission.expanded ? false : true

		const updatedData = missions.map(item =>
			item._id === mission._id ? { ...mission, expanded } : item
		)
		setMissions(updatedData)
	}
	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const handleChangeRowsPerPage = event => {
		setRowsPerPage(parseInt(event.target.value, 10))
		setPage(0)
	}

	const getUser = () => {
		api.get('/users/get')
			.then(res => {
				setUser(res.data)
				getJobSubCategories(res.data.category)
			})
			.catch(err => {})
	}
	useEffect(() => {
		getUser()
		getMissions()
	}, [])

	const getMissions = () => {
		setPublished(true)
		setStartDate('')
		setSubCategory('all')
		setJob('all')
		setLoading(true)
		api.get('/missions/get_missions/' + auth?.user.id)
			.then(res => {
				setTimeout(() => {
					setMissions(res.data)
					setLoading(false)
				}, 1000)
			})
			.catch(err => {
				setLoading(false)
			})
	}
	const navigate = useNavigate()
	const filtred = missions.filter(
		item =>
			((startDate && new Date(item.start_date) >= new Date(startDate).setHours(0, 0, 0, 0)) ||
				!startDate) &&
			(subCategory == item?.job?.subcategory?._id || subCategory == 'all') &&
			(job == item?.job?._id || job == 'all') &&
			published == item.published
	)
	return (
		<>
			<Page title="Gestion des missions">
				<Container maxWidth={themeStretch ? false : 'xl'}>
					<Typography variant="h6" component="h6" paragraph>
						Gestion des missions
					</Typography>
					<Grid container spacing={1} columns={22}>
						<Grid item xs={22} md={4} lg={4}>
							<TextField
								label="	À partir de"
								name="start_date"
								type="date"
								size="small"
								fullWidth
								onChange={event => {
									setStartDate(event.target.value)
								}}
								variant="outlined"
								InputLabelProps={{
									shrink: true,
								}}
							/>
						</Grid>

						<Grid item xs={22} md={4} lg={4}>
							<FormControl size="small" fullWidth>
								<InputLabel id="demo-simple-select-label">
									Sous-Catégorie
								</InputLabel>
								<Select
									labelId="demo-simple-select-label"
									id="demo-simple-select"
									value={subCategory}
									label="Sous-Catégorie"
									size="small"
									variant="outlined"
									name="subcategory"
									onChange={event => {
										getJobs(event.target.value)
										setSubCategory(event.target.value)
									}}
								>
									<MenuItem value="all">Tous</MenuItem>
									{subCategories.length > 0 &&
										subCategories.map(e => (
											<MenuItem value={e._id}>{e.name}</MenuItem>
										))}
								</Select>
							</FormControl>
						</Grid>

						<Grid item xs={22} md={4} lg={4}>
							<FormControl size="small" fullWidth>
								<InputLabel id="demo-simple-select-label">Métier</InputLabel>
								<Select
									labelId="demo-simple-select-label"
									id="demo-simple-select"
									value={job}
									label="Métier"
									size="small"
									variant="outlined"
									name="job"
									onChange={event => {
										setJob(event.target.value)
									}}
								>
									<MenuItem value="all">Tous</MenuItem>
									{jobs.length > 0 &&
										jobs.map(e => <MenuItem value={e._id}>{e.name}</MenuItem>)}
								</Select>
							</FormControl>
						</Grid>
						<Grid item xs={22} md={2} lg={2}>
							<FormControlLabel
								control={
									<Checkbox
										checked={published}
										onChange={event => {
											setPublished(event.target.checked)
										}}
										inputProps={{ 'aria-label': 'controlled' }}
									/>
								}
								label="Publiée"
							/>
						</Grid>

						<Grid item xs={22} md={5} lg={5}>
							<Stack spacing={1} direction="row" alignItems="center">
								<Button
									sx={{ ml: 2, textTransform: 'none' }}
									variant="link"
									size="small"
									fullWidth
									onClick={() => getMissions()}
									startIcon={<Refresh />}
								>
									<Typography>Supprimer les filtres</Typography>
								</Button>
							</Stack>
						</Grid>
						<Grid item xs={22} md={3} lg={3}>
							<Stack spacing={1} direction="row" alignItems="center">
								<Button
									sx={{ ml: 2 }}
									variant="contained"
									size="small"
									fullWidth
									onClick={() => navigate('/dashboard/all_missions/add')}
									startIcon={<Plus />}
								>
									<Typography>Ajouter</Typography>
								</Button>
							</Stack>
						</Grid>
					</Grid>

					{!loading && filtred.length == 0 && (
						<Paper
							variant="outlined"
							sx={{
								display: 'flex',
								justifyContent: 'center',
								alignItems: 'center',
								py: 4,
							}}
						>
							<Typography>Aucun résultat</Typography>
						</Paper>
					)}

					{loading && (
						<Paper
							variant="outlined"
							sx={{
								mt: 2,
							}}
						>
							<Stack alignItems="center" spacing={1}>
								<Skeleton variant="rectangular" width={'100%'} height={40} />
							</Stack>
						</Paper>
					)}

					<Stack spacing={1}>
						{filtred.length > 0 &&
							filtred.map((row, index) => (
								<MissionCard
									row={row}
									// showError={showError}
									setExpanded={setExpanded}
									openDelete={() => {
										setSelected(row)
										setOpenDelete(true)
									}}
								/>
							))}
					</Stack>

					{selected && (
						<DeleteMission
							open={openDelete}
							close={() => setOpenDelete(false)}
							mission={selected}
							refresh={() => {
								getMissions()
								setOpenDelete(false)
							}}
							showSuccess={showSuccess}
							showError={showError}
							// user={user}
						/>
					)}
				</Container>
			</Page>
			<ToastContainer
				position="top-center"
				autoClose={3000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
			/>
		</>
	)
}
