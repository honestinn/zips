import {
	Alert,
	Autocomplete,
	Box,
	Button,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	Divider,
	FormControl,
	Grid,
	Switch,
	TextField,
} from '@mui/material'
import api from 'src/Api'
import { useFormik } from 'formik'
import { useEffect, useState } from 'react'

import * as Yup from 'yup'

import { LoadingButton } from '@mui/lab'
export default function Edit({ open, close, refresh, client }) {
	const [error, setError] = useState(null)
	const [loading, setLoding] = useState(false)

	const formik = useFormik({
		initialValues: {
			name: client.name,
			phone: client.phone,
			email: client.email,
		},
		validationSchema: Yup.object().shape({
			email: Yup.string().email().required('Ce champ est obligatiore'),

			name: Yup.string().max(50).required('Ce champ est obligatiore'),
			phone: Yup.string().required('Ce champ est obligatiore'),
		}),
		onSubmit: function (values) {
			edit(values)
		},
	})
	useEffect(() => {
		setError(null)

		formik.resetForm()
	}, [open])

	const edit = values => {
		setLoding(true)
		api.post('/admin/edit_admin/' + client._id, values)
			.then(res => {
				setLoding(false)
				close()
				formik.resetForm()
				setError(null)
				refresh()
			})
			.catch(err => {
				setLoding(false)
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}
	return (
		<Dialog fullWidth maxWidth="md" open={open} onClose={close}>
			<form onSubmit={formik.handleSubmit}>
				<DialogTitle>Modifier</DialogTitle>
				<DialogContent>
					<Grid sx={{ p: 2 }} container spacing={2}>
						<Grid item xs={12} sm={12} md={6} lg={6}>
							<TextField
								fullWidth
								type="text"
								name="name"
								label="Nom et prénom"
								onChange={formik.handleChange}
								value={formik.values.name}
								error={Boolean(formik.touched.name && formik.errors.name)}
								helperText={formik.touched.name && formik.errors.name}
							/>
						</Grid>
						<Grid item xs={12} sm={12} md={6} lg={6}>
							<TextField
								fullWidth
								type="text"
								name="email"
								label="Email"
								onChange={formik.handleChange}
								value={formik.values.email}
								error={Boolean(formik.touched.email && formik.errors.email)}
								helperText={formik.touched.email && formik.errors.email}
							/>
						</Grid>

						<Grid item xs={12} sm={6} md={6} lg={6}>
							<TextField
								fullWidth
								type="text"
								name="phone"
								label="N° Téléphone"
								onChange={formik.handleChange}
								value={formik.values.phone}
								error={Boolean(formik.touched.phone && formik.errors.phone)}
								helperText={formik.touched.phone && formik.errors.phone}
							/>
						</Grid>
					</Grid>
					{error && <Alert severity="error">{error}</Alert>}
				</DialogContent>

				<DialogActions>
					<LoadingButton type="submit" loading={loading}>
						Modifier
					</LoadingButton>
					<Button onClick={close}>annuler</Button>
				</DialogActions>
			</form>
		</Dialog>
	)
}
