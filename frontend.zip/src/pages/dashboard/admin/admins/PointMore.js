import { useRef, useState } from 'react';
import { Menu, MenuItem, IconButton, ListItemIcon, ListItemText, Divider } from '@mui/material';
import { Delete, Edit, Info, More, MoreVert, TramSharp } from '@mui/icons-material';

// ----------------------------------------------------------------------

export default function PointMore({ row, edit, remove, show }) {
  const ref = useRef(null);
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <IconButton ref={ref} onClick={() => setIsOpen(true)}>
        <MoreVert />
      </IconButton>

      <Menu
        open={isOpen}
        anchorEl={ref.current}
        onClose={() => setIsOpen(false)}
        PaperProps={{
          sx: { width: 200, maxWidth: '100%' },
        }}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <MenuItem
          onClick={() => {
            show(row);
          }}
        >
          <ListItemIcon>
            <Info />
          </ListItemIcon>
          <ListItemText>Info</ListItemText>
        </MenuItem>
        <MenuItem
          onClick={() => {
            edit(row);
          }}
        >
          <ListItemIcon>
            <Edit />
          </ListItemIcon>
          <ListItemText>Modifier</ListItemText>
        </MenuItem>
        <Divider />
        <MenuItem
          sx={{ color: 'red' }}
          onClick={() => {
            remove(row);
          }}
        >
          <ListItemIcon sx={{ color: 'red' }}>
            <Delete />
          </ListItemIcon>
          <ListItemText> Supprimer</ListItemText>
        </MenuItem>
      </Menu>
    </>
  );
}
