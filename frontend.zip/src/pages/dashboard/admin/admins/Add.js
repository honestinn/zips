import {
	Alert,
	Autocomplete,
	Box,
	Button,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	Divider,
	FormControl,
	Grid,
	Switch,
	TextField,
} from '@mui/material'
import api from 'src/Api'
import { useFormik } from 'formik'
import { useEffect, useState } from 'react'

import * as Yup from 'yup'
import { Upload } from '@mui/icons-material'
import { LoadingButton } from '@mui/lab'

export default function Add({ open, close, refresh }) {
	const [error, setError] = useState(null)
	const [loading, setLoding] = useState(false)

	const formik = useFormik({
		initialValues: {
			password: '',
			name: '',
			phone: '',
			email: '',
		},
		validationSchema: Yup.object().shape({
			email: Yup.string().email().required('Ce champ est obligatiore'),
			password: Yup.string().max(30).required('Ce champ est obligatiore'),
			name: Yup.string().max(50).required('Ce champ est obligatiore'),
			phone: Yup.string().required('Ce champ est obligatiore'),
		}),
		onSubmit: function (values) {
			add(values)
		},
	})
	useEffect(() => {
		setError(null)
		formik.resetForm()
	}, [open])

	const add = values => {
		api.post('/admin/add_admin', values)
			.then(res => {
				setLoding(false)
				close()
				formik.resetForm()
				setError(null)
				refresh()
			})
			.catch(err => {
				setLoding(false)
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data.error)
			})
	}
	return (
		<Dialog fullWidth maxWidth="md" open={open} onClose={close}>
			<form onSubmit={formik.handleSubmit}>
				<DialogTitle>Ajouter un Admin</DialogTitle>
				<DialogContent>
					<Grid sx={{ p: 2 }} container spacing={2}>
						<Grid item xs={12} sm={12} md={6} lg={6}>
							<TextField
								fullWidth
								type="text"
								name="name"
								label="Nom et prénom"
								onChange={formik.handleChange}
								value={formik.values.name}
								error={Boolean(formik.touched.name && formik.errors.name)}
								helperText={formik.touched.name && formik.errors.name}
							/>
						</Grid>
						<Grid item xs={12} sm={12} md={6} lg={6}>
							<TextField
								fullWidth
								type="text"
								name="email"
								label="Email"
								onChange={formik.handleChange}
								value={formik.values.email}
								error={Boolean(formik.touched.email && formik.errors.email)}
								helperText={formik.touched.email && formik.errors.email}
							/>
						</Grid>

						<Grid item xs={12} sm={6} md={6} lg={6}>
							<TextField
								fullWidth
								name="password"
								onChange={formik.handleChange}
								type="text"
								label="Mot de passe"
								value={formik.values.password}
								error={Boolean(formik.touched.password && formik.errors.password)}
								helperText={formik.touched.password && formik.errors.password}
							/>
						</Grid>

						<Grid item xs={12} sm={6} md={6} lg={6}>
							<TextField
								fullWidth
								type="text"
								name="phone"
								label="N° Téléphone"
								onChange={formik.handleChange}
								value={formik.values.phone}
								error={Boolean(formik.touched.phone && formik.errors.phone)}
								helperText={formik.touched.phone && formik.errors.phone}
							/>
						</Grid>
					</Grid>

					{error && <Alert severity="error">{error}</Alert>}
				</DialogContent>

				<DialogActions>
					<LoadingButton type="submit" loading={loading}>
						Ajouter
					</LoadingButton>
					<Button onClick={close}>annuler</Button>
				</DialogActions>
			</form>
		</Dialog>
	)
}
