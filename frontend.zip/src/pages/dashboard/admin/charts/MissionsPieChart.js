import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux'
import { PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import api from 'src/Api'

const MissionsPieChart = () => {
    const auth = useSelector(state => state.auth)
    const [missionTitles, setMissionTitles] = useState([]);
    const [loading, setLoading] = useState(false)
	const [error, setError] = useState(false)
	const [missions, setMissions] = useState([])

	useEffect(() => {
		getMissions()
	}, [])
	const getMissions = () => {
		setLoading(true)

		api.get('/missions/get_all_missions/' + auth.user.id)
			.then(res => {
				setMissions(res.data)
				setMissionTitles(res.data.map(mission => mission.job?.name))
				setLoading(false)

				setError(false)
			})
			.catch(err => {
				setLoading(false)
				setError(true)
			})
	}

    const groupJobs = (titles) => {
        if (!titles || titles.length === 0) return [];
        return Object.entries(titles.reduce((acc, job) => {
            acc[job] = (acc[job] || 0) + 1;
            return acc;
        }, {})).map(([name, count]) => ({ name, count }));
    };

    const data = groupJobs(missionTitles);
    const COLORS = ['#FFBB28', '#FF8042', '#0088FE'];

    return (
        <div className="chart-container">
            <PieChart width={400} height={400}>
                <Pie
                    data={data}
                    dataKey="count"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    label
                >
                    {data.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                </Pie>
                <Tooltip />
                <Legend />
            </PieChart>
        </div>
    );
};

export default MissionsPieChart;
