import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { LineChart, Line, XAxis,YAxis,CartesianGrid, Tooltip, Legend,  ResponsiveContainer } from "recharts";
import api from "src/Api";
import moment from "moment";
import frLocale from "moment/locale/fr";

const CAChart = () => {
  const auth = useSelector((state) => state.auth);
  const [months, setMonths] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [invoices, setInvoices] = useState([]);
  moment.locale('fr', frLocale)
  function groupByMonthYearAndSumTh(data, year) {
    // Créer une structure pour tous les mois de l'année spécifiée
    const monthsOfYear = Array.from({ length: 12 }, (_, index) => moment().month(index).format("YYYY-MM"));
    
    // Initialiser l'objet result avec chaque mois de l'année à 0
    const result = monthsOfYear.reduce((acc, monthYear) => {
      acc[monthYear] = { monthYear, thSum: 0 };
      return acc;
    }, {});
  
    // Parcourir les données et additionner 'th' pour chaque mois/année spécifique
    data.forEach(item => {
      const monthYear = moment(item.updated_at).format("YYYY-MM");
      if (monthYear.startsWith(year)) {
        result[monthYear].thSum += item.th;
      }
    });
    for (const key in result) {
        if (result.hasOwnProperty(key)) {
          const item = result[key];
          
          // Format de la date au format MMM YY
          item.monthYear = moment(item.monthYear, 'YYYY-MM').format('MMM YYYY');
          
          // Arrondir thSum à deux chiffres après la virgule
          item.thSum = item.thSum.toFixed(2);
        }
      }
  
    // Retourner les valeurs sous forme de tableau
    return Object.values(result);
  }

  useEffect(() => {
    getInvoices();
  }, []);
  const getInvoices = () => {
    setLoading(true);

    api
      .get("/missions/get_all_invoices/" + auth.user.id)
      .then((res) => {
        setInvoices(groupByMonthYearAndSumTh(res.data, 2024));
        setLoading(false);
        setError(false);
      })
      .catch((err) => {
        setLoading(false);
        setError(true);
      });
  };
  const CustomTooltip = ({ payload, label, active }) => {
    if (active && payload && payload.length) {
      const value = payload[0].value; // The value from the payload
      return (
        <div className="custom-tooltip" style={{ backgroundColor: '#fff', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }}>
          <p>{`${moment(label, 'YYYY-MM').format('MMMM YYYY')}`}</p>
          <p>{`CA: ${value} €`}</p>
        </div>
      );
    }
    return null;
  };

  //const data = groupJobs(missionTitles);

  const COLORS = ["#FFBB28", "#FF8042", "#0088FE"];
  //console.log(missions)


  return (
    <div className="chart-container">
<ResponsiveContainer width="100%" height={400}>
  <LineChart
    data={invoices}
    margin={{ top: 20, right: 40, left: 20, bottom: 20 }}
  >
    {/* Add a grid for a cleaner look */}
    <CartesianGrid strokeDasharray="3 3" stroke="#ddd" />
    
    {/* X Axis with custom styles */}
    <XAxis 
      dataKey="monthYear" 
      style={{ fontSize: '14px', fontWeight: 'bold', fill: '#666',  }} 
      padding={{ left: 30, right: 30 }}
      tickLine={false}  // Remove the tick lines for a cleaner look
    />
    
    {/* Y Axis with custom styles */}
    <YAxis 
      style={{ fontSize: '14px', fontWeight: 'bold', fill: '#666' }} 
      tickLine={false}  // Remove the tick lines for a cleaner look
      tickFormatter={value => `${value} €`}
    />
    
    {/* Tooltip with custom content */}
    <Tooltip 
      contentStyle={{ backgroundColor: '#fff', border: '1px solid #ddd' }} 
      labelStyle={{ fontWeight: 'bold' }}
      content={CustomTooltip}
    />
    
    {/* Legend with custom styles */}
    <Legend wrapperStyle={{ fontSize: '14px', color: '#333' }} />
    
    {/* Line with custom color and smoothness */}
    <Line 
      type="monotone" 
      dataKey="thSum" 
      stroke="#8884d8" 
      strokeWidth={2} 
      dot={{ fill: '#8884d8', stroke: '#fff', strokeWidth: 2 }} // Customize dots
      activeDot={{ r: 8, stroke: '#fff', strokeWidth: 2 }} // Customize active dots
    />
  </LineChart>
</ResponsiveContainer>


    </div>
  );
};

export default CAChart;
