import {
	Button,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	Typography,
} from '@mui/material'

import { useEffect, useState } from 'react'

import MissionDetails from './MissionDetails'

export default function Show({ open, close, row }) {
	useEffect(() => {}, [open])

	return (
		<Dialog fullWidth maxWidth="md" open={open} onClose={close}>
			<DialogTitle sx={{ display: 'flex', justifyContent: 'space-between' }}>
				<Typography>Information :</Typography>
			</DialogTitle>
			<DialogContent>
				<MissionDetails row={{ ...row, client: row?.client }} />
			</DialogContent>
			<DialogActions>
				<Button onClick={close}>Quitter</Button>
			</DialogActions>
		</Dialog>
	)
}
