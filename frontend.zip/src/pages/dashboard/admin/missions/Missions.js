import { Info, Refresh, Search, StopCircle, WifiOff } from '@mui/icons-material'
import api from 'src/Api'
import {
	Box,
	Button,
	Card,
	CardContent,
	CircularProgress,
	Container,
	FormControl,
	IconButton,
	InputAdornment,
	OutlinedInput,
	Paper,
	Stack,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	Typography,
	TableSortLabel,
} from '@mui/material'
import { useEffect, useState } from 'react'
import Page from 'src/components/Page'

import useSettings from 'src/hooks/useSettings'
import Show from './Show'
import { useSelector } from 'react-redux'
import { ToastContainer, toast } from 'react-toastify'
import { confirmAlert } from 'react-confirm-alert'
import moment from 'moment'

export default function Missions() {
	const { themeStretch } = useSettings()
	const auth = useSelector(state => state.auth)
	const [search, setSearch] = useState('')
	const [page, setPage] = useState(0)
	const [rowsPerPage, setRowsPerPage] = useState(25)
	const [loading, setLoading] = useState(false)
	const [selected, setSelected] = useState(null)
	const [missions, setMissions] = useState([])
	const [order, setOrder] = useState('asc')
	const [orderBy, setOrderBy] = useState('')
	const [openShow, setOpenShow] = useState(false)
	const [error, setError] = useState(false)
	const [selectedApplicationId, setSelectedApplicationId] = useState('')

	const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - missions.length) : 0

	const handleRequestSort = (event, property) => {
		const isAsc = orderBy === property && order === 'asc'
		setOrder(isAsc ? 'desc' : 'asc')
		setOrderBy(property)
	}

	const handleChangePage = (event, newPage) => {
		setPage(newPage)
	}

	const handleChangeRowsPerPage = event => {
		setRowsPerPage(parseInt(event.target.value, 10))
		setPage(0)
	}

	const getMissions = () => {
		setLoading(true)
		api.get('/missions/get_all_missions/' + auth.user.id)
			.then(res => {
				setMissions(res.data)
				setLoading(false)
				setError(false)
			})
			.catch(err => {
				setLoading(false)
				setError(true)
			})
	}

	useEffect(() => {
		getMissions()
	}, [])

	const replace = data => {
		const application = missions.find(e => e._id == data._id)
		const updatedData = missions.map(item =>
			item._id == data._id ? { ...application, status: data.status } : item
		)
		setMissions(updatedData)
		setSelected({ ...application, status: data.status })
	}

	const cancel = id => {
		let msg = 'Votre action enverra annuler la candidature.'
		setSelectedApplicationId(id)
		confirmAlert({
			customUI: ({ onClose }) => dialog(onClose, sendCancelRequest, id, msg),
			closeOnEscape: true,
			closeOnClickOutside: true,
			overlayClassName: 'overlay',
		})
	}

	const sendCancelRequest = () => {
		api.post('/missions/cancel_user_application', { applicationId: selectedApplicationId })
			.then(res => {
				showSuccess('envoyé!')
			})
			.catch(err => {
				showError('erreur')
			})
	}

	const dialog = (onClose, submit, id, msg) => (
		<Card sx={{ minWidth: 500, p: 2 }}>
			<CardContent>
				<Typography variant="h6">Êtes-vous sûr(e) ?</Typography>
				<Typography sx={{ m: 2 }} variant="subtitle2" color="error">
					{msg}
				</Typography>
			</CardContent>
			<Stack direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }}>
				<Button
					onClick={() => {
						submit(id)
						onClose()
					}}
					variant="outlined"
					size="large"
				>
					Oui
				</Button>
				<Button onClick={onClose} size="large">
					Quitter
				</Button>
			</Stack>
		</Card>
	)

	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}

	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}

	const sortData = (array) => {
		if (orderBy) {
			return array.sort((a, b) => {
				if (a[orderBy] < b[orderBy]) {
					return order === 'asc' ? -1 : 1
				}
				if (a[orderBy] > b[orderBy]) {
					return order === 'asc' ? 1 : -1
				}
				return 0
			})
		}
		return array
	}

	// Fonction de recherche : filtre les missions en fonction de la saisie
	const filteredMissions = missions.filter(
		e =>
			e.client.name.toLowerCase().includes(search.toLowerCase()) ||
			e.job.subcategory.name.toLowerCase().includes(search.toLowerCase()) ||
			e.job.name.toLowerCase().includes(search.toLowerCase()) ||
			e.job._id.toLowerCase().includes(search.toLowerCase()) // Recherche sur l'ID de job
	)

	const sortedMissions = sortData(filteredMissions)

	return (
		<>
			<Page title="Gestion des missions">
				<Container maxWidth={themeStretch ? false : 'xl'}>
					<Typography variant="h6" component="h6" paragraph>
						Gestion des missions
					</Typography>

					<Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
						<FormControl sx={{ mx: 1, width: '400px' }} variant="outlined">
							<OutlinedInput
								size="small"
								placeholder="Chercher"
								type="text"
								onChange={e => {
									setSearch(e.target.value)
								}}
								value={search}
								endAdornment={
									<InputAdornment position="end">
										<IconButton edge="end">
											<Search />
										</IconButton>
									</InputAdornment>
								}
							/>
						</FormControl>
						<Box>
							<Button
								sx={{ ml: 2 }}
								variant="outlined"
								onClick={getMissions}
								startIcon={<Refresh />}
							>
								<Typography sx={{ mx: 2 }}>Actualiser</Typography>
							</Button>
						</Box>
					</Box>
					<Paper variant="outlined" sx={{ mt: 2, p: 1 }}>
						<TableContainer>
							<Table size="small">
								<TableHead>
									<TableRow>
										<TableCell>
											<TableSortLabel
												active={orderBy === 'client.name'}
												direction={orderBy === 'client.name' ? order : 'asc'}
												onClick={event => handleRequestSort(event, 'client.name')}
											>
												Client
											</TableSortLabel>
										</TableCell>
										<TableCell>
											<TableSortLabel
												active={orderBy === 'job.name'}
												direction={orderBy === 'job.name' ? order : 'asc'}
												onClick={event => handleRequestSort(event, 'job.name')}
											>
												Mission
											</TableSortLabel>
										</TableCell>
										<TableCell>
											<TableSortLabel
												active={orderBy === 'nb_condidat'}
												direction={orderBy === 'nb_condidat' ? order : 'asc'}
												onClick={event => handleRequestSort(event, 'nb_condidat')}
											>
												Nb. candidatures
											</TableSortLabel>
										</TableCell>
										<TableCell>
											<TableSortLabel
												active={orderBy === 'start_date'}
												direction={orderBy === 'start_date' ? order : 'asc'}
												onClick={event => handleRequestSort(event, 'start_date')}
											>
												Début - Fin
											</TableSortLabel>
										</TableCell>
										<TableCell>
											<TableSortLabel
												active={orderBy === 'created_at'}
												direction={orderBy === 'created_at' ? order : 'asc'}
												onClick={event => handleRequestSort(event, 'created_at')}
											>
												Créé le
											</TableSortLabel>
										</TableCell>
										<TableCell>Actions</TableCell>
									</TableRow>
								</TableHead>
								<TableBody>
									{loading ? (
										<TableRow>
											<TableCell colSpan={6} align="center">
												<CircularProgress />
											</TableCell>
										</TableRow>
									) : error ? (
										<TableRow>
											<TableCell colSpan={6} align="center">
												<WifiOff />
												<Typography variant="subtitle2" color="error">
													Une erreur s'est produite. Vérifiez votre connexion ou réessayez plus tard.
												</Typography>
											</TableCell>
										</TableRow>
									) : sortedMissions.length === 0 ? (
										<TableRow>
											<TableCell colSpan={6} align="center">
												<Typography variant="subtitle2" color="textSecondary">
													Aucune mission disponible.
												</Typography>
											</TableCell>
										</TableRow>
									) : (
										sortedMissions.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => (
											
											<TableRow hover key={index}>
												<TableCell>{row.client.name}</TableCell>
												<TableCell>    
													<Typography variant="body1">{row.job.name}</Typography>
													<Typography variant="body2" color="textSecondary">{row.uid}</Typography>
												</TableCell>
												<TableCell>{row.nb_condidat}</TableCell>
												<TableCell>
  {moment(row.start_date).isSame(moment(row.end_date), 'day') ? (
    <>
      {moment(row.start_date).format('DD/MM/YYYY')} de {moment(row.start_date).format('HH:mm')} à {moment(row.end_date).format('HH:mm')}
    </>
  ) : (
    <>
      {moment(row.start_date).format('DD/MM/YYYY')} - {moment(row.end_date).format('DD/MM/YYYY')}
    </>
  )}
</TableCell>

												<TableCell>{moment(row.created_at).format('DD/MM/YYYY')}</TableCell>
												<TableCell sx={{ display: 'flex', justifyContent: 'center' }}>
													<IconButton onClick={() => cancel(row._id)} color="secondary">
														<StopCircle />
													</IconButton>
													<IconButton onClick={() => setOpenShow(true)} color="primary">
														<Info />
													</IconButton>
												</TableCell>
											</TableRow>
										))
									)}
								</TableBody>
							</Table>
						</TableContainer>
					</Paper>
				</Container>
			</Page>
			<ToastContainer />
		</>
	)
}
