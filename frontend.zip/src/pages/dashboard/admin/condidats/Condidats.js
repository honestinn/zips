import { Info, Refresh, Search } from '@mui/icons-material'
import api, { FILES_URL } from 'src/Api'
import {
	Avatar,
	Box,
	Button,
	Card,
	Chip,
	CircularProgress,
	Container,
	FormControl,
	IconButton,
	InputAdornment,
	OutlinedInput,
	Stack,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	TablePagination,
	TableSortLabel,
	Typography,
} from '@mui/material'
import { useEffect, useState } from 'react'
import Page from 'src/components/Page'
import useSettings from 'src/hooks/useSettings'
import { useNavigate } from 'react-router'

export default function Candidats() {
	const { themeStretch } = useSettings() // Récupère les paramètres du thème
	const navigate = useNavigate() // Permet de naviguer entre les pages
	const [search, setSearch] = useState('') // État pour la recherche
	const [page, setPage] = useState(0) // État pour la page actuelle de la pagination
	const [rowsPerPage, setRowsPerPage] = useState(20) // Nombre de lignes par page
	const [loading, setLoading] = useState(false) // État de chargement
	const [selected, setSelected] = useState(null) // État pour l'élément sélectionné
	const [candidats, setCandidats] = useState([]) // Liste complète des candidats
	const [filteredCandidats, setFilteredCandidats] = useState([]) // Liste filtrée des candidats selon la recherche
	const [order, setOrder] = useState('asc') // État pour l'ordre de tri (ascendant/décendant)
	const [orderBy, setOrderBy] = useState('name') // État pour la colonne par laquelle trier
	const [error, setError] = useState(false) // État pour les erreurs de chargement

	// Calcule le nombre de lignes vides à afficher pour un alignement correct dans la pagination
	const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - filteredCandidats.length) : 0

	// Fonction pour changer de page
	const handleChangePage = (event, newPage) => {
		setPage(newPage) // Met à jour la page actuelle
	}

	// Fonction pour changer le nombre de lignes par page
	const handleChangeRowsPerPage = event => {
		setRowsPerPage(parseInt(event.target.value, 10)) // Met à jour le nombre de lignes par page
		setPage(0) // Réinitialise à la première page
	}

	// Fonction pour remplacer les données d'un candidat dans la liste
	const replace = data => {
		const updatedData = candidats.map(item => (item._id === data._id ? { ...data } : item))
		setCandidats(updatedData) // Met à jour la liste des candidats
		setSelected(data) // Met à jour l'élément sélectionné
	}

	// Utilise useEffect pour récupérer les candidats lors du premier rendu du composant
	useEffect(() => {
		getCandidats()
	}, [])

	// Fonction pour récupérer les candidats depuis l'API
	const getCandidats = () => {
		setLoading(true) // Démarre le chargement
		api.get('/admin/get_condidats')
			.then(res => {
				setCandidats(res.data) // Met à jour la liste des candidats
				setFilteredCandidats(res.data) // Initialise la liste filtrée
				setLoading(false) // Arrête le chargement
				setError(false) // Réinitialise l'état d'erreur
			})
			.catch(err => {
				setLoading(false) // Arrête le chargement en cas d'erreur
				setError(true) // Indique une erreur
			})
	}

	// Fonction de recherche qui filtre les candidats selon le texte saisi
	const handleSearch = e => {
		setPage(0)
		setSearch(e.target.value) // Met à jour la valeur de recherche
		const searchValue = e.target.value.toLowerCase() // Met tout en minuscule pour comparaison
		const filtered = candidats.filter(candidate => {
			const fullName = candidate.name.toLowerCase() // Nom en minuscule
			const email = candidate.email.toLowerCase() // Email en minuscule
			const phone = candidate.phone.toLowerCase() // Téléphone en minuscule
			return (
				fullName.includes(searchValue) || // Filtre par nom
				email.includes(searchValue) || // Filtre par email
				phone.includes(searchValue) // Filtre par téléphone
			)
		})
		setFilteredCandidats(filtered) // Met à jour la liste filtrée des candidats
	}

	// Fonction de tri pour changer l'ordre des colonnes
	const handleRequestSort = (event, property) => {
		const isAsc = orderBy === property && order === 'asc' // Vérifie si l'ordre est ascendant
		setOrder(isAsc ? 'desc' : 'asc') // Change l'ordre
		setOrderBy(property) // Met à jour la colonne par laquelle trier
	}

	// Fonction pour trier les candidats selon la colonne sélectionnée
	const sortedCandidats = filteredCandidats.slice().sort((a, b) => {
		const isAsc = order === 'asc' // Vérifie l'ordre
		if (orderBy === 'name') return (a.name < b.name ? -1 : 1) * (isAsc ? 1 : -1) // Trie par nom
		if (orderBy === 'phone') return (a.phone < b.phone ? -1 : 1) * (isAsc ? 1 : -1) // Trie par téléphone
		if (orderBy === 'email') return (a.email < b.email ? -1 : 1) * (isAsc ? 1 : -1) // Trie par email
		if (orderBy === 'status') return (a.unverified_steps.includes(-1) ? -1 : 1) * (isAsc ? 1 : -1) // Trie par statut
		if (orderBy === 'rating') return (a.rating - b.rating) * (isAsc ? 1 : -1) // Trie par évaluation
		return 0 // Par défaut, ne change pas l'ordre
	})

	return (
		<>
			<Page title="Gestion des collaborateurs">
				<Container maxWidth={themeStretch ? false : 'xl'}>
					<Typography variant="h4" component="h4" paragraph>
						Gestion des collaborateurs
					</Typography>

					{/* Barre de recherche et bouton d'actualisation */}
					<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
						<FormControl sx={{ mx: 1, width: '400px' }} variant="outlined">
							<OutlinedInput
								size="small"
								placeholder="Rechercher"
								type="text"
								onChange={handleSearch} // Gère le changement de texte dans le champ de recherche
								value={search}
								endAdornment={
									<InputAdornment position="end">
										<IconButton edge="end">
											<Search />
										</IconButton>
									</InputAdornment>
								}
							/>
						</FormControl>
						<Box>
							<Button
								sx={{ ml: 2 }}
								variant="outlined"
								onClick={getCandidats} // Actualise la liste des candidats
								startIcon={<Refresh />}
							>
								<Typography sx={{ mx: 2 }}>Actualiser</Typography>
							</Button>
						</Box>
					</Box>

					{/* Tableau des candidats */}
					<Card sx={{ borderRadius: 1, mt: 3 }}>
						<TableContainer sx={{ width: '100%' }}>
							<Table size="small">
								<TableHead>
									<TableRow>
										{[
											{ id: 'name', label: 'Nom' },
											{ id: 'phone', label: 'N° Téléphone' },
											{ id: 'email', label: 'Email' },
											{ id: 'status', label: 'Statut' },
											{ id: 'rating', label: 'Évaluation' }
										].map(column => (
											<TableCell
												key={column.id}
												sortDirection={orderBy === column.id ? order : false} // Définit la direction de tri de la colonne
											>
												<TableSortLabel
													active={orderBy === column.id} // Indique si la colonne est active pour le tri
													direction={orderBy === column.id ? order : 'asc'} // Définit la direction du tri
													onClick={event => handleRequestSort(event, column.id)} // Gère le clic pour trier
												>
													{column.label} {/* Affiche le label de la colonne */}
												</TableSortLabel>
											</TableCell>
										))}
										<TableCell sx={{ textAlign: 'center' }}>Options</TableCell> {/* Colonne pour les options */}
									</TableRow>
								</TableHead>

								<TableBody>
    {/* Si en cours de chargement */}
    {loading ? (
        <TableRow>
            <TableCell colSpan={6} align="center" sx={{ py: 5 }}>
                <Box display="flex" alignItems="center" flexDirection="column">
                    <CircularProgress size={30} sx={{ mb: 2 }} />
                    <Typography variant="body1" color="textSecondary">
                        Veuillez patienter...
                    </Typography>
                </Box>
            </TableCell>
        </TableRow>
    ) : (
        // Si aucun résultat après la recherche
        filteredCandidats.length === 0 ? (
            <TableRow>
                <TableCell colSpan={6} align="center" sx={{ py: 5 }}>
                    <Typography variant="h6" color="textSecondary">
                        Aucun résultat trouvé
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                        Essayez de changer les critères de recherche.
                    </Typography>
                </TableCell>
            </TableRow>
        ) : (
            // Affichage des résultats triés et filtrés
            sortedCandidats
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map(row => (
                    <TableRow hover key={row._id} tabIndex={-1}>
                        {/* Contenu de la ligne de candidat */}
                        <TableCell>
                            <Stack direction="row" alignItems="center" spacing={2}>
                                <Avatar
                                    sx={{ mx: 2 }}
                                    alt=""
                                    src={
                                        row.avatar.length > 0
                                            ? FILES_URL + row.avatar
                                            : '/statics/avatar.png'
                                    }
                                />
                                <Typography variant="subtitle2" noWrap>
                                    {row.name} {row.fname}
                                </Typography>
                            </Stack>
                        </TableCell>
                        <TableCell>{row.phone}</TableCell>
                        <TableCell       onClick={() => window.location.href = `mailto:${row.email}`} style={{ cursor: 'pointer' }}>{row.email}</TableCell>
                        <TableCell>
                            <Chip
                                label={
                                    row.unverified_steps.includes(-1)
                                        ? 'Non Validé'
                                        : 'Validé'
                                }
                                color={
                                    row.unverified_steps.includes(-1)
                                        ? 'error'
                                        : 'success'
                                }
                            />
                        </TableCell>
                        <TableCell sx={{ textAlign: 'center' }}>{row.rating}</TableCell>
                        <TableCell sx={{ textAlign: 'center' }}>
                            <IconButton
                                onClick={() => navigate('/dashboard/candidats/' + row._id)}
                            >
                                <Info />
                            </IconButton>
                        </TableCell>
                    </TableRow>
                ))
        )
    )}
    {emptyRows > 0 && (
        <TableRow style={{ height: 53 * emptyRows }}>
            <TableCell colSpan={6} />
        </TableRow>
    )}
</TableBody>

							</Table>
						</TableContainer>
						{/* Pagination pour naviguer entre les pages */}
						<TablePagination
							rowsPerPageOptions={[10, 20, 25, 50]}
							component="div"
							count={filteredCandidats.length}
							rowsPerPage={rowsPerPage}
							page={page}
							onPageChange={handleChangePage}
							onRowsPerPageChange={handleChangeRowsPerPage}
							labelRowsPerPage="Lignes par page"
							labelDisplayedRows={({ from, to, count }) =>
								`${from}-${to} sur ${count !== -1 ? count : `plus de ${to}`}`
							}
						/>
					</Card>
				</Container>
			</Page>
		</>
	)
}
