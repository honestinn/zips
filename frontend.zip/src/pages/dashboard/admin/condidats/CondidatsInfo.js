import {
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Grid,
  IconButton,
  Paper,
  Stack,
  Switch,
  Typography,
} from "@mui/material";
import { Worker, Viewer } from "@react-pdf-viewer/core";
import "@react-pdf-viewer/core/lib/styles/index.css";
import api, { FILES_URL } from "src/Api";

import { useEffect, useState } from "react";

import {
  CheckCircle,
  HighlightOff,
  Refresh,
  Upload,
  Phone,
  Email,
  LocationOn,
  CheckCircleOutline,
  ErrorOutline,
} from "@mui/icons-material";

import { confirmAlert } from "react-confirm-alert";

import { APP_URL } from "src/config";
import { Link as MuiLink } from "@mui/material";
import { Navigate, useParams } from "react-router";
import ValidateDialog from "./ValidateDialog";
import { toast } from "react-toastify";
import Image from "src/components/Image";

export default function CondidatsInfo({}) {
  const { id } = useParams();
  const [client, setClient] = useState(false);
  const [loading, setLoading] = useState(false);
  const [cnxErr, setCnxErr] = useState(false);
  const [openValidation, setOpenValidation] = useState(false);

  const getUser = (client_id) => {
    // Headers
    setLoading(true);
    api
      .get("/users/get_client_info/" + client_id)
      .then((res) => {
        setClient(res.data);

        setFiles(res.data?.documents ?? []);
        setLoading(false);
      })
      .catch((err) => {
        setCnxErr(true);
        setLoading(false);
      });
  };
  useEffect(() => {
    getUser(id);
  }, []);
  const [error, setError] = useState(null);

  const [openVerify, setOpenVerify] = useState(false);
  const [res, setRes] = useState(null);
  const [resErr, setResErr] = useState("");
  const [loadingVerify, setLoadingVerify] = useState(false);
  const [files, setFiles] = useState();

  const [openDialog, setOpenDialog] = useState(false);
  const [documentToShow, setDocumentToShow] = useState(null);

  const handleOpenDialog = (doc) => {
    setDocumentToShow(doc);
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setDocumentToShow(null);
  };

  const changeStatus = () => {
    api
      .post("/admin/change_status/" + client._id)
      .then((res) => {
        setClient(res.data);
      })
      .catch((err) => {
        if (err.code === "ERR_NETWORK") {
          setError("le serveur ne répond pas");
        } else setError(err.response?.data?.error);
      });
  };

  const dialog = (onClose, submit, document, msg) => (
    <Card sx={{ minWidth: 500, p: 2 }}>
      <CardContent>
        <Typography variant="h6">Êtes-vous sûr(e) ?</Typography>

        <Typography sx={{ m: 2 }} variant="subtitle2" color="error">
          {msg}
        </Typography>
      </CardContent>
      <Stack
        direction="row"
        sx={{ display: "flex", justifyContent: "flex-end" }}
      >
        <Button
          onClick={() => {
            submit(document);
            onClose();
          }}
          variant="outlined"
          size="large"
        >
          Oui
        </Button>
        <Button onClick={onClose} size="large">
          Quitter
        </Button>
      </Stack>
    </Card>
  );

  const showError = (msg) => {
    toast.error(msg, {
      position: "bottom-center",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };
  const showSuccess = (msg) => {
    toast.success(msg, {
      position: "bottom-center",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };
  const verify = () => {
    setOpenVerify(true);
    setLoadingVerify(true);
    api
      .post("/admin/verify_siren/", { id: client._id })
      .then((res) => {
        if (res.data.status == 200) {
          setRes(res.data?.data?.data);
        } else if (res.data.status == 422) {
          setResErr(
            "Ce numéro SIREN n'est pas valide. Le client n'a pas été vérifié"
          );
        }
        setLoadingVerify(false);
      })
      .catch((err) => {
        console.log(err);
        setLoadingVerify(false);
      });
  };
  const validate_doc = (id) => {
    api
      .post("/admin/validate_docs", { id: client._id, doc_id: id })
      .then((res) => {
        setFiles(res.data);
      })
      .catch((err) => {});
  };

  const refuse_doc = (id) => {
    api
      .post("/admin/refuse_docs", { id: client._id, doc_id: id })
      .then((res) => {
        setFiles(res.data);
      })
      .catch((err) => {});
  };
  const handleStatusChange = (event) => {
    let msg = client.active
      ? "Votre action entraînera la suspension du collaborateur"
      : "Votre action activera le compte du collaborateur";

    confirmAlert({
      customUI: ({ onClose }) => dialog(onClose, changeStatus, document, msg),
      closeOnEscape: true,
      closeOnClickOutside: true,
      overlayClassName: "overlay",
    });
  };
  if (loading) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "80vh",
        }}
      >
        <Stack
          spacing={2}
          display={"flex"}
          justifyContent="center"
          direction="column"
          alignItems="center"
        >
          <CircularProgress />
          <Typography>Chargement</Typography>
        </Stack>
      </Box>
    );
  }
  if (cnxErr || !client) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "80vh",
        }}
      >
        <Stack
          spacing={2}
          display={"flex"}
          justifyContent="center"
          direction="column"
          alignItems="center"
        >
          <IconButton onClick={() => getUser(id)}>
            <Refresh />
          </IconButton>
          <Typography>probleme de connexion </Typography>
        </Stack>
      </Box>
    );
  }
  if (client.role !== 2) return <Navigate to={"/dashboard"} />;

  return (
    <>
      <Stack spacing={1} sx={{ m: 1 }}>
        <Paper variant="outlined" sx={{ p: 1 }}>
          <Stack
            direction={"row"}
            justifyContent={"space-between"}
            alignItems={"center"}
          >
            <Box display="flex" alignItems="center" gap={1} mt={2}>
              <Typography variant="subtitle1" fontWeight="bold">
                Dossier du collaborateur :
              </Typography>
              <Box display="flex" alignItems="center" gap={0.5}>
                {client.unverified_steps.includes(-1) ? (
                  <>
                    <Typography
                      sx={{
                        color: "red",
                        display: "flex",
                        alignItems: "center",
                      }}
                      variant="body1"
                    >
                      <ErrorOutline sx={{ fontSize: 20, marginRight: 0.5 }} />{" "}
                      Invalide
                    </Typography>
                  </>
                ) : (
                  <>
                    <Typography
                      sx={{
                        color: "green",
                        display: "flex",
                        alignItems: "center",
                      }}
                      variant="body1"
                    >
                      <CheckCircleOutline
                        sx={{ fontSize: 20, marginRight: 0.5 }}
                      />{" "}
                      Valide
                    </Typography>
                  </>
                )}
              </Box>
            </Box>

            {true ? (
              <Button
                onClick={() => setOpenValidation(true)}
                variant="contained"
              >
                Validation
              </Button>
            ) : (
              <>Inscription incomplète</>
            )}
          </Stack>
        </Paper>
        <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, boxShadow: 1 }}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Stack spacing={3}>
                {/* Nom et Prénom */}
                <Stack direction="row" alignItems="center" spacing={2}>
                  <Typography variant="subtitle2" sx={{ fontWeight: "bold" }}>
                    Nom et Prénom:
                  </Typography>
                  <Typography variant="body2" sx={{ fontWeight: 500 }}>
                    {client.name.toUpperCase()} {client.fname}
                  </Typography>
                </Stack>

                {/* Téléphone */}
                <Stack direction="row" alignItems="center" spacing={2}>
                  <Phone sx={{ color: "primary.main" }} />
                  <Typography variant="body2">{client.phone}</Typography>
                </Stack>

                {/* Email */}
                <Stack direction="row" alignItems="center" spacing={2}>
                  <Email sx={{ color: "primary.main" }} />
                  <Typography variant="body2">{client.email}</Typography>
                </Stack>

                {/* Adresse */}
                <Stack direction="row" alignItems="center" spacing={2}>
                  <LocationOn sx={{ color: "primary.main" }} />
                  <Typography variant="body2">
                    {client.address}, {client.postal_code + " " + client.city},{" "}
                    {client.state}
                    <br />
                    {client.address2 && `${client.address2}`}{" "}
                    {/* Complément d'adresse intégré ici */}
                  </Typography>
                </Stack>

                {/* Status du compte */}
                <Stack direction="row" alignItems="center" spacing={2}>
                  <Typography variant="subtitle2" sx={{ fontWeight: "bold" }}>
                    Statut du compte :
                  </Typography>
                  <Typography variant="body2">
                    <Switch
                      checked={client.active}
                      onChange={handleStatusChange}
                      inputProps={{ "aria-label": "status-switch" }}
                    />
                  </Typography>
                  <Typography variant="body2" sx={{ fontWeight: 500 }}>
                    {client.active ? "Activé" : "Suspendu"}
                  </Typography>
                </Stack>
              </Stack>
            </Grid>

            {/* Avatar du client */}
            <Grid item xs={12} md={6}>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  height: "100%",
                }}
              >
                <Box
                  sx={{
                    width: 150,
                    height: 150,
                    borderRadius: "50%",
                    overflow: "hidden",
                    boxShadow: 2,
                  }}
                >
                  <Image
                    src={
                      client?.avatar.length > 0
                        ? FILES_URL + client?.avatar
                        : "/statics/image-placeholder.png"
                    }
                    alt="Avatar"
                    width="100%"
                    height="100%"
                    style={{
                      objectFit: "cover", // L'image couvre le conteneur
                      objectPosition: "center", // Centrer l'image dans le conteneur
                    }}
                  />
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Paper>
        {true ? (
          <>
            <Paper variant="outlined" sx={{ p: 1 }}>
              {files
                .sort((a, b) => a.id - b.id)
                .map((doc) => (
                  <div key={doc.id}>
                    <Stack direction={"row"} alignItems="center" spacing={2}>
                      <Box sx={{ m: 1 }}>
                        <img
                          src="/statics/undraw_add_files_re_v09g.svg"
                          alt=""
                          style={{ maxWidth: "50px", maxHeight: "50px" }}
                        />
                      </Box>

                      <Stack sx={{ flex: 1 }}>
                        <Stack direction="row" alignItems="center" spacing={1}>
                          <Typography variant="body2">{doc.name}</Typography>
                          {doc.is_valid === false && doc.status === true ? (
                            <HighlightOff sx={{ color: "orange" }} /> // En attente
                          ) : doc.is_valid === true && doc.status === true ? (
                            <CheckCircle sx={{ color: "green" }} /> // Validé
                          ) : doc.is_valid === false && doc.status === false ? (
                            <HighlightOff sx={{ color: "red" }} /> // Refusé
                          ) : null}
                        </Stack>
                        {doc.file ? (
                          <MuiLink
                            href={URL.createObjectURL(doc.file)}
                            target="_blank"
                            rel="noopener noreferrer"
                            color="inherit"
                          >
                            <Typography
                              sx={{
                                color: "blue",
                                textDecoration: "underline",
                              }}
                              variant="caption"
                            >
                              {doc.file.name}
                            </Typography>
                          </MuiLink>
                        ) : (
                          doc.path.length > 0 && (
                            <MuiLink
                              onClick={() => handleOpenDialog(doc)}
                              sx={{ cursor: "pointer" }}
                              color="inherit"
                            >
                              <Typography
                                sx={{
                                  color: "blue",
                                  textDecoration: "underline",
                                }}
                                variant="caption"
                              >
                                Consulter le document...
                              </Typography>
                            </MuiLink>
                          )
                        )}
                      </Stack>

                      {(doc.is_valid || doc.status) && (
                        <Button
                          variant="outlined"
                          color="error"
                          onClick={() => refuse_doc(doc?.id)}
                        >
                          {!doc.is_valid ? 'Refuser' : 'Annuler'}
                        </Button>
                      )}

                      {doc.is_valid === false && doc.path.length > 0 && (
                        <Button
                          variant="outlined"
                          color="success"
                          onClick={() => validate_doc(doc?.id)}
                        >
                          Valider
                        </Button>
                      )}
                    </Stack>
                    <Divider />
                  </div>
                ))}
            </Paper>

            {/* Dialog pour afficher le document */}
            {documentToShow && (
              <Dialog
                open={openDialog}
                onClose={handleCloseDialog}
                fullWidth
                maxWidth="md"
              >
                <DialogTitle>Document - {documentToShow.name}</DialogTitle>
                <DialogContent>
                  {["jpg", "jpeg", "png"].includes(
                    documentToShow.path.split(".").pop().toLowerCase()
                  ) ? (
                    // Affichage de l'image si le document est un fichier image
                    <img
                      src={FILES_URL + documentToShow.path}
                      alt="Document"
                      style={{
                        width: "100%",
                        maxHeight: "500px",
                        objectFit: "contain",
                      }}
                    />
                  ) : ["pdf"].includes(
                      documentToShow.path.split(".").pop().toLowerCase()
                    ) ? (
                    <Worker
                      workerUrl={`https://unpkg.com/pdfjs-dist@3.4.120/build/pdf.worker.min.js`}
                    >
                      <Viewer fileUrl={FILES_URL + documentToShow.path} />
                    </Worker>
                  ) : (
                    // Si le fichier est sur S3, on affiche l'URL
                    <MuiLink
                      href={FILES_URL + documentToShow.path}
                      target="_blank"
                      rel="noopener noreferrer"
                      color="inherit"
                      sx={{ display: "block", textAlign: "center" }}
                    >
                      <Typography
                        sx={{ color: "blue", textDecoration: "underline" }}
                        variant="caption"
                      >
                        Consulter le document
                      </Typography>
                    </MuiLink>
                  )}
                </DialogContent>
                <DialogActions>
                  <Button
                    variant="outlined"
                    onClick={handleCloseDialog}
                    color="primary"
                  >
                    Fermer
                  </Button>
                </DialogActions>
              </Dialog>
            )}
          </>
        ) : (
          <>
            <Paper variant="outlined" sx={{ p: 1 }}>
              <Typography color={"error"}>
                Cet partenaire n'a pas encore fourni toutes les informations
                nécessaires. Attendez qu'il fournisse toutes les informations
                requises.
              </Typography>
            </Paper>
          </>
        )}
      </Stack>

      <Dialog
        fullWidth
        maxWidth="sm"
        open={openVerify}
        onClose={() => {
          setResErr(null);
          setRes(null);
          setOpenVerify(false);
        }}
      >
        <DialogContent>
          {loadingVerify && (
            <>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  height: 100,
                }}
              >
                <Stack alignItems={"center"}>
                  <CircularProgress />
                  <Typography>Chargement</Typography>
                </Stack>
              </Box>
            </>
          )}
          <Typography sx={{ color: "red" }}>
            {!res && !loadingVerify && "Erreur interne du serveur"}
          </Typography>
          {res && !resErr && <DataDisplay data={res} />}
          {resErr && !res && resErr}
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => {
              setResErr(null);
              setRes(null);
              setOpenVerify(false);
            }}
          >
            annuler
          </Button>
        </DialogActions>
      </Dialog>
      <ValidateDialog
        open={openValidation}
        close={() => setOpenValidation(false)}
        documents={client.documents}
        showSuccess={showSuccess}
        valid_siret={client?.valid_siret}
        valid_client={!client?.unverified_steps.includes(-1)}
        setClient={setClient}
        client_id={client?._id}
      />
    </>
  );
}

const DataDisplay = ({ data }) => {
  return (
    <Stack spacing={2}>
      <Typography variant="subtitle1">SIREN:</Typography>
      <Typography variant="body2">{data?.siren}</Typography>

      <Typography variant="subtitle1">DATE RADIATION:</Typography>
      <Typography variant="body2">{data?.date_radiation}</Typography>

      <Typography variant="subtitle1">DATE EXTRAIT:</Typography>
      <Typography variant="body2">{data?.date_extrait}</Typography>

      <Typography variant="subtitle1">DATE IMMATRICULATION:</Typography>
      <Typography variant="body2">{data?.date_immatriculation}</Typography>

      <Typography variant="subtitle1">NOM COMMERCIAL:</Typography>
      <Typography variant="body2">{data?.nom_commercial}</Typography>

      <Typography variant="subtitle1">ETABLISSEMENT PRINCIPAL:</Typography>
      <Stack spacing={1} paddingLeft={2}>
        <Typography variant="body2">
          Activité: {data?.etablissement_principal?.activite}
        </Typography>
        <Typography variant="body2">
          Origine des fonds: {data?.etablissement_principal?.origine_fonds}
        </Typography>
        <Typography variant="body2">
          Mode d'exploitation:{" "}
          {data?.etablissement_principal?.mode_exploitation}
        </Typography>
        <Typography variant="body2">
          Code APE: {data?.etablissement_principal?.code_ape}
        </Typography>
      </Stack>

      <Typography variant="subtitle1">CAPITAL:</Typography>
      <Stack spacing={1} paddingLeft={2}>
        <Typography variant="body2">
          Montant: {data?.capital?.montant}
        </Typography>
        <Typography variant="body2">Devise: {data?.capital?.devise}</Typography>
        <Typography variant="body2">
          Code Devise: {data?.capital?.code_devise}
        </Typography>
      </Stack>

      <Typography variant="subtitle1">GREFFE:</Typography>
      <Stack spacing={1} paddingLeft={2}>
        <Typography variant="body2">Valeur: {data?.greffe?.valeur}</Typography>
        <Typography variant="body2">Code: {data?.greffe?.code}</Typography>
      </Stack>

      <Typography variant="subtitle1">PERSONNE PHYSIQUE:</Typography>
      <Stack spacing={1} paddingLeft={2}>
        <Typography variant="body2">
          Nom: {data?.personne_physique?.nom}
        </Typography>
        <Typography variant="body2">
          Prénom: {data?.personne_physique?.prenom}
        </Typography>
        <Typography variant="body2">
          Nationalité: {data?.personne_physique?.nationalite?.valeur}
        </Typography>
      </Stack>

      <Typography variant="subtitle1">PERSONNE MORALE:</Typography>
      <Stack spacing={1} paddingLeft={2}>
        <Typography variant="body2">
          Forme juridique: {data?.personne_morale?.forme_juridique.valeur}
        </Typography>
        <Typography variant="body2">
          Dénomination: {data?.personne_morale?.denomination}
        </Typography>
        <Typography variant="body2">
          Date de clôture exercice comptable:{" "}
          {data?.personne_morale?.date_cloture_exercice_comptable}
        </Typography>
        <Typography variant="body2">
          Date de fin de vie: {data?.personne_morale?.date_fin_de_vie}
        </Typography>
      </Stack>
    </Stack>
  );
};
