import { Info, Refresh, Search, StopCircle, WifiOff } from '@mui/icons-material'
import api from 'src/Api'
import {
	Avatar,
	Box,
	Button,
	Card,
	Chip,
	CircularProgress,
	Container,
	FormControl,
	IconButton,
	InputAdornment,
	OutlinedInput,
	Pagination,
	PaginationItem,
	Stack,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	TableSortLabel,
	Typography,
} from '@mui/material'
import { useEffect, useState } from 'react'
import Page from 'src/components/Page'
import useSettings from 'src/hooks/useSettings'
import { useNavigate } from 'react-router'

export default function Clients() {
	const { themeStretch } = useSettings()
	const navigate = useNavigate()
	const [search, setSearch] = useState('')
	const [page, setPage] = useState(0)
	const [rowsPerPage, setRowsPerPage] = useState(10)
	const [loading, setLoading] = useState(false)
	const [clients, setClients] = useState([])
	const [error, setError] = useState(false)
	const [order, setOrder] = useState('asc')
	const [orderBy, setOrderBy] = useState('company_name')

	useEffect(() => {
		getClients()
	}, [])

	const getClients = () => {
		setLoading(true)
		api.get('/admin/get_clients')
			.then(res => {
				setClients(res.data)
				setLoading(false)
				setError(false)
			})
			.catch(err => {
				setLoading(false)
				setError(true)
			})
	}

	const handleSearchChange = (event) => {
		setSearch(event.target.value)
		setPage(0)
	}

	const handleChangePage = (event, newPage) => {
		setPage(newPage - 1)
	}

	const handleRequestSort = (property) => {
		const isAsc = orderBy === property && order === 'asc'
		setOrder(isAsc ? 'desc' : 'asc')
		setOrderBy(property)
	}

	const filteredClients = clients.filter(client =>
		client.company_name.toLowerCase().includes(search.toLowerCase())
	)

	const sortedClients = filteredClients.sort((a, b) => {
		const isAsc = order === 'asc'
		if (a[orderBy] < b[orderBy]) return isAsc ? -1 : 1
		if (a[orderBy] > b[orderBy]) return isAsc ? 1 : -1
		return 0
	})

	const paginatedClients = sortedClients.slice(
		page * rowsPerPage,
		page * rowsPerPage + rowsPerPage
	)

	return (
		<Page title="Gestion des partenaires">
			<Container maxWidth={themeStretch ? false : 'xl'}>
				<Typography variant="h4" component="h4" paragraph>
					Gestion des partenaires
				</Typography>

				<Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
					<FormControl sx={{ mx: 1, width: '400px' }} variant="outlined">
						<OutlinedInput
							size="small"
							placeholder="Rechercher"
							value={search}
							onChange={handleSearchChange}
							endAdornment={
								<InputAdornment position="end">
									<IconButton edge="end">
										<Search />
									</IconButton>
								</InputAdornment>
							}
						/>
					</FormControl>
					<Button sx={{ ml: 2 }} variant="outlined" onClick={getClients} startIcon={<Refresh />}>
						Actualiser
					</Button>
				</Box>

				<Card sx={{ borderRadius: 1, mt: 3 }}>
					<TableContainer>
						<Table size="small">
							<TableHead>
								<TableRow>
									{['company_name', 'phone', 'email', 'status', 'rating'].map((column) => (
										<TableCell
											key={column}
											sortDirection={orderBy === column ? order : false}
										>
											<TableSortLabel
												active={orderBy === column}
												direction={orderBy === column ? order : 'asc'}
												onClick={() => handleRequestSort(column)}
											>
												{column === 'company_name' ? "Nom de l'entreprise" :
												 column === 'phone' ? 'N° Téléphone' :
												 column === 'email' ? 'Email' :
												 column === 'status' ? 'Statut' :
												 'Évaluation'}
											</TableSortLabel>
										</TableCell>
									))}
									<TableCell align="center">Options</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{loading && (
									<TableRow>
										<TableCell colSpan={7} align="center">
											<CircularProgress />
											<Typography variant="body2">Chargement des données...</Typography>
										</TableCell>
									</TableRow>
								)}
								{!loading && error && (
									<TableRow>
										<TableCell colSpan={7} align="center">
											<WifiOff />
											<Typography variant="body2">Vérifiez votre connexion internet.</Typography>
										</TableCell>
									</TableRow>
								)}
								{!loading && paginatedClients.length === 0 && (
									<TableRow>
										<TableCell colSpan={7} align="center">
											<StopCircle />
											<Typography variant="body2">Aucun résultat trouvé.</Typography>
										</TableCell>
									</TableRow>
								)}
								{paginatedClients.map((client) => (
									<TableRow hover key={client._id}>
										<TableCell>{client.company_name}</TableCell>
										<TableCell>{client.phone}</TableCell>
										<TableCell>{client.email}</TableCell>
										<TableCell>
											<Chip
												label={client.unverified_steps.includes(-1) ? 'Non Validé' : 'Validé'}
												color={client.unverified_steps.includes(-1) ? 'error' : 'success'}
											/>
										</TableCell>
										<TableCell align="center">{client.rating}</TableCell>
										<TableCell align="center">
											<IconButton onClick={() => navigate(`/dashboard/clients/${client._id}`)}>
												<Info />
											</IconButton>
										</TableCell>
									</TableRow>
								))}
							</TableBody>
						</Table>
					</TableContainer>

					<Box sx={{ p: 2, display: 'flex', justifyContent: 'center' }}>
						<Pagination
							count={Math.ceil(filteredClients.length / rowsPerPage)}
							page={page + 1}
							onChange={handleChangePage}
							renderItem={(item) => <PaginationItem {...item} />}
						/>
					</Box>
				</Card>
			</Container>
		</Page>
	)
}
