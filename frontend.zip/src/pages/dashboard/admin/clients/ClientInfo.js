import {
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Grid,
  IconButton,
  Paper,
  Stack,
  Switch,
  Typography,
  Alert,
  AlertTitle,
} from "@mui/material";
import api, { FILES_URL } from "src/Api";

import { useEffect, useState } from "react";

import {
  CheckCircle,
  Close,
  HighlightOff,
  Refresh,
  Upload,
  Info,
  Business,
  LocationCity,
  OpenInNew,
  Error,
  Phone,
  Email,
  LocationOn,
} from "@mui/icons-material";

import { confirmAlert } from "react-confirm-alert";

import { APP_URL } from "src/config";
import { Link as MuiLink } from "@mui/material";
import { Navigate, useParams } from "react-router";
import ValidateDialog from "./ValidateDialog";
import { ToastContainer, toast } from "react-toastify";
import Image from "src/components/Image";

export default function ClientInfo({}) {
  const { id } = useParams();
  const [client, setClient] = useState(false);
  const [loading, setLoading] = useState(false);
  const [cnxErr, setCnxErr] = useState(false);
  const [openValidation, setOpenValidation] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [dialogMessage, setDialogMessage] = useState("");
  const getUser = (client_id) => {
    // Headers
    setLoading(true);
    api
      .get("/users/get_client_info/" + client_id)
      .then((res) => {
        setClient(res.data);

        setFiles(res.data?.documents ?? []);
        setLoading(false);
      })
      .catch((err) => {
        setCnxErr(true);
        setLoading(false);
      });
  };
  useEffect(() => {
    getUser(id);
  }, []);
  const [error, setError] = useState(null);

  const [openVerify, setOpenVerify] = useState(false);
  const [res, setRes] = useState(null);
  const [resErr, setResErr] = useState("");
  const [loadingVerify, setLoadingVerify] = useState(false);
  const [files, setFiles] = useState();

  const changeStatus = () => {
    api
      .post("/admin/change_status/" + client._id)
      .then((res) => {
        setClient(res.data);
        if (res.data.active) showSuccess("Le compte a été activé.");
        else showSuccess("Le compte a été désactivé.");
      })
      .catch((err) => {
        if (err.code === "ERR_NETWORK") {
          setError("Une erreur est survenue. Veuillez réessayer plus tard.");
        } else setError(err.response?.data?.error);
      });
  };

  const showError = (msg) => {
    toast.error(msg, {
      position: "bottom-center",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };
  const showSuccess = (msg) => {
    toast.success(msg, {
      position: "bottom-center",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };
  // const verify = () => {
  // 	setOpenVerify(true)
  // 	setLoadingVerify(true)
  // 	api.post('/admin/verify_siren/', { id: client._id })
  // 		.then(res => {
  // 			if (res.data.status == 200) {
  // 				setRes(res.data?.data?.data)
  // 			} else if (res.data.status == 422) {
  // 				setResErr("Ce numéro SIREN n'est pas valide. Le client n'a pas été vérifié")
  // 			}
  // 			setLoadingVerify(false)
  // 		})
  // 		.catch(err => {
  // 			console.log(err)
  // 			setLoadingVerify(false)
  // 		})
  // }

  const verify = () => {
    setOpenVerify(true);
    setLoadingVerify(true);
    api
      .get(`/users/get_company_infos/${client.siret}`)
      .then((res) => {
        if (res.data.header.statut == 200) {
          setRes(res.data);
        }
        setLoadingVerify(false);
      })
      .catch((err) => {
        setResErr("Ce numéro SIRET/SIREN est invalide.");
        setLoadingVerify(false);
      });
  };
  const validate_doc = (id) => {
    api
      .post("/admin/validate_docs", { id: client._id, doc_id: id })
      .then((res) => {
        setFiles(res.data);
      })
      .catch((err) => {});
  };
  //   const handleStatusChange = (event) => {
  //     let msg = client.active
  //       ? "votre action entraînera la suspension du partenaire"
  //       : "votre action activera le compte du  partenaire";

  //     confirmAlert({
  //       customUI: ({ onClose }) => dialog(onClose, changeStatus, document, msg),
  //       closeOnEscape: true,
  //       closeOnClickOutside: true,
  //       overlayClassName: "overlay",
  //     });
  //   };
  const handleStatusChange = () => {
    let msg = client.active
      ? "Votre action entraînera la suspension du partenaire."
      : "Votre action activera le compte du partenaire.";

    // Ouvrir le Dialog
    setOpenDialog(true);
    setDialogMessage(msg); // Définit le message à afficher dans la boîte de dialogue
  };
  if (loading) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "80vh",
        }}
      >
        <Stack
          spacing={2}
          display={"flex"}
          justifyContent="center"
          direction="column"
          alignItems="center"
        >
          <CircularProgress />
          <Typography>Chargement</Typography>
        </Stack>
      </Box>
    );
  }
  if (cnxErr || !client) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "80vh",
        }}
      >
        <Stack
          spacing={2}
          display={"flex"}
          justifyContent="center"
          direction="column"
          alignItems="center"
        >
          <IconButton onClick={() => getUser(id)}>
            <Refresh />
          </IconButton>
          <Typography>probleme de connexion </Typography>
        </Stack>
      </Box>
    );
  }
  if (client.role !== 1) return <Navigate to={"/dashboard"} />;

  return (
    <>
      <ToastContainer />
      <Stack spacing={2} sx={{ m: 2 }}>
        {/* Dossier du partenaire */}
        <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, boxShadow: 1 }}>
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
          >
            <Box>
              <Typography variant="subtitle1" sx={{ fontWeight: "bold" }}>
                Dossier du partenaire :
              </Typography>
              <Typography
                sx={{
                  color: client.unverified_steps.includes(-1)
                    ? "error.main"
                    : "green",
                  fontWeight: 500,
                }}
                component="span"
              >
                {client.unverified_steps.includes(-1) ? "Invalide" : "Valide"}
              </Typography>
            </Box>
            {client.unverified_steps.length <= 1 ? (
              <Button
                onClick={() => setOpenValidation(true)}
                variant="contained"
                sx={{ textTransform: "none" }}
              >
                Validation
              </Button>
            ) : (
              <Typography
                variant="body2"
                sx={{ fontStyle: "italic", color: "text.secondary" }}
              >
                Inscription incomplète
              </Typography>
            )}
          </Stack>
        </Paper>

        {/* Informations du client */}
        <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, boxShadow: 1 }}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Stack spacing={3}>
                {/* Nom et Prénom */}
                <Stack direction="row" alignItems="center" spacing={2}>
                  <Typography variant="subtitle2" sx={{ fontWeight: "bold" }}>
                    Nom et Prénom:
                  </Typography>
                  <Typography variant="body2" sx={{ fontWeight: 500 }}>
                    {client.name.toUpperCase()}
                  </Typography>
                </Stack>

                {/* Téléphone */}
                <Stack direction="row" alignItems="center" spacing={2}>
                  <Phone sx={{ color: "primary.main" }} />
                  <Typography variant="body2">{client.phone}</Typography>
                </Stack>

                {/* Email */}
                <Stack direction="row" alignItems="center" spacing={2}>
                  <Email sx={{ color: "primary.main" }} />
                  <Typography variant="body2">{client.email}</Typography>
                </Stack>

                {/* Adresse */}
                <Stack direction="row" alignItems="center" spacing={2}>
                  <LocationOn sx={{ color: "primary.main" }} />
                  <Typography variant="body2">
                    {client.address}, {client.postal_code + " " + client.city},{" "}
                    {client.state}
                    <br />
                    {client.address2 && `${client.address2}`}{" "}
                    {/* Complément d'adresse intégré ici */}
                  </Typography>
                </Stack>

                {/* Status du compte */}
                <Stack direction="row" alignItems="center" spacing={2}>
                  <Typography variant="subtitle2" sx={{ fontWeight: "bold" }}>
                    Statut du compte :
                  </Typography>
                  <Typography variant="body2">
                    <Switch
                      checked={client.active}
                      onChange={handleStatusChange}
                      inputProps={{ "aria-label": "status-switch" }}
                    />
                  </Typography>
                  <Typography variant="body2" sx={{ fontWeight: 500 }}>
                    {client.active ? "Activé" : "Suspendu"}
                  </Typography>
                </Stack>
              </Stack>
            </Grid>

            {/* Avatar du client */}
            <Grid item xs={12} md={6}>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  height: "100%",
                }}
              >
                <Box
                  sx={{
                    width: 150,
                    height: 150,
                    borderRadius: "50%",
                    overflow: "hidden",
                    boxShadow: 2,
                  }}
                >
                  <Image
                    src={
                      client?.avatar.length > 0
                        ? FILES_URL + client?.avatar
                        : "/statics/image-placeholder.png"
                    }
                    alt="Avatar"
                    width="100%"
                    height="100%"
                    style={{ objectFit: "cover" }}
                  />
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Paper>

        {/* Détails du partenaire */}
		{client.unverified_steps.length <= 1 ? (
  <>
    <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, boxShadow: 1 }}>
      <Stack spacing={3}>
        <Stack
          direction={{ xs: "column", sm: "row" }}  // Colonne sur petits écrans, ligne sur grands écrans
          alignItems="center"
          spacing={2}
        >
          <Typography variant="subtitle2" sx={{ fontWeight: "bold" }}>
            Nom d'établissement :
          </Typography>
          <Typography variant="body2" sx={{ textTransform: "uppercase" }}>
            {client.company_name}
          </Typography>
        </Stack>

        {/* SIRET */}
        <Stack
          direction={{ xs: "column", sm: "row" }}  // Colonne sur petits écrans, ligne sur grands écrans
          alignItems="center"
          spacing={2}
        >
          <Typography variant="subtitle2" sx={{ fontWeight: "bold" }}>
            SIRET/SIREN :
          </Typography>
          <Typography variant="body2" sx={{ fontWeight: "bold" }}>
            {client.siret}
          </Typography>
          <Typography
            sx={{
              color: client.valid_siret ? "green" : "orange",
              display: "inline-flex",
              alignItems: "center",
              gap: 1,
            }}
          >
            {client.valid_siret ? (
              <>
                <CheckCircle sx={{ color: "green" }} /> Valide
              </>
            ) : (
              <>
                <Error sx={{ color: "orange" }} /> N'est pas validé
              </>
            )}
          </Typography>
          {/* Action SIRET */}
          <Button
            variant="outlined"
            color="primary"
            onClick={() => verify()}
            sx={{
              textTransform: "none",
              borderRadius: 2,
              fontWeight: "bold",
              mt: { xs: 1, sm: 0 },  // Marge sur petits écrans
            }}
          >
            {client.valid_siret ? "Voir les détails" : "Vérifier"}
          </Button>
        </Stack>

        {/* IBAN */}
        <Stack
          direction={{ xs: "column", sm: "row" }}  // Colonne sur petits écrans, ligne sur grands écrans
          alignItems="center"
          spacing={2}
        >
          <Typography variant="subtitle2" sx={{ fontWeight: "bold" }}>
            IBAN :
          </Typography>
          <Typography variant="body2">{client.iban}</Typography>
        </Stack>
      </Stack>
    </Paper>

    {/* Documents */}
  </>
) : (
  <Alert severity="info" sx={{ mt: 2 }}>
    Cette entreprise est en attente de complétion d'inscription.
  </Alert>
)}

      </Stack>

      <Dialog
        fullWidth
        maxWidth="sm"
        open={openVerify}
        onClose={() => {
          setResErr(null);
          setRes(null);
          setOpenVerify(false);
        }}
      >
        <DialogContent>
          {loadingVerify && (
            <>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  height: 100,
                }}
              >
                <Stack alignItems={"center"}>
                  <CircularProgress />
                  <Typography>Chargement</Typography>
                </Stack>
              </Box>
            </>
          )}
          {resErr && (
            <Alert severity="error">
              <AlertTitle>Erreur de vérification</AlertTitle>
              Le SIRET fourni est invalide ou n'existe pas dans la base de
              données.
            </Alert>
          )}
          {res && !resErr && <DataDisplay data={res} />}
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => {
              setResErr(null);
              setRes(null);
              setOpenVerify(false);
            }}
          >
            Annuler
          </Button>
          {res && !client.valid_siret && (
            <Button
              onClick={async () => {
                try {
                  const res = await api.post(
                    `/admin/validate_siret/${client._id}`
                  );
                  setOpenVerify(false);
                  setClient(res.data);
                  if (res.status == 200) showSuccess("Le SIRET a été validé."); // Montre le message de succès -- ne s'affiche pas --
                } catch (err) {
                  showError("Une erreur s'est produite"); // Assurez-vous d'avoir une fonction pour afficher les erreurs
                }
              }}
            >
              Valider
            </Button>
          )}
        </DialogActions>
      </Dialog>
      <ValidateDialog
        open={openValidation}
        close={() => setOpenValidation(false)}
        documents={client.documents}
        showSuccess={showSuccess}
        valid_siret={client?.valid_siret}
        valid_client={!client?.unverified_steps.includes(-1)}
        setClient={setClient}
        client_id={client?._id}
      />

      <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
        <DialogTitle>Êtes-vous sûr(e) ?</DialogTitle>
        <DialogContent>
          <Typography sx={{ m: 2 }} variant="subtitle2" color="error">
            {dialogMessage}
          </Typography>
        </DialogContent>
        <DialogActions sx={{ justifyContent: "flex-end" }}>
          <Button
            onClick={async () => {
              setLoading(true);
              changeStatus(); // Effectuer le changement de statut
              setOpenDialog(false);
              setLoading(false);
            }}
            color="primary"
            variant="outlined"
            size="large"
            disabled={loading}
          >
            {loading ? <CircularProgress size={24} /> : "Oui"}
          </Button>
          <Button onClick={() => setOpenDialog(false)} size="large">
            Quitter
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}

const DataDisplay = ({ data }) => {
  return (
    <Stack spacing={3} padding={2}>
      {/* Informations Générales */}
      <Card variant="outlined">
        <CardContent>
          <Box display="flex" alignItems="center" gap={1} mb={2}>
            <Info color="primary" />
            <Typography variant="h6" fontWeight="bold" color="primary">
              Informations Générales
            </Typography>
          </Box>
          <Divider />
          <Box mt={2}>
            <Typography variant="body2" mb={1}>
              <strong>Nom commercial:</strong>{" "}
              {data?.etablissement.uniteLegale.denominationUniteLegale}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>SIREN:</strong> {data?.etablissement.siren}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>NIC:</strong> {data?.etablissement.nic}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>SIRET:</strong> {data?.etablissement.siret}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>Date de Création:</strong>{" "}
              {new Date(
                data?.etablissement.uniteLegale.dateCreationUniteLegale
              ).toLocaleDateString("fr-FR")}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>Statut Diffusion:</strong>{" "}
              {data?.etablissement.statutDiffusionEtablissement === "O"
                ? "Visible"
                : "Non Visible"}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>Dernier Traitement:</strong>{" "}
              {new Date(
                data?.etablissement.dateDernierTraitementEtablissement
              ).toLocaleDateString("fr-FR")}
            </Typography>
          </Box>
        </CardContent>
      </Card>

      {/* Adresse de l'Établissement */}
      <Card variant="outlined">
        <CardContent>
          <Box display="flex" alignItems="center" gap={1} mb={2}>
            <LocationCity color="primary" />
            <Typography variant="h6" fontWeight="bold" color="primary">
              Adresse de l'Établissement
            </Typography>
          </Box>
          <Divider />
          <Box mt={2}>
            {console.log(data)}
            <Typography variant="body2" mb={1}>
              <strong>Adresse:</strong>{" "}
              {data?.etablissement.adresseEtablissement.numeroVoieEtablissement}{" "}
              {data?.etablissement.adresseEtablissement.typeVoieEtablissement}{" "}
              {
                data?.etablissement.adresseEtablissement
                  .libelleVoieEtablissement
              }
              ,{" "}
              {
                data?.etablissement.adresseEtablissement
                  .complementAdresseEtablissement
              }
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>Code Postal:</strong>{" "}
              {data?.etablissement.adresseEtablissement.codePostalEtablissement}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>Ville:</strong>{" "}
              {
                data?.etablissement.adresseEtablissement
                  .libelleCommuneEtablissement
              }
            </Typography>
          </Box>
        </CardContent>
      </Card>

      {/* Activité Principale */}
      <Card variant="outlined">
        <CardContent>
          <Box display="flex" alignItems="center" gap={1} mb={2}>
            <Info color="primary" />
            <Typography variant="h6" fontWeight="bold" color="primary">
              Activité Principale
            </Typography>
          </Box>
          <Divider />
          <Box mt={2}>
            <Typography variant="body2" mb={1}>
              <strong>Activité:</strong>{" "}
              {data?.etablissement.uniteLegale.nafIntitule}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>Code NAF:</strong>{" "}
              {data?.etablissement.uniteLegale.activitePrincipaleUniteLegale}
            </Typography>
          </Box>
        </CardContent>
      </Card>

      {/* Détails de l'Unité Légale */}
      <Card variant="outlined">
        <CardContent>
          <Box display="flex" alignItems="center" gap={1} mb={2}>
            <Info color="primary" />
            <Typography variant="h6" fontWeight="bold" color="primary">
              Détails de l'Unité Légale
            </Typography>
          </Box>
          <Divider />
          <Box mt={2}>
            <Typography variant="body2" mb={1}>
              <strong>Catégorie d'entreprise:</strong>{" "}
              {data?.etablissement.uniteLegale.categorieEntreprise}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>Catégorie Juridique:</strong>{" "}
              {data?.etablissement.uniteLegale.categorieJuridiqueUniteLegale}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>Date de Création:</strong>{" "}
              {data?.etablissement.uniteLegale.dateCreationUniteLegale}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>Statut Diffusion:</strong>{" "}
              {data?.etablissement.uniteLegale.statutDiffusionUniteLegale ===
              "O"
                ? "Visible"
                : "Non Visible"}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>Caractère Employeur:</strong>{" "}
              {data?.etablissement.uniteLegale.caractereEmployeurUniteLegale ===
              "N"
                ? "Non Employeur"
                : "Employeur"}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>Tranche Effectifs:</strong>{" "}
              {data?.etablissement.uniteLegale.trancheEffectifsUniteLegale
                ? data?.etablissement.uniteLegale.trancheEffectifsUniteLegale
                : "Non spécifié"}
            </Typography>
            <Typography variant="body2" mb={1}>
              <strong>Dernier Traitement:</strong>{" "}
              {new Date(
                data?.etablissement.uniteLegale.dateDernierTraitementUniteLegale
              ).toLocaleDateString()}
            </Typography>
          </Box>
        </CardContent>
      </Card>

      {/* Bouton Lien vers l'annuaire des entreprises */}
      <Box mt={2} display="flex" justifyContent="center">
        <Button
          variant="contained"
          color="primary"
          href={`https://annuaire-entreprises.data.gouv.fr/entreprise/${data?.etablissement.siren}?redirected=1`}
          target="_blank"
          rel="noopener noreferrer"
          endIcon={<OpenInNew />}
        >
          Voir sur Annuaire des Entreprises
        </Button>
      </Box>
    </Stack>
  );
};
