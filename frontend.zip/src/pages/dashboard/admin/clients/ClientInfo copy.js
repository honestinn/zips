import {
	Box,
	Button,
	Card,
	CardContent,
	CircularProgress,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	Divider,
	Grid,
	IconButton,
	Paper,
	Stack,
	Switch,
	Typography,
} from '@mui/material'
import api, { FILES_URL } from 'src/Api'

import { useEffect, useState } from 'react'

import { CheckCircle, Close, HighlightOff, Refresh, Upload } from '@mui/icons-material'

import { confirmAlert } from 'react-confirm-alert'

import { APP_URL } from 'src/config'
import { Link as MuiLink } from '@mui/material'
import { Navigate, useParams } from 'react-router'
import ValidateDialog from './ValidateDialog'
import { ToastContainer, toast } from 'react-toastify'
import Image from 'src/components/Image'

export default function ClientInfo({}) {
	const { id } = useParams()
	const [client, setClient] = useState(false)
	const [loading, setLoading] = useState(false)
	const [cnxErr, setCnxErr] = useState(false)
	const [openValidation, setOpenValidation] = useState(false)
	const getUser = client_id => {
		// Headers
		setLoading(true)
		api.get('/users/get_client_info/' + client_id)
			.then(res => {
				setClient(res.data)

				setFiles(res.data?.documents ?? [])
				setLoading(false)
			})
			.catch(err => {
				setCnxErr(true)
				setLoading(false)
			})
	}
	useEffect(() => {
		getUser(id)
	}, [])
	const [error, setError] = useState(null)

	const [openVerify, setOpenVerify] = useState(false)
	const [res, setRes] = useState(null)
	const [resErr, setResErr] = useState('')
	const [loadingVerify, setLoadingVerify] = useState(false)
	const [files, setFiles] = useState()

	const changeStatus = () => {
		api.post('/admin/change_status/' + client._id)
			.then(res => {
				setClient(res.data)
			})
			.catch(err => {
				if (err.code === 'ERR_NETWORK') {
					setError('le serveur ne répond pas')
				} else setError(err.response?.data?.error)
			})
	}

	const dialog = (onClose, submit, document, msg) => (
		<Card sx={{ minWidth: 500, p: 2 }}>
			<CardContent>
				<Typography variant="h6">Êtes-vous sûr(e) ?</Typography>

				<Typography sx={{ m: 2 }} variant="subtitle2" color="error">
					{msg}
				</Typography>
			</CardContent>
			<Stack direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }}>
				<Button
					onClick={() => {
						submit(document)
						onClose()
					}}
					variant="outlined"
					size="large"
				>
					Oui
				</Button>
				<Button onClick={onClose} size="large">
					Quitter
				</Button>
			</Stack>
		</Card>
	)

	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	// const verify = () => {
	// 	setOpenVerify(true)
	// 	setLoadingVerify(true)
	// 	api.post('/admin/verify_siren/', { id: client._id })
	// 		.then(res => {
	// 			if (res.data.status == 200) {
	// 				setRes(res.data?.data?.data)
	// 			} else if (res.data.status == 422) {
	// 				setResErr("Ce numéro SIREN n'est pas valide. Le client n'a pas été vérifié")
	// 			}
	// 			setLoadingVerify(false)
	// 		})
	// 		.catch(err => {
	// 			console.log(err)
	// 			setLoadingVerify(false)
	// 		})
	// }

	const verify = () => {
		setOpenVerify(true)
		setLoadingVerify(true)
		api.get(`/users/get_company_infos/${client.siret}`)
		.then(res => 
		{
			if(res.data.header.statut == 200){
				setRes(res.data)
			}
			else{
				setResErr("Ce numéro SIRET/SIREN est invalide.")
			}
			setLoadingVerify(false)
		}
		)
		.catch(err => {
			console.log(err)
	 		setLoadingVerify(false)
	 	})

	}
	const validate_doc = id => {
		api.post('/admin/validate_docs', { id: client._id, doc_id: id })
			.then(res => {
				setFiles(res.data)
			})
			.catch(err => {})
	}
	const handleStatusChange = event => {
		let msg = client.active
			? 'votre action entraînera la suspension du partenaire'
			: 'votre action activera le compte du  partenaire'

		confirmAlert({
			customUI: ({ onClose }) => dialog(onClose, changeStatus, document, msg),
			closeOnEscape: true,
			closeOnClickOutside: true,
			overlayClassName: 'overlay',
		})
	}
	if (loading) {
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '80vh',
				}}
			>
				<Stack
					spacing={2}
					display={'flex'}
					justifyContent="center"
					direction="column"
					alignItems="center"
				>
					<CircularProgress />
					<Typography>Chargement</Typography>
				</Stack>
			</Box>
		)
	}
	if (cnxErr || !client) {
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '80vh',
				}}
			>
				<Stack
					spacing={2}
					display={'flex'}
					justifyContent="center"
					direction="column"
					alignItems="center"
				>
					<IconButton onClick={() => getUser(id)}>
						<Refresh />
					</IconButton>
					<Typography>probleme de connexion </Typography>
				</Stack>
			</Box>
		)
	}
	console.log(res)
	if (client.role !== 1) return <Navigate to={'/dashboard'} />

	return (
		<>
			<Stack spacing={1} sx={{ m: 1 }}>
				<Paper variant="outlined" sx={{ p: 1 }}>
					<Stack direction={'row'} justifyContent={'space-between'} alignItems={'center'}>
						<Box>
							<Typography variant="subtitle1">Dossier du partenaire :</Typography>
							<Typography
								sx={{
									color: client.unverified_steps.includes(-1) ? 'red' : 'green',
								}}
								component={'span'}
							>
								{client.unverified_steps.includes(-1) ? 'Invalide' : 'Valide'}
							</Typography>
						</Box>
						{client.unverified_steps.length <= 1 ? (
							<Button onClick={() => setOpenValidation(true)} variant="contained">
								Validation
							</Button>
						) : (
							<>Inscription incomplète</>
						)}
					</Stack>
				</Paper>
				<Paper variant="outlined" sx={{ p: 1 }}>
					<Grid container spacing={1}>
						<Grid item xs={12} sm={12} md={6} lg={6}>
							<Stack spacing={1}>
								<Stack alignItems={'center'} direction="row" spacing={2}>
									<Typography variant="subtitle1"> Nom et prenom :</Typography>
									<Typography variant="body2">
										{client.name.toUpperCase()}
									</Typography>
								</Stack>
								<Stack alignItems={'center'} direction="row" spacing={2}>
									<Typography variant="subtitle1"> Téléphone:</Typography>
									<Typography variant="body2"> {client.phone}</Typography>
								</Stack>
								<Stack alignItems={'center'} direction="row" spacing={2}>
									<Typography variant="subtitle1"> Email:</Typography>
									<Typography variant="body2"> {client.email}</Typography>
								</Stack>

								<Stack alignItems={'center'} direction="row" spacing={2}>
									<Typography variant="subtitle1"> Adresse:</Typography>
									<Typography variant="body2"> {client.address}</Typography>
								</Stack>
								<Stack alignItems={'center'} direction="row" spacing={2}>
									<Typography variant="subtitle1">
										Complément d'adresse :
									</Typography>
									<Typography variant="body2"> {client.address2}</Typography>
								</Stack>
								<Stack alignItems={'center'} direction="row" spacing={2}>
									<Typography variant="subtitle1">
										Status du compte (suspondu ou activé) :
									</Typography>
									<Typography variant="body2">
										<Switch
											checked={client.active}
											onChange={handleStatusChange}
											inputProps={{ 'aria-label': 'controlled' }}
										/>
									</Typography>
								</Stack>
							</Stack>
						</Grid>

						<Grid item xs={12} sm={12} md={6} lg={6}>
							<Box
								sx={{
									display: 'flex',
									justifyContent: 'center',
									alignItems: 'center',
									height: '100%',
									width: '100%',
								}}
							>
								<Box
									sx={{
										display: 'flex',
										justifyContent: 'center',
										alignItems: 'center',
										height: '100%',
										width: '100%',
									}}
								>
									<Box
										sx={{
											display: 'flex',
											justifyContent: 'center',
											alignItems: 'center',

											width: 150,
											height: 150,
											p: 1,
										}}
									>
										<Image
											src={
												client?.avatar.length > 0
													? FILES_URL + client?.avatar
													: '/statics/image-placeholder.png'
											}
										/>
									</Box>
								</Box>
							</Box>
						</Grid>
					</Grid>
				</Paper>
				{client.unverified_steps.length <= 1 ? (
					<>
						<Paper variant="outlined" sx={{ p: 1 }}>
							<Stack spacing={1}>
								<Stack alignItems={'center'} direction="row" spacing={2}>
									<Typography variant="subtitle1">Nom d'établisment :</Typography>
									<Typography variant="body2">
										{client.company_name.toUpperCase()}
									</Typography>
								</Stack>

								<Stack alignItems={'center'} direction="row" spacing={2}>
									<Typography variant="subtitle1"> SIRET :</Typography>
									<Typography variant="body2">
										{client.siret}
										&nbsp; &nbsp;&nbsp;
										<Typography
											sx={{ color: 'green', display: 'inline-block' }}
										>
											{!client.valid_siret ? "n'est pas validé." : 'Valide'}
										</Typography>
									</Typography>
									<Typography variant="body2">
										<Button
											color="primary"
											onClick={() => {
												verify()
												
											}}
										>
											{!client.valid_siret ? "Vérifier" : 'Voir les détails'}
										</Button>
									</Typography>
								</Stack>
								<Stack alignItems={'center'} direction="row" spacing={2}>
									<Typography variant="subtitle1"> IBAN :</Typography>
									<Typography variant="body2">{client.iban}</Typography>
								</Stack>
							</Stack>
						</Paper>
						<Paper variant="outlined" sx={{ p: 1 }}>
							{files
								.sort((a, b) => a.id - b.id)
								.map(doc => (
									<>
										{doc.status == true && (
											<>
												<Stack
													direction={'row'}
													alignItems="center"
													spacing={2}
												>
													<Box sx={{ m: 1 }}>
														<img
															src="/statics/undraw_add_files_re_v09g.svg"
															alt=""
															style={{
																maxWidth: '50px',
																maxHeight: '50px',
															}}
														/>
													</Box>

													<Stack sx={{ flex: 1 }}>
														<Typography variant="body2">
															{doc.name}
														</Typography>
														{doc.file ? (
															<MuiLink
																href={URL.createObjectURL(doc.file)}
																target="_blank"
																rel="noopener noreferrer"
																color="inherit"
															>
																<Typography
																	sx={{
																		color: 'blue',
																		textDecoration: 'underline',
																	}}
																	variant="caption"
																>
																	{doc.file && doc.file.name}
																</Typography>
															</MuiLink>
														) : (
															doc.path.length > 0 && (
																<MuiLink
																	href={FILES_URL + doc.path}
																	target="_blank"
																	rel="noopener noreferrer"
																	color="inherit"
																>
																	<Typography
																		sx={{
																			color: 'blue',
																			textDecoration:
																				'underline',
																		}}
																		variant="caption"
																	>
																		consulter le document ..
																	</Typography>
																</MuiLink>
															)
														)}
													</Stack>
													{doc.is_valid == true && (
														<Button
															variant="outlined"
															color="error"
															startIcon={<HighlightOff />}
															onClick={() => validate_doc(doc?.id)}
														>
															invalider
														</Button>
													)}
													{doc.is_valid == false && doc.path.length > 0 && (
														<Button
															variant="outlined"
															color="success"
															startIcon={<CheckCircle />}
															onClick={() => validate_doc(doc?.id)}
														>
															valider
														</Button>
													)}
												</Stack>
												<Divider />
											</>
										)}
									</>
								))}
						</Paper>
					</>
				) : (
					<>
						<Paper variant="outlined" sx={{ p: 1 }}>
							<Typography color={'error'}>
								Cet partenaire n'a pas encore fourni toutes les informations
								nécessaires. Attendez qu'il fournisse toutes les informations
								requises.
							</Typography>
						</Paper>
					</>
				)}
			</Stack>

			<Dialog
				fullWidth
				maxWidth="sm"
				open={openVerify}
				onClose={() => {
					setResErr(null)
					setRes(null)
					setOpenVerify(false)
				}}
			>
				<DialogContent>
					{loadingVerify && (
						<>
							<Box
								sx={{
									display: 'flex',
									justifyContent: 'center',
									alignItems: 'center',
									height: 100,
								}}
							>
								<Stack alignItems={'center'}>
									<CircularProgress />
									<Typography>Chargement</Typography>
								</Stack>
							</Box>
						</>
					)}
					<Typography sx={{ color: 'red' }}>
						{!res && !loadingVerify && 'Erreur interne du serveur'}
					</Typography>
					{res && !resErr && <DataDisplay data={res} />}
					{resErr && !res && resErr}
				</DialogContent>
				<DialogActions>
					<Button
						onClick={() => {
							setResErr(null)
							setRes(null)
							setOpenVerify(false)
						}}
					>
						Annuler
					</Button>
					{!client.valid_siret && (
					<Button
					onClick={async () => {
						try {
						const res = await api.post(`/admin/validate_siret/${client._id}`);
						setOpenVerify(false);
						setClient(res.data);
						if(res.status == 200)
							showSuccess("Le SIRET a été validé."); // Montre le message de succès -- ne s'affiche pas --
						} catch (err) {
						showError("Une erreur s'est produite"); // Assurez-vous d'avoir une fonction pour afficher les erreurs
						}
					}}
					>
					Valider
					</Button>
					)}

				</DialogActions>
			</Dialog>
			<ValidateDialog
				open={openValidation}
				close={() => setOpenValidation(false)}
				documents={client.documents}
				showSuccess={showSuccess}
				valid_siret={client?.valid_siret}
				valid_client={!client?.unverified_steps.includes(-1)}
				setClient={setClient}
				client_id={client?._id}
			/>
		</>
	)
}

const DataDisplay = ({ data }) => {
	return (
		<Stack spacing={2}>
			<Box display="flex" alignItems="center" gap={1}>
			<Typography variant="subtitle1">SIREN:</Typography>
			<Typography variant="body2">{data?.etablissement.siren}</Typography>
			</Box>


			<Typography variant="subtitle1">DATE RADIATION:</Typography>
			<Typography variant="body2">{data?.date_radiation}</Typography>

			<Typography variant="subtitle1">DATE EXTRAIT:</Typography>
			<Typography variant="body2">{data?.date_extrait}</Typography>

			<Typography variant="subtitle1">DATE IMMATRICULATION:</Typography>
			<Typography variant="body2">{data?.date_immatriculation}</Typography>

			<Typography variant="subtitle1">NOM COMMERCIAL:</Typography>
			<Typography variant="body2">{data?.nom_commercial}</Typography>

			<Typography variant="subtitle1">ETABLISSEMENT PRINCIPAL:</Typography>
			<Stack spacing={1} paddingLeft={2}>
				<Typography variant="body2">
					Activité: {data?.etablissement_principal?.activite}
				</Typography>
				<Typography variant="body2">
					Origine des fonds: {data?.etablissement_principal?.origine_fonds}
				</Typography>
				<Typography variant="body2">
					Mode d'exploitation: {data?.etablissement_principal?.mode_exploitation}
				</Typography>
				<Typography variant="body2">
					Code APE: {data?.etablissement_principal?.code_ape}
				</Typography>
				{/* Add other fields here if needed */}
			</Stack>

			<Typography variant="subtitle1">CAPITAL:</Typography>
			<Stack spacing={1} paddingLeft={2}>
				<Typography variant="body2">Montant: {data?.capital?.montant}</Typography>
				<Typography variant="body2">Devise: {data?.capital?.devise}</Typography>
				<Typography variant="body2">Code Devise: {data?.capital?.code_devise}</Typography>
				{/* Add other fields here if needed */}
			</Stack>

			<Typography variant="subtitle1">GREFFE:</Typography>
			<Stack spacing={1} paddingLeft={2}>
				<Typography variant="body2">Valeur: {data?.greffe?.valeur}</Typography>
				<Typography variant="body2">Code: {data?.greffe?.code}</Typography>
			</Stack>

			<Typography variant="subtitle1">PERSONNE PHYSIQUE:</Typography>
			<Stack spacing={1} paddingLeft={2}>
				<Typography variant="body2">Nom: {data?.personne_physique?.nom}</Typography>
				<Typography variant="body2">Prénom: {data?.personne_physique?.prenom}</Typography>
				<Typography variant="body2">
					Nationalité: {data?.personne_physique?.nationalite?.valeur}
				</Typography>
			</Stack>

			<Typography variant="subtitle1">PERSONNE MORALE:</Typography>
			<Stack spacing={1} paddingLeft={2}>
				<Typography variant="body2">
					Forme juridique: {data?.personne_morale?.forme_juridique.valeur}
				</Typography>
				<Typography variant="body2">
					Dénomination: {data?.personne_morale?.denomination}
				</Typography>
				<Typography variant="body2">
					Date de clôture exercice comptable:{' '}
					{data?.personne_morale?.date_cloture_exercice_comptable}
				</Typography>
				<Typography variant="body2">
					Date de fin de vie: {data?.personne_morale?.date_fin_de_vie}
				</Typography>
			</Stack>
			<ToastContainer
					position="top-center"
					autoClose={3000}
					hideProgressBar={false}
					newestOnTop={false}
					closeOnClick
					rtl={false}
					pauseOnFocusLoss
					draggable
					pauseOnHover
				/>
		</Stack>
		
	)
}
