import {
	Alert,
	Button,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	Stack,
	Typography,
} from '@mui/material'
import api from 'src/Api'

import { useEffect, useState } from 'react'

export default function ValidateDialog({
	open,
	close,
	
	documents,
	valid_siret,
	valid_client,
	setClient,

	client_id,
}) {
	const [error, setError] = useState(null)

	useEffect(() => {}, [])

	const validate = () => {
		api.post('/admin/validate_client/' + client_id)
			.then(res => {
				if (res.data.code == 'MAVC200') {
					// showSuccess("L'opération a été réussie")
					setClient(res.data.client)
					close()
				}
				if (res.data.code == 'EAVC401') {
					// showError(
					// 	"Vous ne pouvez pas valider , car l'inscription du partenaire est incomplète."
					// )
				}
			})
			.catch(err => {
				// showError('Quelque chose ne va pas.')
			})
	}

	return (
		<Dialog fullWidth maxWidth="sm" open={open} onClose={close}>
			<DialogTitle>Validation</DialogTitle>
			<DialogContent>
				{!valid_client ? (
					<>
						<Typography color={'error'}>
							Êtes-vous sûr de valider ce partenaire?
						</Typography>
						<Stack spacing={1}>
							<Stack direction={'row'} spacing={2}>
								<Typography variant="subtitle2">Siret :</Typography>
								<Typography
									color={valid_siret ? 'success' : 'error'}
									variant="body2"
								>
									{valid_siret ? 'valide' : 'invalide'}
								</Typography>
							</Stack>
							{documents
								.filter(e => !e.is_valid)
								.sort((a, b) => a.id - b.id)
								.map(doc => (
									<Stack direction={'row'} spacing={2}>
										<Typography variant="subtitle2">{doc.name}:</Typography>
										<Typography color={'error'} variant="body2">
											{'invalide'}
										</Typography>
									</Stack>
								))}
						</Stack>
					</>
				) : (
					<Typography color={'error'}>
						Êtes-vous sûr de vouloir invalider ce partenaire?
					</Typography>
				)}
			</DialogContent>

			<DialogActions>
				<Button
					onClick={validate}
					sx={{ textTransform: 'none' }}
					color="error"
					type="submit"
				>
					Confirmer
				</Button>
				<Button onClick={close}>annuler</Button>
			</DialogActions>
		</Dialog>
	)
}
