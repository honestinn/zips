import {
	Alert,
	Autocomplete,
	Avatar,
	Box,
	Button,
	Card,
	CardActions,
	CardContent,
	Checkbox,
	Chip,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	Divider,
	FormControl,
	FormControlLabel,
	FormLabel,
	Grid,
	Radio,
	RadioGroup,
	Rating,
	Stack,
	Switch,
	TextField,
	Typography,
} from '@mui/material'
import api, { FILES_URL } from 'src/Api'
import { useFormik } from 'formik'
import { useEffect, useState } from 'react'

import * as Yup from 'yup'
import { Check, Close, ThumbUp, Upload } from '@mui/icons-material'
import { LoadingButton } from '@mui/lab'
import { confirmAlert } from 'react-confirm-alert'

import './style.css' // Import css
import MissionDetails from './MissionDetails'
import { StarIcon } from 'src/theme/overrides/CustomIcons'
import moment from 'moment'
import Image from 'src/components/Image'
const labels = {
	0.5: '',
	1: '',
	1.5: '',
	2: '',
	2.5: '',
	3: '',
	3.5: '',
	4: '',
	4.5: '',
	5: '',
}
function getLabelText(value) {
	return `${value} Star${value !== 1 ? 's' : ''}, ${labels[value]}`
}

function isMoreThan12HoursAhead(date) {
	const twelveHoursInMilliseconds = 12 * 60 * 60 * 1000 // 12 hours in milliseconds
	const currentDate = new Date()

	return new Date(date) - currentDate > twelveHoursInMilliseconds
}

export default function Show({
	open,
	close,
	replace,
	row,
	langs,
	levels,
	competences,
	diplomes,
	softwares,
	showError,
	showSuccess,
}) {
	const [openRating, setOpenRating] = useState(false)
	const [value, setValue] = useState(2)
	const [hover, setHover] = useState(-1)
	const [recommended, setRecommended] = useState(false)
	const [comment, setComment] = useState('')
	const handleClickOpen = () => {
		setOpenRating(true)
	}

	const handleClose = () => {
		setOpenRating(false)
	}

	useEffect(() => {
		getMotifs()
	}, [open])

	const [motif, setMotif] = useState('')
	const [motifs, setMotifs] = useState([])
	const [validMotif, setValidMotif] = useState(true)
	const [otherMotif, setOtherMotif] = useState('')
	const [openConfirmation, setOpenConfirmation] = useState(false)
	const [confirmationType, setConfirmationType] = useState('')
	console.log(row)
	const dialog = (onClose, submit, id, msg) => (
		<Card sx={{ minWidth: 500, p: 2 }}>
			<CardContent>
				<Typography variant="h6">Êtes-vous sûr(e) ?</Typography>

				<Typography sx={{ m: 2 }} variant="subtitle2" color="error">
					{msg}
				</Typography>
			</CardContent>
			<Stack direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }}>
				<Button
					onClick={() => {
						submit(id)
						onClose()
					}}
					variant="outlined"
					size="large"
				>
					Oui
				</Button>
				<Button onClick={onClose} size="large">
					Quitter
				</Button>
			</Stack>
		</Card>
	)
	const sendCancel = id => {
		let reason = motif == 'm0' ? otherMotif : motifs[motif]

		api.post('/missions/cancel_application/' + row?.user?._id, {
			applicationId: id,
			motif: reason,
		})
			.then(res => {
				showSuccess('Mission annulée avec succès')
				setOpenConfirmation(false)
				close()
				replace(res.data)
			})
			.catch(err => {
				showError('erreur')
			})
	}

	const getMotifs = () => {
		api.get('/users/get_admin_motifs_list')
			.then(res => {
				setMotifs(res.data)
			})
			.catch(err => {})
	}

	const evaluate = id => {
		api.post('/missions/evaluate/' + row?.user?._id, {
			id,
			comment,
			rating: value,
			recommended,
		})
			.then(res => {
				showSuccess('Votre évaluation a bien été enregistrée.')
				handleClose()
				replace(res.data)
			})
			.catch(err => {
				showError('erreur')
			})
	}
	// const finish = id => {
	// 	let msg = 'Votre action terminera la candidature et informera le collaborateur.'

	// 	confirmAlert({
	// 		customUI: ({ onClose }) => dialog(onClose, sendFinish, id, msg),
	// 		closeOnEscape: true,
	// 		closeOnClickOutside: true,
	// 		overlayClassName: 'overlay',
	// 	})
	// }

	// const sendFinish = id => {
	// 	api.post('/missions/finish_application/' + row?.user?._id, { id })
	// 		.then(res => {
	// 			showSuccess('modifié!')

	// 			replace(res.data)
	// 		})
	// 		.catch(err => {
	// 			showError('erreur')
	// 		})
	// }

	const refuse = id => {
		let msg =
			"Votre action enverra un e-mail au collaborateur pour l'informer que la candidature est refusé"

		confirmAlert({
			customUI: ({ onClose }) => dialog(onClose, sendRefuse, id, msg),
			closeOnEscape: true,
			closeOnClickOutside: true,
			overlayClassName: 'overlay',
		})
	}

	const sendRefuse = id => {
		api.post('/missions/refuse_application/' + row?.user?._id, { id })
			.then(res => {
				showSuccess('modifié!')

				replace(res.data)
			})
			.catch(err => {
				showError('erreur')
			})
	}
	const accept = id => {
		let msg =
			"Votre action enverra un e-mail au collaborateur pour l'informer que la candidature est Accepté"

		confirmAlert({
			customUI: ({ onClose }) => dialog(onClose, sendAccept, id, msg),
			closeOnEscape: true,
			closeOnClickOutside: true,
			overlayClassName: 'overlay',
		})
	}

	const sendAccept = id => {
		api.post('/missions/accept_application/' + row?.user?._id, { id })
			.then(res => {
				showSuccess('modifié!')

				replace(res.data)
			})
			.catch(err => {
				showError('erreur')
			})
	}

	return (
		<>
			<Dialog fullWidth maxWidth="lg" open={open} onClose={close}>
				<DialogTitle sx={{ display: 'flex', justifyContent: 'space-between' }}>
					<Typography>Information :</Typography>

					{row.status == 'waiting' ? (
						<Chip label="En attente" color="warning" />
					) : row.status == 'refused' ? (
						<Chip label="Refusé" color="error" />
					) : row.status == 'accepted' ? (
						<Chip label="Accepté" color="info" />
					) : row.status == 'canceled' ? (
						<Chip label="Annulé" color="cancel" />
					) : row.status == 'completed' ? (
						<Chip label="Terminé" color="success" />
					) : null}
				</DialogTitle>
				<DialogContent>
					{row.status == 'accepted' &&
						row.cancel_request &&
						row.cancel_request_status == 'pending' && (
							<Stack spacing={1} my={1}>
								<Typography variant="subtitle1" color={'error'}>
									{row.cancel_request &&
										"Le collaborateur a demandé d'annuler cette candidature."}
								</Typography>
								{row.cancel_request && (
									<Typography>Motif d'annulation : {row.cancel_motif}</Typography>
								)}
							</Stack>
						)}

					{row.status == 'canceled' && row.cancel_motif_admin.length > 0 && (
						<Stack spacing={1} my={1}>
							<Typography variant="subtitle1" color={'error'}>
								{row.cancel_request &&
									'Cette mission a été annulée par le partenaire.'}
							</Typography>
							{row.cancel_request && (
								<Typography>
									Motif d'annulation : {row.cancel_motif_admin}
								</Typography>
							)}
						</Stack>
					)}
					<Divider />
					<Box sx={{ m: 2 }}>
						<Grid container spacing={2}>
							<Grid item xs={12} sm={12} md={8} lg={8}>
								<Stack spacing={1}>
									<Stack alignItems={'center'} direction="row" spacing={2}>
										<Typography variant="subtitle1">
											{' '}
											Nom et prénom :
										</Typography>
										<Typography variant="body2">
											{ row?.user?.fname + ' ' + row?.user?.name.toUpperCase()}
										</Typography>
									</Stack>
									{row.status !== 'waiting' && (
										<>
											<Stack
												alignItems={'center'}
												direction="row"
												spacing={2}
											>
												<Typography variant="subtitle1">
													{' '}
													Téléphone:
												</Typography>
												<Typography variant="body2">
													{' '}
													{row?.user?.phone}
												</Typography>
											</Stack>
											<Stack
												alignItems={'center'}
												direction="row"
												spacing={2}
											>
												<Typography variant="subtitle1"> Email:</Typography>
												<Typography
													color={!row?.user?.valid_email && 'error'}
													variant="body2"
												>
													{row?.user?.email}{' '}
													{!row?.user?.valid_email && '| non valide'}
												</Typography>
											</Stack>
										</>
									)}
									<Stack alignItems={'center'} direction="row" spacing={2}>
										<Typography variant="subtitle1">
											Date de naissance :
										</Typography>
										<Typography variant="body2">
											{moment(row?.user?.dob).format('DD-MM-YYYY')}
										</Typography>
									</Stack>
									<Stack alignItems={'center'} direction="row" spacing={2}>
										<Typography variant="subtitle1"> Adresse:</Typography>
										<Typography variant="body2">
											{row?.user?.address + ', ' + row?.user?.postal_code + ' ' + row?.user?.city + ', ' + row?.user?.state}
										</Typography>
									</Stack>
									<Stack alignItems={'center'} direction="row" spacing={2}>
										<Typography variant="subtitle1">
											Complément d'adresse :
										</Typography>
										<Typography variant="body2">
											{row?.user?.address2}
										</Typography>
									</Stack>
								</Stack>
							</Grid>

							<Grid item xs={12} sm={12} md={4} lg={4}>
								<Stack
									spacing={2}
									sx={{
										display: 'flex',

										alignItems: 'center',

										width: '100%',
									}}
								>
									<Box
										sx={{
											display: 'flex',
											justifyContent: 'center',
											alignItems: 'center',

											width: 150,
											height: 150,
											p: 1,
										}}
									>
										<Image
											src={
												row?.user?.avatar.length > 0
													? FILES_URL + row?.user?.avatar
													: '/statics/image-placeholder.png'
											}
										/>
									</Box>
									<Rating
										name="read-only"
										value={Number(row?.user?.rating)}
										readOnly
									/>
									<Stack spacing={1} direction="row">
										<ThumbUp sx={{ color: 'green' }} />
										<Typography variant="subtitle1">
											{row?.user?.nb_recommendation}
										</Typography>
									</Stack>
								</Stack>
							</Grid>
							<Grid xs={12} md={12} lg={12}>
								<Divider />
							</Grid>
							<Grid item xs={12} sm={12} md={12} lg={12}>
								<Stack spacing={2}>
									<Typography variant="subtitle2">Métier(s)</Typography>
									<Stack direction={'row'} spacing={1} flexWrap="wrap">
										{row?.user?.experiences?.length > 0 &&
											row?.user?.experiences?.map(item => (
												<Stack
													direction={'row'}
													sx={{ ml: 1, p: 1, background: '#ededed' }}
													spacing={1}
												>
													<Box>
														<Typography variant="subtitle2">
															{item.job?.name}
														</Typography>
														<Typography
															variant="body2"
															color="text.secondary"
														>
															{moment(item.start_date).format(
																'DD-MM-YYYY'
															) +
																'/' +
																moment(item.end_date).format(
																	'DD-MM-YYYY'
																)}
														</Typography>
													</Box>
												</Stack>
											))}
									</Stack>
								</Stack>
							</Grid>
							<Grid item xs={12} sm={12} md={12} lg={12}>
								<Typography variant="subtitle2">Références</Typography>

								<Stack direction={'row'} spacing={1} flexWrap="wrap">
									{row?.user?.references?.length > 0 &&
										row?.user?.references?.map(item => (
											<Stack
												sx={{ ml: 1, p: 1, background: '#ededed' }}
												spacing={1}
											>
												<Typography variant="subtitle2">
													{item.company_name}
												</Typography>
												<Typography variant="subtitle2">
													{item.name}
												</Typography>
												<Typography variant="body2" color="text.secondary">
													{item.phone}
												</Typography>
												<Typography variant="body2" color="text.secondary">
													{item.email}
												</Typography>
											</Stack>
										))}
								</Stack>
							</Grid>
							<Grid item xs={12} sm={12} md={12} lg={12}>
								<Stack spacing={2}>
									<Typography variant="subtitle2">Diplôme(s)</Typography>
									<Stack direction={'row'} spacing={1} flexWrap="wrap">
										{row?.user?.diplomes?.length > 0 &&
											row?.user?.diplomes?.map(item => (
												<Stack
													direction={'row'}
													sx={{ ml: 1, p: 1, background: '#ededed' }}
													spacing={1}
													alignItems={'center'}
												>
													<Typography variant="subtitle2">
														{diplomes.find(e => e.id == item)?.title}
													</Typography>
												</Stack>
											))}
									</Stack>
								</Stack>
							</Grid>
							<Grid item xs={12} sm={12} md={6} lg={6}>
								<Stack spacing={2}>
									<Typography variant="subtitle2">Logiciels</Typography>
									<Stack direction={'row'} spacing={1} flexWrap="wrap">
										{row?.user?.softwares?.length > 0 &&
											row?.user?.softwares?.map(item => (
												<Stack
													direction={'row'}
													sx={{ ml: 1, p: 1, background: '#ededed' }}
													spacing={1}
													alignItems={'center'}
												>
													<Typography variant="subtitle2">
														{softwares.find(e => e.id == item)?.name}
													</Typography>
												</Stack>
											))}
									</Stack>
								</Stack>
							</Grid>

							<Grid item xs={12} sm={12} md={6} lg={6}>
								<Stack spacing={2}>
									<Typography variant="subtitle2">Langues</Typography>
									<Stack direction={'row'} flexWrap="wrap">
										{row?.user?.languages?.length > 0 &&
											row?.user?.languages?.map(item => (
												<Stack
													direction={'row'}
													sx={{ ml: 1, p: 1, background: '#ededed' }}
													spacing={1}
													alignItems={'center'}
												>
													<Typography variant="subtitle2">
														{langs.find(e => e.id == item.lang)?.title}
													</Typography>
												</Stack>
											))}
									</Stack>
								</Stack>
							</Grid>

							<Grid
								item
								xs={12}
								sm={12}
								md={12}
								lg={12}
								sx={{ border: '1px solid #ccc', m: 1, p: 1 }}
							>
								<Typography variant="subtitle2">Mes motivations</Typography>
								<Typography variant="paragraph"> {row.message}</Typography>
							</Grid>

							<Grid item xs={12} sm={12} md={12} lg={12}>
								<MissionDetails client={row?.client} row={row?.mission} />
							</Grid>
						</Grid>
					</Box>
				</DialogContent>
				<DialogActions>
					{['waiting'].includes(row.status) && (
						<Button onClick={() => accept(row._id)} variant="contained" color="success">
							Accepter
						</Button>
					)}
					{['waiting'].includes(row.status) && (
						<Button
							onClick={() => {
								refuse(row._id)
							}}
							variant="contained"
							color="error"
						>
							Refuser
						</Button>
					)}
					{['accepted'].includes(row.status) && (
						<>
							<Button
								onClick={() => {
									handleClickOpen()
								}}
								variant="contained"
								color="primary"
							>
								Évaluez et terminez
							</Button>
							<Button
								onClick={() => {
									setOpenConfirmation(true)
								}}
								variant="contained"
								color="error"
							>
								Annuler
							</Button>
						</>
					)}

					<Button onClick={close}>Quitter</Button>
				</DialogActions>
			</Dialog>

			<Dialog fullWidth maxWidth="md" open={openRating} onClose={handleClose}>
				<DialogTitle>Évaluation</DialogTitle>
				<DialogContent>
					<Stack spacing={2} alignItems="center">
						<Rating
							value={value}
							size="large"
							getLabelText={getLabelText}
							onChange={(event, newValue) => {
								setValue(newValue)
							}}
						/>
						{value !== null && (
							<Typography>{labels[hover !== -1 ? hover : value]}</Typography>
						)}

						<FormControlLabel
							control={
								<Checkbox
									checked={recommended}
									onChange={event => {
										setRecommended(event.target.checked)
									}}
									inputProps={{ 'aria-label': 'controlled' }}
								/>
							}
							label="Recommander ce candidat"
						/>

						<TextField
							size="small"
							fullWidth
							type="text"
							name="comment"
							label="Commantaire"
							onChange={e => setComment(e.target.value)}
							value={comment}
						/>
					</Stack>
				</DialogContent>
				<DialogActions>
					<Button onClick={() => evaluate(row._id)}>Envoyer</Button>
					<Button onClick={handleClose} autoFocus>
						Annuler
					</Button>
				</DialogActions>
			</Dialog>
			<Dialog
				fullWidth
				maxWidth="sm"
				open={openConfirmation}
				onClose={() => setOpenConfirmation(false)}
			>
				<DialogTitle>Êtes-vous sûr(e) ?</DialogTitle>
				<DialogContent>
					{isMoreThan12HoursAhead(row.mission.start_date) ? (
						<>
							<Typography sx={{ color: 'red', p: 2 }}>
								Vous allez annuler la mission
							</Typography>
							<Stack spacing={1}>
								<FormControl>
									<FormLabel>sélectionner un motif :</FormLabel>
									<RadioGroup
										name="radio-buttons-group"
										value={motif}
										onChange={e => setMotif(e.target.value)}
									>
										{Object.keys(motifs).map(e => (
											<FormControlLabel
												value={e}
												control={<Radio />}
												label={motifs[e]}
											/>
										))}
										<FormControlLabel
											value="m0"
											control={<Radio />}
											label="Autre"
										/>
									</RadioGroup>
								</FormControl>

								{motif == 'm0' && (
									<TextField
										fullWidth
										label="autre * (max 250 char)"
										error={otherMotif.length < 10 || otherMotif.length > 251}
										onChange={event => setOtherMotif(event.target.value)}
										value={otherMotif}
										variant="outlined"
										helperText={
											(otherMotif.length < 10 || otherMotif.length > 251) &&
											'chemp obligatoire * min 10 char max 250 char'
										}
									/>
								)}
							</Stack>
							<Stack direction={'row'} justifyContent={'flex-end'}>
								<Button
									color="error"
									disabled={
										(motif == 'm0' &&
											(otherMotif.length < 10 || otherMotif.length > 251)) ||
										motif == ''
									}
									onClick={() => {
										sendCancel(row._id)
										// setOpenConfirmation(false)
									}}
								>
									ENVOYER
								</Button>
								<Button
									color="info"
									onClick={() => setOpenConfirmation(false)}
									autoFocus
								>
									QUITTER
								</Button>
							</Stack>
						</>
					) : (
						<Stack>
							<Typography color={'error'}>
								Vous pouvez annuler la mission seulement avant 12 heures du début.
							</Typography>
						</Stack>
					)}
				</DialogContent>
			</Dialog>
		</>
	)
}
