import { m } from 'framer-motion'
import { Link as RouterLink } from 'react-router-dom'
// @mui
import { styled } from '@mui/material/styles'
import { Box, Button, Typography, Container, Avatar, Stack } from '@mui/material'
// components

import { useSelector } from 'react-redux'

import { useTheme } from '@mui/material/styles'

import { useState } from 'react'

import { useEffect } from 'react'
import * as Yup from 'yup'
import { useFormik } from 'formik'

import { ToastContainer, toast } from 'react-toastify'

// ----------------------------------------------------------------------

// ----------------------------------------------------------------------

export default function HomePro() {
	const [loading, setLoading] = useState(false)

	const [cnxErr, setCnxErr] = useState(null)

	useEffect(() => {}, [])

	if (cnxErr)
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '60vh',
					border: '1px solid #ccc',
					p: 2,
				}}
			>
				<Typography color={'error'} variant="h6">
					probleme de connexion ...
				</Typography>
			</Box>
		)
	if (loading)
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '60vh',
					border: '1px solid #ccc',
					p: 2,
				}}
			>
				<Typography variant="h6"> Chargement ...</Typography>
			</Box>
		)

	return (
		<Box
			sx={{
				display: 'flex',
				justifyContent: 'center',
				alignItems: 'center',
				minHeight: '50vh',

				p: 2,
			}}
		>
			<Stack spacing={2}>
				<Box
					sx={{
						display: 'flex',
						justifyContent: 'center',
						alignItems: 'center',
					}}
				>
					<Box
						sx={{
							display: 'flex',
							justifyContent: 'center',
							alignItems: 'center',
							width: 400,
						}}
					>
						<img
							style={{ width: '100%', height: '100%' }}
							src="/statics/undraw_Security_on_re_e491.png"
						/>
					</Box>
					<Typography variant="h5">Bienvenue sur votre espace partenaire</Typography>
				</Box>
			</Stack>
		</Box>
	)
}
