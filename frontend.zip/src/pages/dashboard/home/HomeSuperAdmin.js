	import { Box, Typography, Grid, Card, CardContent } from '@mui/material';
	import { useEffect, useState } from 'react';
	import { useSelector } from 'react-redux';
	import api from 'src/Api';
	// components
	import Page from 'src/components/Page';
	import MissionsPieChart from '../admin/charts/MissionsPieChart';
	import CAChart from '../admin/charts/CAChart';


	export default function HomeSuperAdmin() {
		const [loading, setLoading] = useState(false);
		const [error, setError] = useState(false);
		const auth = useSelector(state => state.auth);
		

		
		return (
			<Page title="Tableau de bord" sx={{ height: 1 }}>
				<Box sx={{ padding: 3 }}>
				{console.log(localStorage.getItem('lastActivity'))}
					<Grid container spacing={2}>

					{/* Métiers demandés par les partenaires */}
						<Grid item xs={12} sm={6} md={4}>
							<Card>
								<CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>						
									<Typography variant="h6" gutterBottom>
									Les métiers les plus demandés
									</Typography>
									<MissionsPieChart />
								</CardContent>
							</Card>
						</Grid>

						<Grid item xs={12} sm={6} md={8}>
							<Card>
								<CardContent>
									<Typography variant="h6" gutterBottom>
									Chiffre d'affaires
									</Typography>	
									<CAChart/>
								</CardContent>
							</Card>
						</Grid>

					{/* Ajoutez d'autres graphiques ici en suivant le même modèle */}
					</Grid>
				</Box>
			</Page>
		);
	}
