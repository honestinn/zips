import {
	AccessTime,
	CalendarMonth,
	Check,
	DoNotDisturbAlt,
	ExpandLess,
	ExpandMore,
	LocalOffer,
	Place,
	StarBorder,
} from '@mui/icons-material'
import {
	Box,
	Button,
	Card,
	CardContent,
	Collapse,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	FormControl,
	FormControlLabel,
	FormLabel,
	Grid,
	Paper,
	Radio,
	RadioGroup,
	Stack,
	TextField,
	Typography,
} from '@mui/material'
import React, { useState } from 'react'
import api, { FILES_URL } from 'src/Api'
import { confirmAlert } from 'react-confirm-alert'
import moment from 'moment'
import { ToastContainer } from 'react-toastify'
import { reloadResources } from 'i18next'
import Image from 'src/components/Image'

function msToHMS(time1, time2, pause) {
	const time1Parts = time1.split(':')
	const time2Parts = time2.split(':')

	const date1 = new Date(0, 0, 0, parseInt(time1Parts[0]), parseInt(time1Parts[1]))
	let date2 = new Date(0, 0, 0, parseInt(time2Parts[0]), parseInt(time2Parts[1]))

	if (date2 < date1) {
		// If time2 is earlier in the day than time1, add 24 hours to date2 to account for next day
		date2.setDate(date2.getDate() + 1)
	}

	const differenceMilliseconds = Math.abs(date2 - date1) - pause * 60000

	const seconds = Math.floor((differenceMilliseconds / 1000) % 60)
	const minutes = Math.floor((differenceMilliseconds / (1000 * 60)) % 60)
	const hours = Math.floor(differenceMilliseconds / (1000 * 60 * 60))

	const formattedTime = `${String(hours).padStart(2, '0')} h :${String(minutes).padStart(
		2,
		'0'
	)} min`
	return formattedTime
}
function isLessThan24Hours(date) {
	const twelveHoursInMilliseconds = 24 * 60 * 60 * 1000 // 12 hours in milliseconds
	const currentDate = new Date()

	return (
		new Date(date) - currentDate <= twelveHoursInMilliseconds || new Date(date) <= currentDate
	)
}
function missionStarted(date) {
	const currentDate = new Date()
	return new Date(date) <= currentDate
}

export default function MissionCard({
	row,
	setExpanded,
	showError,
	showSuccess,
	replace,
	userId,
	refresh,
	cancel_count,
	motifs,
	applicationId,
}) {
	const [motif, setMotif] = useState('')
	const [validMotif, setValidMotif] = useState(true)
	const [otherMotif, setOtherMotif] = useState('')
	const [openConfirmation, setOpenConfirmation] = useState(false)
	const [confirmationType, setConfirmationType] = useState('')

	const sendCancelRequest = () => {
		let reason = motif == 'm0' ? otherMotif : motifs[motif]
		api.post('/missions/cancel_request/' + userId, { applicationId, motif: reason })
			.then(res => {
				replace("votre demande d'anulation a été envoyé!")
				// showSuccess("votre demande d'anulation a été envoyé!")
			})
			.catch(err => {
				showError('erreur')
			})
	}
	const sendDeleteCancelRequest = () => {
		api.post('/missions/delete_cancel_request/' + userId, { applicationId })
			.then(res => {
				replace("votre demande d'anulation a été supprimé!")
				// showSuccess("votre demande d'anulation a été supprimé!")
			})
			.catch(err => {
				showError('erreur')
			})
	}
	const cancelMission = () => {
		api.post('/missions/cancel_mission', { applicationId })
			.then(res => {
				replace('la missiona été annulé!')
			})
			.catch(err => {
				showError('erreur')
			})
	}
	let start_date = new Date(row?.start_date)

	start_date.setDate(start_date.getDate() - 1)
	return (
		<>
			<Grid container spacing={1}>
				<Grid item xs={12} md={3} lg={3}>
					<Stack justifyContent="center" alignItems="center" spacing={1} minHeight={200}>
						<Box
							sx={{
								display: 'flex',
								justifyContent: 'center',
								alignItems: 'center',

								width: 150,
								height: 150,
								p: 1,
							}}
						>
							<Image
								src={
									row?.client?.avatar.length > 0
										? FILES_URL + row?.client?.avatar
										: '/statics/image-placeholder.png'
								}
							/>
						</Box>

						<Typography color={'text.secondary'} variant="body2">
							ID :{row.uid}
						</Typography>
					</Stack>
				</Grid>
				<Grid item xs={12} md={6} lg={6}>
					<Stack sx={{ height: '100%' }} justifyContent={'space-between'} spacing={1}>
						<Stack spacing={1}>
							<Typography variant="h6">
								{row?.job?.subcategory?.name}
								{' - '}
								{row?.job?.name}
							</Typography>
							<Stack alignItems="center" direction="row" spacing={1}>
								<Typography variant="subtitle2">
									{row?.client?.company_name}
								</Typography>
								<Stack direction="row" alignItems="center" spacing={0}>
									<StarBorder fontSize="10" />
									<Typography color={'text.secondary'} variant="body2">
										{row?.client?.title}
									</Typography>
								</Stack>
							</Stack>
						</Stack>

						<Stack
							sx={{
								typography: 'body2',
								color: 'text.secondary',
								p: 1,
							}}
							spacing={1}
						>
							<Stack
								direction="row"
								alignItems="center"
								justifyContent={'space-between'}
								spacing={2}
							>
								<Stack direction="row" spacing={1}>
									<Place fontSize="small" />
									{row?.address}
								</Stack>
								<Stack direction="row" alignItems="center" spacing={1}>
									<LocalOffer fontSize="10" />
									<Typography>{row?.hour_salary + ' €/H'}</Typography>
								</Stack>
							</Stack>
						</Stack>
						<Stack spacing={1} direction={'row'}>
							<Typography color={'text.secondary'} variant="body2">
								Du
							</Typography>
							<Typography color={'text.secondary'} variant="body2">
								{moment(row?.start_date).format('DD-MM-YYYY HH:mm')}
							</Typography>
							<Typography color={'text.secondary'} variant="body2">
								au
							</Typography>
							<Typography color={'text.secondary'} variant="body2">
								{moment(row?.end_date).format('DD-MM-YYYY HH:mm')}
							</Typography>
						</Stack>

						{row?.periods && row?.periods.length > 1 && (
							<Stack direction={'row'} justifyContent={'flex-end'}>
								<Button
									sx={{ width: 100 }}
									onClick={() => setExpanded(row)}
									startIcon={row?.expanded ? <ExpandLess /> : <ExpandMore />}
									size="small"
								>
									{row.expanded ? 'Moins' : 'Plus'}
								</Button>
							</Stack>
						)}
						{row.periods &&
							row.periods.length > 0 &&
							row.periods.map((item, index) => {
								if (index == 0)
									return (
										<Paper
											variant="outlined"
											sx={{ p: 0.5, mb: 1, maxWidth: 420 }}
										>
											<Stack
												direction="row"
												alignItems={'center'}
												spacing={1}
											>
												<CalendarMonth fontSize="10" />
												<Typography variant="body2">
													{moment(item.date).format('DD-MM-YYYY')}
												</Typography>
												<Typography>|</Typography>
												<Typography variant="body2">{item.from}</Typography>
												<Typography>-</Typography>
												<Typography variant="body2">{item.to}</Typography>
												<Typography>|</Typography>
												<AccessTime fontSize="10" />
												<Typography variant="body2">
													{msToHMS(item.from, item.to, item.pause)}
												</Typography>
											</Stack>
										</Paper>
									)
								return null
							})}
						<Collapse style={{ transitionDuration: '1s' }} in={row.expanded}>
							{row.periods &&
								row.periods.map((item, index) => {
									if (index == 0) return null
									else
										return (
											<Paper
												variant="outlined"
												sx={{ p: 0.5, mb: 1, maxWidth: 420 }}
											>
												<Stack
													direction="row"
													alignItems={'center'}
													spacing={1}
												>
													<CalendarMonth fontSize="10" />
													<Typography variant="body2">
														{moment(item.date).format('DD-MM-YYYY')}
													</Typography>
													<Typography>|</Typography>
													<Typography variant="body2">
														{item.from}
													</Typography>
													<Typography>-</Typography>
													<Typography variant="body2">
														{item.to}
													</Typography>
													<Typography>|</Typography>
													<AccessTime fontSize="10" />
													<Typography variant="body2">
														{msToHMS(item.from, item.to, item.pause)}
													</Typography>
												</Stack>
											</Paper>
										)
								})}
						</Collapse>
					</Stack>
				</Grid>
				<Grid item xs={12} md={3} lg={3}>
					<Stack
						sx={{
							display: 'flex',
							alignItems: 'center',
							justifyContent: 'center',
							height: '100%',
						}}
						spacing={1}
					>
						<Typography variant="h3">{row?.total?.toFixed(2) + ' €'}</Typography>
						<Button color="success" fullWidth variant="contained" size="large">
							Accepté
						</Button>

						{!missionStarted(start_date) && (
							<Button
								color="error"
								fullWidth
								variant="text"
								size="small"
								sx={{ textTransform: 'none' }}
								onClick={() => {
									setConfirmationType('cancel')
									setOpenConfirmation(true)
								}}
							>
								Annuler la mission
							</Button>
						)}

						{missionStarted(start_date) && (
							<>
								{row.cancel_request ? (
									<>
										{row.cancel_request_status == 'pending' && (
											<Button
												color="error"
												fullWidth
												variant="text"
												size="small"
												sx={{ textTransform: 'none' }}
												onClick={() => {
													setConfirmationType('delete_req')
													setOpenConfirmation(true)
												}}
											>
												Supprimer la demande d'annulation
											</Button>
										)}
									</>
								) : (
									<Button
										color="error"
										fullWidth
										variant="text"
										size="small"
										sx={{ textTransform: 'none' }}
										onClick={() => {
											setConfirmationType('send_req')
											setOpenConfirmation(true)
										}}
									>
										Demande d'annulation
									</Button>
								)}
							</>
						)}
					</Stack>
				</Grid>
			</Grid>
			<Dialog
				fullWidth
				maxWidth="sm"
				open={openConfirmation}
				onClose={() => setOpenConfirmation(false)}
			>
				<DialogTitle>Êtes-vous sûr(e) ?</DialogTitle>
				<DialogContent>
					{/* {!isMoreThan24Hours(selectedDate) ? (
						<> */}
					{confirmationType == 'send_req' && (
						<>
							<Typography sx={{ color: 'red', p: 2 }}>
								Votre action enverra une demande d'annulation.
							</Typography>
							{cancel_count == 2 && (
								<Typography variant="subtitle2" my={1}>
									Attention, si vous annulez cette mission, vous serez suspendu
									car vous dépasserez le nombre maximal d'annulations
									consécutives.
								</Typography>
							)}
							<Stack spacing={1}>
								<FormControl>
									<FormLabel>sélectionner un motif :</FormLabel>
									<RadioGroup
										name="radio-buttons-group"
										value={motif}
										onChange={e => setMotif(e.target.value)}
									>
										{Object.keys(motifs).map(e => (
											<FormControlLabel
												value={e}
												control={<Radio />}
												label={motifs[e]}
											/>
										))}
										<FormControlLabel
											value="m0"
											control={<Radio />}
											label="Autre"
										/>
									</RadioGroup>
								</FormControl>

								{motif == 'm0' && (
									<TextField
										fullWidth
										label="autre * (max 250 char)"
										error={otherMotif.length < 10 || otherMotif.length > 251}
										onChange={event => setOtherMotif(event.target.value)}
										value={otherMotif}
										variant="outlined"
										helperText={
											(otherMotif.length < 10 || otherMotif.length > 251) &&
											'chemp obligatoire * min 10 char max 250 char'
										}
									/>
								)}
							</Stack>
							<Stack direction={'row'} justifyContent={'flex-end'}>
								<Button
									color="error"
									disabled={
										(motif == 'm0' &&
											(otherMotif.length < 10 || otherMotif.length > 251)) ||
										motif == ''
									}
									onClick={() => {
										sendCancelRequest()
										setOpenConfirmation(false)
									}}
								>
									ENVOYER
								</Button>
								<Button
									color="info"
									onClick={() => setOpenConfirmation(false)}
									autoFocus
								>
									QUITTER
								</Button>
							</Stack>
						</>
					)}
					{confirmationType == 'delete_req' && (
						<>
							<Typography sx={{ color: 'red', textAlign: 'center', pt: 2 }}>
								Votre action supprimera la demande d'annulation.
							</Typography>

							<Stack direction={'row'} justifyContent={'flex-end'}>
								<Button
									color="error"
									onClick={() => {
										sendDeleteCancelRequest()
										setOpenConfirmation(false)
									}}
								>
									OUI
								</Button>
								<Button
									color="info"
									onClick={() => setOpenConfirmation(false)}
									autoFocus
								>
									QUITTER
								</Button>
							</Stack>
						</>
					)}
					{confirmationType == 'cancel' && (
						<>
							<Typography sx={{ color: 'red', textAlign: 'center', pt: 2 }}>
								Attention, vous allez annuler cette mission et vous ne pourrez pas
								postuler à nouveau.
							</Typography>
							<Typography variant="caption" sx={{ pt: 2 }}>
								La mission ne peut être annulée que 24 heures avant le début prévu.
							</Typography>

							<Stack direction={'row'} justifyContent={'flex-end'}>
								<Button
									color="error"
									disabled={isLessThan24Hours(row?.start_date)}
									onClick={() => {
										cancelMission()
										setOpenConfirmation(false)
									}}
								>
									OUI
								</Button>
								<Button
									color="info"
									onClick={() => setOpenConfirmation(false)}
									autoFocus
								>
									QUITTER
								</Button>
							</Stack>
						</>
					)}
				</DialogContent>
			</Dialog>
			<ToastContainer
				autoClose={3000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
			/>
		</>
	)
}
