import {
	Alert,
	Autocomplete,
	Avatar,
	Box,
	Button,
	Card,
	CardActions,
	CardContent,
	Chip,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	Divider,
	FormControl,
	Grid,
	Stack,
	Switch,
	TextField,
	Typography,
} from '@mui/material'
import api from 'src/Api'
import { useFormik } from 'formik'
import { useEffect, useState } from 'react'

import * as Yup from 'yup'
import { Check, Close, Upload } from '@mui/icons-material'
import { LoadingButton } from '@mui/lab'
import { confirmAlert } from 'react-confirm-alert'

import MissionDetails from './MissionDetails'

export default function Show({ open, close, row }) {
	useEffect(() => {}, [open])

	return (
		<Dialog fullWidth maxWidth="md" open={open} onClose={close}>
			<DialogTitle sx={{ display: 'flex', justifyContent: 'space-between' }}>
				<Typography>Information :</Typography>
				{row.status == 'waiting' ? (
					<Chip label="En attente" color="warning" />
				) : row.status == 'refused' ? (
					<Chip label="Refusé" color="error" />
				) : row.status == 'accepted' ? (
					<Chip label="Accepté" color="success" />
				) : null}{' '}
			</DialogTitle>
			<DialogContent>
				{row.status == 'accepted' &&
					row.cancel_request &&
					row.cancel_request_status == 'pending' && (
						<Stack spacing={1} my={1}>
							<Typography variant="subtitle1" color={'error'}>
								{row.cancel_request &&
									"Le collaborateur a demandé d'annuler cette candidature."}
							</Typography>
							{row.cancel_request && (
								<Typography>Motif d'annulation : {row.cancel_motif}</Typography>
							)}
						</Stack>
					)}

				{row.status == 'canceled' && row.cancel_motif_admin.length > 0 && (
					<Stack spacing={1} my={1}>
						<Typography variant="subtitle1" color={'error'}>
							{row.cancel_request && 'Cette mission a été annulée par le partenaire.'}
						</Typography>
						{row.cancel_request && (
							<Typography>Motif d'annulation : {row.cancel_motif_admin}</Typography>
						)}
					</Stack>
				)}
				<MissionDetails row={{ ...row?.mission, client: row?.client }} />
			</DialogContent>
			<DialogActions>
				<Button onClick={close}>Quitter</Button>
			</DialogActions>
		</Dialog>
	)
}
