import { Box, Typography } from '@mui/material'
// components
import Page from 'src/components/Page'

export default function HomeAdmin() {
	return (
		<Page title="Accueil" sx={{ height: 1 }}>
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					height: '60vh',
				}}
			>
				<Typography variant="h5">
					Bonjour, Vous êtes dans le tableau de bord, vous avez le droit de tout gérer.
				</Typography>
			</Box>
		</Page>
	)
}
