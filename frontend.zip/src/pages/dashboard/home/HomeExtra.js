import {
	Edit,
	Info,
	PlusOne,
	Refresh,
	Search,
	StopCircle,
	ThumbUp,
	WifiOff,
	WifiTethering,
} from '@mui/icons-material'
import api, { FILES_URL } from 'src/Api'
import {
	Avatar,
	Box,
	Button,
	Card,
	CardContent,
	CardMedia,
	Chip,
	CircularProgress,
	Container,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	FormControl,
	Grid,
	IconButton,
	InputAdornment,
	Link,
	OutlinedInput,
	Paper,
	Rating,
	Stack,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	Typography,
} from '@mui/material'
import { useEffect, useState } from 'react'
import Page from 'src/components/Page'
import './style.css'
import useSettings from 'src/hooks/useSettings'

import { useSelector } from 'react-redux'
import { ToastContainer, toast } from 'react-toastify'
import Show from './Show'
import MissionCard from './MissionCard'
import RouterLink from 'src/hooks/RouterLink'
import { confirmAlert } from 'react-confirm-alert'
import moment from 'moment'
import { LoadingButton } from '@mui/lab'
import Image from 'src/components/Image'
const labels = {
	0.5: '',
	1: '',
	1.5: '',
	2: '',
	2.5: '',
	3: '',
	3.5: '',
	4: '',
	4.5: '',
	5: '',
}
function getLabelText(value) {
	return `${value} Star${value !== 1 ? 's' : ''}, ${labels[value]}`
}
function isLessThan24Hours(date) {
	const twelveHoursInMilliseconds = 24 * 60 * 60 * 1000 // 12 hours in milliseconds
	const currentDate = new Date()

	return (
		new Date(date) - currentDate <= twelveHoursInMilliseconds || new Date(date) <= currentDate
	)
}

export default function HomeExtra() {
	const { themeStretch } = useSettings()

	const [page, setPage] = useState(0)
	const [rowsPerPage, setRowsPerPage] = useState(25)
	const [loading, setLoading] = useState(false)
	const [selected, setSelected] = useState(null)
	const [user, setUser] = useState(null)
	const [openConfirmation, setOpenConfirmation] = useState(false)
	const [confirmationType, setConfirmationType] = useState(false)
	const [reviews, setReviews] = useState([])
	const [motifs, setMotifs] = useState([])
	const [selectedDate, setSelectedDate] = useState(null)
	const [toRateClient, setToRateClient] = useState(null)

	const [applications, setApplications] = useState([])
	const [selectedApplicationId, setSelectedApplicationId] = useState('')
	const [selectedApplicationStatus, setSelectedApplicationStatus] = useState('waiting')
	const [currentMission, setCurrentMission] = useState([])
	const [nextMissions, setNextMissions] = useState([])
	const [value, setValue] = useState(2)
	const [hover, setHover] = useState(-1)
	const [submitting, setSubmitting] = useState(false)
	const [cancelWait, setOpenCancelWait] = useState(false)

	const [openShow, setOpenShow] = useState(false)
	const [error, setError] = useState(false)

	const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - applications.length) : 0
	const handleChangePage = (event, newPage) => {
		setPage(newPage)
	}

	const handleChangeRowsPerPage = event => {
		setRowsPerPage(parseInt(event.target.value, 10))
		setPage(0)
	}
	const setExpanded = mission => {
		const expanded = mission.expanded ? false : true
		setCurrentMission({ ...mission, expanded })
	}

	const sendCancel = () => {
		if (selectedApplicationStatus == 'waiting') {
			api.post('/missions/cancel_user_application', { applicationId: selectedApplicationId })
				.then(res => {
					getApplications('la mission a été annulée avec succès')
				})
				.catch(err => {
					showError("quelque chose s'est mal passé")
				})
		}
		if (selectedApplicationStatus == 'accepted') {
			api.post('/missions/cancel_mission', { applicationId: selectedApplicationId })
				.then(res => {
					getApplications('la mission a été annulée avec succès')
				})
				.catch(err => {
					showError('erreur')
				})
		}
	}
	useEffect(() => {
		getApplications()
		getUser()
		getReviews()
		getMotifs()
	}, [])
	const getUser = () => {
		// Headers
		api.get('/users/get')
			.then(res => {
				setUser(res.data)
			})
			.catch(err => {})
	}
	const getReviews = () => {
		api.get('/missions/get_reviews')
			.then(res => {
				setReviews(res.data)
			})
			.catch(err => {
				setError(true)
			})
	}
	const evaluate = id => {
		api.post('/missions/evaluate_client', {
			toRateClient,
			rating: value,
		})
			.then(res => {
				showSuccess('Votre évaluation a bien été enregistrée')
				setToRateClient(null)
			})
			.catch(err => {
				showError('erreur')
			})
	}

	const getApplications = msg => {
		setLoading(true)
		api.get('/missions/get_my_missions')
			.then(res => {
				setApplications(res.data.applications)
				setCurrentMission(res.data.current_mission)
				setToRateClient(res.data.toRate)
				setNextMissions(res.data.next_missions)
				setLoading(false)
				if (msg?.length) showSuccess(msg)
			})
			.catch(err => {
				setLoading(false)
				setError(true)
			})
	}
	const getMotifs = () => {
		api.get('/users/get_motifs_list')
			.then(res => {
				setMotifs(res.data)
			})
			.catch(err => {
				setError(true)
			})
	}

	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	if (loading)
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					height: '60vh',
				}}
			>
				<Stack alignItems={'center'} direction={'row'} spacing={1}>
					<CircularProgress /> <Typography>Chargement...</Typography>
				</Stack>
			</Box>
		)
	if (error)
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					height: '60vh',
				}}
			>
				<Stack sx={{ color: 'red' }} alignItems={'center'} direction={'row'} spacing={1}>
					<WifiTethering /> <Typography>Problème de connexion...</Typography>
				</Stack>
			</Box>
		)

	return (
		<>
			<Page title="Accueil">
				<Container maxWidth={themeStretch ? false : 'xl'}>
					<Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
						<IconButton onClick={getApplications}>
							<Refresh />
						</IconButton>
					</Box>

					<Grid container spacing={1}>
						<Grid item xs={12} md={3} lg={3}>
							<Paper sx={{ p: 1 }} variant="outlined">
								<Box
									sx={{
										display: 'flex',
										justifyContent: 'center',
										alignItems: 'center',

										width: '100%',
									}}
								>
									<Box
										sx={{
											display: 'flex',
											justifyContent: 'center',
											alignItems: 'center',
											width: 200,
											height: 200,
											p: 1,
										}}
									>
										<Image
											src={
												user?.avatar.length > 0
													? FILES_URL + user?.avatar
													: '/statics/image-placeholder.png'
											}
										/>
									</Box>
								</Box>

								<Stack spacing={1} alignItems="center">
									<Link
										variant="button"
										color="text.primary"
										component={RouterLink}
										underline="none"
										href="/dashboard/profile"
										sx={{
											mx: 1.5,
											display: 'flex',
											alignItems: 'center',
										}}
									>
										<Button
											sx={{ ml: 2 }}
											variant="outlined"
											startIcon={<Edit />}
										>
											<Typography sx={{ mx: 2 }}>Mon profil</Typography>
										</Button>
									</Link>

									<Rating
										name="read-only"
										value={Number(user?.rating)}
										readOnly
									/>
									<Stack spacing={1} direction="row">
										<ThumbUp sx={{ color: 'green' }} />
										<Typography variant="subtitle1">
											{user?.nb_recommendation}
										</Typography>
									</Stack>
								</Stack>
							</Paper>
						</Grid>
						<Grid item xs={12} md={9} lg={9}>
							<Stack spacing={2}>
								{!loading && toRateClient && (
									<Paper sx={{ p: 1 }} variant="outlined">
										<Stack
											direction={'row'}
											sx={{
												p: 1,
												m: 1,
												justifyContent: 'space_between',
												alignItems: 'center',
											}}
										>
											<Typography variant="subtitle2" textAlign={'center'}>
												La mission est terminée. Vous pouvez procéder au
												paiement Comment était votre expérience ? Veuillez
												la noter, s'il vous plaît.
											</Typography>
											<Rating
												sx={{ mx: 1 }}
												value={value}
												size="large"
												getLabelText={getLabelText}
												onChange={(event, newValue) => {
													setValue(newValue)
												}}
											/>
											{value !== null && (
												<Typography>
													{labels[hover !== -1 ? hover : value]}
												</Typography>
											)}
											<LoadingButton
												loading={submitting}
												onClick={() => evaluate()}
												sx={{ mx: 1 }}
											>
												Envoyer
											</LoadingButton>
										</Stack>
									</Paper>
								)}
								<Paper sx={{ p: 1 }} variant="outlined">
									{!loading && !currentMission && (
										<Stack
											sx={{
												p: 1,
												display: 'flex',

												mt: 1,
												justifyContent: 'center',
												alignItems: 'center',
												minHeight: 120,
											}}
										>
											<Typography>
												Vous n’avez aucune mission disponible
											</Typography>
											<Box>
												<Link
													variant="button"
													color="text.primary"
													component={RouterLink}
													underline="none"
													href="/dashboard/missions"
													sx={{
														mx: 1.5,
														display: 'flex',
														alignItems: 'center',
													}}
												>
													<Button
														sx={{ ml: 2, textTransform: 'none' }}
														variant="outlined"
														startIcon={<Search />}
													>
														<Typography sx={{ mx: 2 }}>
															Rechercher une mission
														</Typography>
													</Button>
												</Link>
											</Box>
										</Stack>
									)}

									{!loading && currentMission !== null && (
										<MissionCard
											row={currentMission}
											setExpanded={setExpanded}
											showSuccess={showSuccess}
											applicationId={currentMission?.applicationId}
											userId={user?._id}
											cancel_count={user?.cancel_count}
											motifs={motifs}
											showError={showError}
											replace={msg => getApplications(msg)}
										/>
									)}
								</Paper>
								{nextMissions?.length > 1 && (
									<Paper sx={{ p: 1 }} variant="outlined">
										<Typography sx={{ mb: 1 }} variant="subtitle2">
											Les missions suivant :
										</Typography>

										<TableContainer>
											<Table size="small">
												<TableBody>
													{!loading &&
														nextMissions.map((row, index) => {
															if (index == 0) return null
															return (
																<TableRow
																	hover
																	key={row._id}
																	tabIndex={-1}
																>
																	<TableCell
																		scope="row"
																		padding="none"
																	>
																		<Stack
																			direction="row"
																			alignItems="center"
																			spacing={2}
																		>
																			<Stack>
																				<Typography
																					variant="subtitle2"
																					noWrap
																				>
																					{row.mission
																						?.job
																						.subcategory
																						.name +
																						' - ' +
																						row.mission
																							?.job
																							.name}
																				</Typography>
																				<Typography variant="body2">
																					ID:
																					{
																						row.mission
																							?.uid
																					}
																				</Typography>
																			</Stack>
																		</Stack>
																	</TableCell>

																	<TableCell>
																		<Typography variant="body2">
																			{moment(
																				row.mission
																					?.start_date
																			).format(
																				'DD-MM-YYYY HH:mm'
																			) +
																				' -> ' +
																				moment(
																					row.mission
																						?.end_date
																				).format(
																					'DD-MM-YYYY HH:mm'
																				)}
																		</Typography>
																	</TableCell>
																	<TableCell
																		sx={{ textAlign: 'center' }}
																	>
																		<IconButton
																			onClick={() => {
																				setSelected(row)
																				setOpenShow(true)
																			}}
																		>
																			<Info />
																		</IconButton>
																	</TableCell>
																</TableRow>
															)
														})}
													{!loading && emptyRows > 0 && (
														<TableRow
															style={{ height: 53 * emptyRows }}
														>
															<TableCell colSpan={4} />
														</TableRow>
													)}
													{!loading && error && (
														<TableRow
															style={{ height: 53 * emptyRows }}
														>
															<TableCell colSpan={7}>
																<Box
																	sx={{
																		display: 'flex',
																		justifyContent: 'center',
																	}}
																>
																	<WifiOff />
																</Box>
																<Box
																	sx={{
																		display: 'flex',
																		justifyContent: 'center',
																	}}
																>
																	<Typography
																		variant="h6"
																		color="#383737"
																	>
																		Vérifier votre connexion
																		internet et réessayer.
																	</Typography>
																</Box>
															</TableCell>
														</TableRow>
													)}
													{loading && (
														<TableRow
															style={{ height: 53 * emptyRows }}
														>
															<TableCell colSpan={7}>
																<Box
																	sx={{
																		display: 'flex',
																		justifyContent: 'center',
																		pt: 3,
																		pb: 1,
																		px: 1,
																	}}
																>
																	<CircularProgress />
																</Box>
																<Box
																	sx={{
																		display: 'flex',
																		justifyContent: 'center',
																		pb: 3,
																		px: 1,
																	}}
																>
																	<Typography
																		variant="h6"
																		color="#383737"
																	>
																		Chargement de contenu.
																	</Typography>
																</Box>
															</TableCell>
														</TableRow>
													)}
													{!loading &&
														applications.length == 0 &&
														!error && (
															<TableRow>
																<TableCell colSpan={7}>
																	<Box
																		sx={{
																			display: 'flex',
																			justifyContent:
																				'center',
																			mb: 2,
																			mt: 2,
																		}}
																	>
																		<StopCircle />
																	</Box>
																	<Box
																		sx={{
																			display: 'flex',
																			justifyContent:
																				'center',
																		}}
																	>
																		<Typography
																			variant="h6"
																			color="#383737"
																		>
																			Aucune candidatures.
																		</Typography>
																	</Box>
																</TableCell>
															</TableRow>
														)}
												</TableBody>
											</Table>
										</TableContainer>
									</Paper>
								)}
								<Paper sx={{ p: 1 }} variant="outlined">
									<Typography sx={{ mb: 1 }} variant="subtitle2">
										Liste des candidatures :
									</Typography>

									<TableContainer>
										<Table size="small">
											<TableBody>
												{!loading &&
													applications.map(row => {
														return (
															<TableRow
																hover
																key={row._id}
																tabIndex={-1}
															>
																<TableCell
																	scope="row"
																	padding="none"
																>
																	<Stack
																		direction="row"
																		alignItems="center"
																		spacing={2}
																	>
																		<Stack>
																			<Typography
																				variant="subtitle2"
																				noWrap
																			>
																				{row.mission?.job
																					.subcategory
																					.name +
																					' - ' +
																					row.mission?.job
																						.name}
																			</Typography>
																			<Typography variant="body2">
																				ID:
																				{row.mission.uid}
																			</Typography>
																			<Typography variant="body2">
																				{moment(
																					row.mission
																						?.start_date
																				).format(
																					'DD-MM-YYYY HH:mm'
																				) +
																					' -> ' +
																					moment(
																						row.mission
																							?.end_date
																					).format(
																						'DD-MM-YYYY HH:mm'
																					)}
																			</Typography>
																		</Stack>
																	</Stack>
																</TableCell>

																<TableCell>
																	{row.status == 'waiting' ? (
																		<Chip
																			label="En attente"
																			color="warning"
																		/>
																	) : row.status == 'refused' ? (
																		<Chip
																			label="Refusé"
																			color="error"
																		/>
																	) : row.status == 'accepted' ? (
																		<Chip
																			label="Accepté"
																			color="info"
																		/>
																	) : row.status ==
																	  'completed' ? (
																		<Chip
																			label="Terminé"
																			color="success"
																		/>
																	) : row.status == 'canceled' ? (
																		<Chip
																			label="Annulé"
																			color="cancel"
																		/>
																	) : null}
																</TableCell>
																<TableCell>
																	{row.status == 'waiting' && (
																		<Button
																			color="error"
																			fullWidth
																			variant="text"
																			size="small"
																			onClick={() => {
																				setSelectedApplicationId(
																					row._id
																				)
																				setSelectedApplicationStatus(
																					row.status
																				)
																				setSelectedDate(
																					row.mission
																						.start_date
																				)

																				setOpenCancelWait(
																					true
																				)

																				// cancel(row._id)
																			}}
																		>
																			me désengager
																		</Button>
																	)}
																	{row.status == 'accepted' && (
																		<Button
																			color="error"
																			fullWidth
																			variant="text"
																			size="small"
																			onClick={() => {
																				setSelectedApplicationId(
																					row._id
																				)
																				setSelectedApplicationStatus(
																					row.status
																				)
																				setSelectedDate(
																					row.mission
																						.start_date
																				)
																				setOpenConfirmation(
																					true
																				)

																				// cancel(row._id)
																			}}
																		>
																			Annuler
																		</Button>
																	)}
																</TableCell>
																<TableCell>
																	{moment(row.created_at).format(
																		'DD-MM-YYYY / HH:MM'
																	)}
																</TableCell>
																<TableCell
																	sx={{ textAlign: 'center' }}
																>
																	<IconButton
																		onClick={() => {
																			setSelected(row)

																			setOpenShow(true)
																		}}
																	>
																		<Info />
																	</IconButton>
																</TableCell>
															</TableRow>
														)
													})}
												{!loading && emptyRows > 0 && (
													<TableRow style={{ height: 53 * emptyRows }}>
														<TableCell colSpan={4} />
													</TableRow>
												)}
												{!loading && error && (
													<TableRow style={{ height: 53 * emptyRows }}>
														<TableCell colSpan={7}>
															<Box
																sx={{
																	display: 'flex',
																	justifyContent: 'center',
																}}
															>
																<WifiOff />
															</Box>
															<Box
																sx={{
																	display: 'flex',
																	justifyContent: 'center',
																}}
															>
																<Typography
																	variant="h6"
																	color="#383737"
																>
																	Vérifier votre connexion
																	internet et réessayer.
																</Typography>
															</Box>
														</TableCell>
													</TableRow>
												)}
												{loading && (
													<TableRow style={{ height: 53 * emptyRows }}>
														<TableCell colSpan={7}>
															<Box
																sx={{
																	display: 'flex',
																	justifyContent: 'center',
																	pt: 3,
																	pb: 1,
																	px: 1,
																}}
															>
																<CircularProgress />
															</Box>
															<Box
																sx={{
																	display: 'flex',
																	justifyContent: 'center',
																	pb: 3,
																	px: 1,
																}}
															>
																<Typography
																	variant="h6"
																	color="#383737"
																>
																	Chargement de contenu.
																</Typography>
															</Box>
														</TableCell>
													</TableRow>
												)}
												{!loading && applications.length === 0 && !error && (
													<TableRow>
														<TableCell colSpan={7}>
															<Box
																sx={{
																	display: 'flex',
																	justifyContent: 'center',
																	mb: 2,
																	mt: 2,
																}}
															>
																<StopCircle />
															</Box>
															<Box
																sx={{
																	display: 'flex',
																	justifyContent: 'center',
																}}
															>
																<Typography
																	variant="h6"
																	color="#383737"
																>
																	Aucune candidatures.
																</Typography>
															</Box>
														</TableCell>
													</TableRow>
												)}
											</TableBody>
										</Table>
										<Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
											<Link
												component={RouterLink}
												href="/dashboard/my_applications"
												sx={{
													mx: 1.5,
													display: 'flex',
													alignItems: 'center',
												}}
											>
												plus
											</Link>
										</Box>
									</TableContainer>
								</Paper>
								<Paper sx={{ p: 1 }} variant="outlined">
									<Stack
										sx={{
											p: 1,

											mt: 1,
											minHeight: 80,
										}}
									>
										<Typography>Les avis : </Typography>
										{reviews.length == 0 && (
											<Typography>Aucun avis </Typography>
										)}
										{reviews.map(review => (
											<Stack
												spacing={1}
												direction="row"
												display="flex"
												sx={{ my: 0.5 }}
											>
												<Stack
													spacing={1}
													sx={{ p: 1, flex: 0 }}
													alignItems="center"
												>
													<Avatar src={FILES_URL+review?.client?.avatar} />
													<Typography variant="caption">
														{review?.client?.company_name}
													</Typography>
												</Stack>
												<Stack sx={{ flex: 2 }}>
													<Typography
														variant="caption"
														color="text.secondary"
													>
														{moment(review?.created_at).format(
															'DD-MM-YYYY HH:MM'
														)}
													</Typography>
													<Typography>{review.comment}</Typography>
												</Stack>
											</Stack>
										))}
									</Stack>
								</Paper>
							</Stack>
						</Grid>
					</Grid>
				</Container>
				{selected && (
					<Show open={openShow} close={() => setOpenShow(false)} row={selected} />
				)}

				<Dialog
					fullWidth
					maxWidth="sm"
					open={openConfirmation}
					onClose={() => setOpenConfirmation(false)}
				>
					<DialogTitle>Êtes-vous sûr(e) ?</DialogTitle>
					<DialogContent>
						{selectedApplicationStatus == 'waiting' && (
							<>
								<Typography variant="body2" sx={{ color: 'red', p: 2 }}>
									Attention, vous allez annuler cette mission et vous ne pourrez
									pas postuler à nouveau.
								</Typography>
							</>
						)}
						{selectedApplicationStatus == 'accepted' && (
							<>
								<Typography variant="body2" sx={{ color: 'red', p: 2 }}>
									Attention, vous allez annuler cette mission et vous ne pourrez
									pas postuler à nouveau.
								</Typography>
								<Typography variant="caption" sx={{ p: 2 }}>
									La mission ne peut être annulée que 24 heures avant le début
									prévu.
								</Typography>
							</>
						)}
					</DialogContent>
					<DialogActions>
						<Button
							color="error"
							disabled={
								selectedApplicationStatus == 'accepted' &&
								isLessThan24Hours(selectedDate)
							}
							onClick={() => {
								sendCancel()
								setOpenConfirmation(false)
							}}
						>
							Oui
						</Button>
						<Button color="info" onClick={() => setOpenConfirmation(false)} autoFocus>
							Quitter
						</Button>
					</DialogActions>
				</Dialog>
				<Dialog
					fullWidth
					maxWidth="sm"
					open={cancelWait}
					onClose={() => setOpenCancelWait(false)}
				>
					<DialogTitle>Êtes-vous sûr(e) ?</DialogTitle>
					<DialogContent>
						<Typography variant="body1" sx={{ p: 2 }}>
							Êtes-vous sûr de vouloir vous désengager de votre candidature ?
						</Typography>
						<Typography variant="caption" sx={{ p: 2 }}>
							Vous ne pouvez vous désengager que 24 heures avant le début de la
							mission.
						</Typography>
					</DialogContent>
					<DialogActions>
						<Button
							color="error"
							disabled={
								selectedApplicationStatus == 'waiting' &&
								isLessThan24Hours(selectedDate)
							}
							onClick={() => {
								sendCancel()
								setOpenCancelWait(false)
							}}
						>
							Oui
						</Button>
						<Button color="info" onClick={() => setOpenCancelWait(false)} autoFocus>
							Quitter
						</Button>
					</DialogActions>
				</Dialog>
				<ToastContainer
					autoClose={3000}
					hideProgressBar={false}
					newestOnTop={false}
					closeOnClick
					rtl={false}
					pauseOnFocusLoss
					draggable
					pauseOnHover
				/>
			</Page>
		</>
	)
}
