import { Box, Typography, Button, Grid, Card, CardContent, CardMedia } from '@mui/material';
import { motion } from 'framer-motion';
import Logo from 'src/components/Logo';

const MotionBox = motion(Box);
const MotionButton = motion(Button);

export default function Main() {
	return (
		<Box sx={{ width: '100%', overflow: 'hidden', position: 'relative' }}>
			{/* Arrière-plan avec image et effet de flou */}
			<Box
				sx={{
					background: 'url(https://source.unsplash.com/1600x900/?hotel,restaurant) no-repeat center center fixed',
					backgroundSize: 'cover',
					height: '100vh',
					position: 'fixed',
					width: '100%',
					overflow: 'hidden',
					zIndex: -1,
					filter: 'blur(5px)', // Effet de flou sur l'image de fond
				}}
			/>
			{/* Conteneur principal */}
			<Box
				sx={{
					height: '100vh',
					display: 'flex',
					flexDirection: 'column',
					justifyContent: 'center',
					alignItems: 'center',
					textAlign: 'center',
					color: 'white',
					p: 4,
					backgroundColor: 'rgba(0, 0, 0, 0.6)', // Overlay sombre pour améliorer la lisibilité
				}}
			>
				<Logo sx={{ height: '100%', width: 250, mb: 2 }} />
				<Typography variant="h2" gutterBottom>
					Bienvenue chez Honest-Inn
				</Typography>
				<Typography variant="h6" gutterBottom>
					Connectons les meilleurs talents de l'hôtellerie et de la restauration.
				</Typography>
				<MotionButton
					variant="contained"
					color="primary"
					sx={{ mt: 2, borderRadius: '20px' }}
					whileHover={{ scale: 1.1 }}
					whileTap={{ scale: 0.9 }}
				>
					Découvrir nos offres
				</MotionButton>
			</Box>

			{/* Section À propos */}
			<Box
				sx={{
					textAlign: 'center',
					p: 4,
					mt: 10,
					backgroundColor: 'rgba(255, 255, 255, 0.9)',
					borderRadius: '20px',
					boxShadow: 3,
				}}
			>
				<Typography variant="h4" gutterBottom>
					À propos de nous
				</Typography>
				<Typography variant="body1" gutterBottom>
					Honest-Inn est un leader dans la mise en relation des candidats avec des opportunités dans le secteur de l'hôtellerie et de la restauration. Notre objectif est de simplifier le processus de recrutement et de rendre les opportunités accessibles à tous.
				</Typography>
				<MotionButton variant="outlined" color="primary" sx={{ mt: 2, borderRadius: '20px' }}>
					En savoir plus
				</MotionButton>
			</Box>

			{/* Section Statistiques */}
			<Box
				sx={{
					textAlign: 'center',
					p: 4,
					mt: 10,
					backgroundColor: 'rgba(255, 255, 255, 0.9)',
					borderRadius: '20px',
					boxShadow: 3,
				}}
			>
				<Typography variant="h4" gutterBottom>
					Nos statistiques
				</Typography>
				<Grid container spacing={4} justifyContent="center">
					<Grid item xs={12} sm={4}>
						<Typography variant="h2">1000+</Typography>
						<Typography variant="body1">Candidats placés</Typography>
					</Grid>
					<Grid item xs={12} sm={4}>
						<Typography variant="h2">300+</Typography>
						<Typography variant="body1">Partenaires d'affaires</Typography>
					</Grid>
					<Grid item xs={12} sm={4}>
						<Typography variant="h2">50+</Typography>
						<Typography variant="body1">Opportunités chaque semaine</Typography>
					</Grid>
				</Grid>
			</Box>

			{/* Section Témoignages */}
			<Box sx={{ mt: 10, p: 4 }}>
				<Typography variant="h4" textAlign="center" gutterBottom>
					Ce que disent nos utilisateurs
				</Typography>
				<Grid container spacing={4} justifyContent="center">
					<Grid item xs={12} sm={6} md={4}>
						<Card sx={{ borderRadius: '20px', boxShadow: 2 }}>
							<CardMedia
								component="img"
								height="140"
								image="https://via.placeholder.com/140"
								alt="Témoignage 1"
							/>
							<CardContent>
								<Typography variant="h6">Marie Dupont</Typography>
								<Typography variant="body2">
									"Honest-Inn m'a aidé à trouver un emploi dans un hôtel de premier plan. Leur service est incroyable !"
								</Typography>
							</CardContent>
						</Card>
					</Grid>
					<Grid item xs={12} sm={6} md={4}>
						<Card sx={{ borderRadius: '20px', boxShadow: 2 }}>
							<CardMedia
								component="img"
								height="140"
								image="https://via.placeholder.com/140"
								alt="Témoignage 2"
							/>
							<CardContent>
								<Typography variant="h6">Jean Martin</Typography>
								<Typography variant="body2">
									"Une expérience exceptionnelle, je recommande Honest-Inn à tous mes amis."
								</Typography>
							</CardContent>
						</Card>
					</Grid>
				</Grid>
			</Box>

			{/* Section Offres d'Emploi */}
			<Box sx={{ mt: 10, p: 4, textAlign: 'center' }}>
				<Typography variant="h4" gutterBottom>
					Nos offres d'emploi
				</Typography>
				<Grid container spacing={4} justifyContent="center">
					<Grid item xs={12} sm={6} md={4}>
						<Card sx={{ borderRadius: '20px', boxShadow: 2 }}>
							<CardMedia
								component="img"
								height="140"
								image="https://via.placeholder.com/140"
								alt="Offre d'emploi 1"
							/>
							<CardContent>
								<Typography variant="h6">Chef de Cuisine</Typography>
								<Typography variant="body2">
									Rejoignez notre équipe en tant que Chef de Cuisine dans un hôtel 5 étoiles.
								</Typography>
								<MotionButton
									variant="contained"
									color="primary"
									sx={{ mt: 2, borderRadius: '20px' }}
									whileHover={{ scale: 1.1 }}
									whileTap={{ scale: 0.9 }}
								>
									Candidater
								</MotionButton>
							</CardContent>
						</Card>
					</Grid>
					<Grid item xs={12} sm={6} md={4}>
						<Card sx={{ borderRadius: '20px', boxShadow: 2 }}>
							<CardMedia
								component="img"
								height="140"
								image="https://via.placeholder.com/140"
								alt="Offre d'emploi 2"
							/>
							<CardContent>
								<Typography variant="h6">Serveur(se)</Typography>
								<Typography variant="body2">
									Nous recherchons un serveur pour un restaurant branché en centre-ville.
								</Typography>
								<MotionButton
									variant="contained"
									color="primary"
									sx={{ mt: 2, borderRadius: '20px' }}
									whileHover={{ scale: 1.1 }}
									whileTap={{ scale: 0.9 }}
								>
									Candidater
								</MotionButton>
							</CardContent>
						</Card>
					</Grid>
				</Grid>
			</Box>
		</Box>
	);
}
