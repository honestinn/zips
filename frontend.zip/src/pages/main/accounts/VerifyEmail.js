import { Alert, Box, CircularProgress, Link, Stack, Typography } from '@mui/material'
import React, { useEffect } from 'react'
import { useState } from 'react'
import api from 'src/Api'
import { useSelector } from 'react-redux'
import { Navigate, useLocation } from 'react-router'
import RouterLink from 'src/hooks/RouterLink'

export default function VerifyEmail() {
	const location = useLocation()
	const queryParams = new URLSearchParams(location.search)
	const auth = useSelector(state => state.auth)
	const token = queryParams.get('token')
	const [loading, setLoading] = useState(false)
	const [status, setStatus] = useState('expired')
	const [cnxErr, setCnxErr] = useState(false)
	useEffect(() => {
		check()
	}, [])
	const check = () => {
		setLoading(true)
		api.post('/users/verify_email', { token })
			.then(res => {
				setStatus(res.data)
				setLoading(false)
			})
			.catch(err => {	
				alert(err)
				setCnxErr(true)
				setLoading(false)
			})
	}
	if (status == 'already_verified' || status == 'invalid_token')
		return <Navigate to="/404'" replace={true} />
	if (cnxErr)
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '80vh',
				}}
			>
				<Stack
					spacing={2}
					display={'flex'}
					justifyContent="center"
					direction="column"
					alignItems="center"
				>
					<Alert severity="error">probleme de connexion</Alert>
				</Stack>
			</Box>
		)
	return (
		<Box
			sx={{
				display: 'flex',
				justifyContent: 'center',
				alignItems: 'center',
				minHeight: '80vh',
			}}
		>
			<Stack
				spacing={2}
				display={'flex'}
				justifyContent="center"
				direction="column"
				alignItems="center"
			>
				{loading && (
					<>
						<CircularProgress />
						<Typography>Chargement</Typography>
					</>
				)}
				{status == 'expired_token' && (
					<>
						<Alert severity="error">
							<Stack direction="row" spacing={1}>
								<Typography>Ce lien a expiré</Typography>
								<Link
									variant="button"
									color="text.primary"
									component={RouterLink}
									href="/login"
									sx={{ mx: 1.5, display: 'flex', alignItems: 'center' }}
								>
									Se connecter
								</Link>
								<Link
									variant="button"
									color="text.primary"
									component={RouterLink}
									href="/"
									sx={{ mx: 1.5, display: 'flex', alignItems: 'center' }}
								>
									Acceuil
								</Link>
							</Stack>
						</Alert>
					</>
				)}
				{status == 'verified' && (
					<>
						<Alert severity="success">
							<Stack direction="row" spacing={1}>
								<Typography>
									Votre adresse e-mail a été vérifiée avec succès
								</Typography>
								<Link
									variant="button"
									color="text.primary"
									component={RouterLink}
									href="/login"
									sx={{ mx: 1.5, display: 'flex', alignItems: 'center' }}
								>
									Se connecter
								</Link>
								<Link
									variant="button"
									color="text.primary"
									component={RouterLink}
									href="/"
									sx={{ mx: 1.5, display: 'flex', alignItems: 'center' }}
								>
									Acceuil
								</Link>
							</Stack>
						</Alert>
					</>
				)}
			</Stack>
		</Box>
	)
}
