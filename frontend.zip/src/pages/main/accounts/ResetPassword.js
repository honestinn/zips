import {
	Alert,
	Box,
	Button,
	CircularProgress,
	Divider,
	IconButton,
	InputAdornment,
	Link,
	Paper,
	Stack,
	TextField,
	Typography,
} from '@mui/material'
import React, { useEffect } from 'react'
import { useState } from 'react'
import api from 'src/Api'
import { useSelector } from 'react-redux'
import { Navigate, useLocation, useNavigate } from 'react-router'
import RouterLink from 'src/hooks/RouterLink'
import { Send, Visibility, VisibilityOff } from '@mui/icons-material'
import { useFormik } from 'formik'
import * as Yup from 'yup'
import { ToastContainer, toast } from 'react-toastify'
import { jwtDecode } from 'jwt-decode'
import Logo from 'src/components/Logo'
export default function ResetPassword() {
	const location = useLocation()
	const queryParams = new URLSearchParams(location.search)
	const auth = useSelector(state => state.auth)
	const token = queryParams.get('token')
	const navigate = useNavigate()
	const [decoded, setDecoded] = useState(null)
	const [loading, setLoading] = useState(false)
	const [status, setStatus] = useState('expired')
	const [showPassword, setShowPassword] = useState(false)

	const [showPasswordC, setShowPasswordC] = useState(false)
	const [cnxErr, setCnxErr] = useState(false)
	useEffect(() => {
		try {
			const decoded = jwtDecode(token)
			setDecoded(decoded)
		} catch (error) {
			console.error('Error decoding token:', error.message)
		}
	}, [])

	const formik = useFormik({
		enableReinitialize: true,
		initialValues: {
			email: '',
		},
		validationSchema: Yup.object().shape({
			email: Yup.string()
				.email("Format d'email invalide")
				.required('Ce champ est obligatoire *'),
		}),
		onSubmit: async (values, helpers) => {
			try {
				send(values)
			} catch (err) {
				console.error(err)

				helpers.setStatus({ success: false })
				helpers.setErrors({ submit: err.message })
				helpers.setSubmitting(false)
			}
		},
	})
	const formikReset = useFormik({
		initialValues: {
			password: '',
			confirmPassword: '',
		},
		validationSchema: Yup.object({
			password: Yup.string()
				.min(
					8,
					'Le mot de passe doit contenir au moins 8 caractères, 1 chiffre, une lettre majuscule et un caractère spécial'
				)
				.matches(
					/[a-z]/,
					'Le mot de passe doit contenir au moins 8 caractères, 1 chiffre, une lettre majuscule et un caractère spécial'
				)
				.matches(
					/[A-Z]/,
					'Le mot de passe doit contenir au moins 8 caractères, 1 chiffre, une lettre majuscule et un caractère spécial'
				)
				.matches(
					/\d/,
					'Le mot de passe doit contenir au moins 8 caractères, 1 chiffre, une lettre majuscule et un caractère spécial'
				)
				.matches(
					/[!@#$%^&*(),.?":{}|<>]/,
					'Le mot de passe doit contenir au moins 8 caractères, 1 chiffre, une lettre majuscule et un caractère spécial'
				)
				.required(
					'Le mot de passe doit contenir au moins 8 caractères, 1 chiffre, une lettre majuscule et un caractère spécial'
				),
			confirmPassword: Yup.string()
				.oneOf([Yup.ref('password'), null], 'confirmation de mot de passe incorrecte')
				.required('Veuillez confirmer le mot de passe.'),
		}),
		onSubmit: values => {
			reset(values)
		},
	})

	const send = values => {
		// Headers
		setLoading(true)
		api.post('/users/send_reset_password_ink', { ...values })
			.then(res => {
				showSuccess(
					'Nous avons envoyé le lien de réinitialisation de mot de passe. Veuillez vérifier votre e-mail'
				)
			})
			.catch(err => {
				showError(
					"Quelque chose ne va pas , veuillez fournir l'adresse e-mail avec laquelle vous vous êtes inscrit(e)"
				)
			})
	}
	const reset = values => {
		// Headers
		setLoading(true)
		api.post('/users/reset_password', { ...values, token })
			.then(res => {
				showSuccess('Le mot de passe a été réinitialisé avec succès')
				navigate('/login')
			})
			.catch(err => {
				showError('Quelque chose ne va pas')
			})
	}
	const showError = msg => {
		toast.error(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}
	const showSuccess = msg => {
		toast.success(msg, {
			position: 'bottom-center',
			autoClose: 3000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
		})
	}

	return (
		<Box
			sx={{
				display: 'flex',
				justifyContent: 'center',
				alignItems: 'center',
				minHeight: '70vh',
			}}
		>
			{decoded == null && (
				<Paper variant="outlined" sx={{ minWidth: 700, maxWidth: 700, p: 2 }}>
					<form autoComplete="off" noValidate onSubmit={formik.handleSubmit}>
						<Stack spacing={2}>
							<Logo sx={{ height: '100%', width: 200, mb: 2 }} />
							<Divider />
							<Typography variant="h6">Réinitialisation de mot de passe</Typography>
							<Typography variant="body2">
								Les instructions pour réinitialiser votre mot de passe vous seront
								envoyées à l'adresse e-mail que vous avez utilisée lors de votre
								inscription.
							</Typography>
							<Stack>
								<TextField
									fullWidth
									autoComplete="email"
									type="text"
									name="email"
									label="Adresse mail"
									onChange={formik.handleChange}
									value={formik.values.email}
									error={Boolean(formik.touched.email && formik.errors.email)}
									helperText={formik.touched.email && formik.errors.email}
								/>
							</Stack>
							<Stack direction={'row'} justifyContent={'space-between'}>
								<Button
									sx={{ textTransform: 'none' }}
									to="/"
									size="medium"
									variant="text"
									component={RouterLink}
								>
									Accéder à la page d'accueil
								</Button>
								<Button
									startIcon={<Send />}
									size="medium"
									variant="contained"
									type="submit"
								>
									Envoyer
								</Button>
							</Stack>
						</Stack>
					</form>
				</Paper>
			)}
			{decoded && (
				<Paper variant="outlined" sx={{ minWidth: 700, maxWidth: 700, p: 2 }}>
					{decoded?.exp * 1000 > Date.now() ? (
						<form autoComplete="off" noValidate onSubmit={formikReset.handleSubmit}>
							<Stack spacing={2}>
								<Logo sx={{ height: '100%', width: 200, mb: 2 }} />
								<Divider />

								<Stack>
									<TextField
										fullWidth
										id="password"
										name="password"
										label="Nouveau mot de passe"
										type={showPassword ? 'text' : 'password'}
										InputProps={{
											endAdornment: (
												<InputAdornment position="end">
													<IconButton
														onClick={() =>
															setShowPassword(prev => !prev)
														}
														edge="end"
													>
														{showPassword ? (
															<VisibilityOff />
														) : (
															<Visibility />
														)}
													</IconButton>
												</InputAdornment>
											),
										}}
										value={formikReset.values.password}
										onChange={formikReset.handleChange}
										error={
											formikReset.touched.password &&
											Boolean(formikReset.errors.password)
										}
										helperText={
											formikReset.touched.password &&
											formikReset.errors.password
										}
										margin="normal"
									/>

									<TextField
										fullWidth
										id="confirmPassword"
										name="confirmPassword"
										label="Confirmez le mot de passe"
										type={showPasswordC ? 'text' : 'password'}
										InputProps={{
											endAdornment: (
												<InputAdornment position="end">
													<IconButton
														onClick={() =>
															setShowPasswordC(prev => !prev)
														}
														edge="end"
													>
														{showPasswordC ? (
															<VisibilityOff />
														) : (
															<Visibility />
														)}
													</IconButton>
												</InputAdornment>
											),
										}}
										value={formikReset.values.confirmPassword}
										onChange={formikReset.handleChange}
										error={
											formikReset.touched.confirmPassword &&
											Boolean(formikReset.errors.confirmPassword)
										}
										helperText={
											formikReset.touched.confirmPassword &&
											formikReset.errors.confirmPassword
										}
										margin="normal"
									/>
								</Stack>
								<Stack direction={'row'} justifyContent={'space-between'}>
									<Button
										sx={{ textTransform: 'none' }}
										to="/"
										size="medium"
										variant="text"
										component={RouterLink}
									>
										Accéder à la page d'accueil
									</Button>
									<Button
										startIcon={<Send />}
										size="medium"
										variant="contained"
										type="submit"
									>
										Envoyer
									</Button>
								</Stack>
							</Stack>
						</form>
					) : (
						<Box textAlign={'center'}>
							<Typography>Ce lien a déjà expiré. Veuillez réessayer</Typography>
							<Link variant="subtitle2" component={RouterLink} to="/login">
								réessayer
							</Link>
						</Box>
					)}
				</Paper>
			)}
			<ToastContainer
				autoClose={3000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
			/>
		</Box>
	)
}
