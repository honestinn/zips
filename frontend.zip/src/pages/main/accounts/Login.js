// material
import { styled } from '@mui/material/styles'

// components
import Page from 'src/components/Page'

import eyeFill from '@iconify/icons-eva/eye-fill'
import eyeOffFill from '@iconify/icons-eva/eye-off-fill'
import { Icon } from '@iconify/react'
import { LoadingButton } from '@mui/lab'
// material
import {
	Typography,
	Alert,
	Box,
	Container,
	IconButton,
	InputAdornment,
	Link,
	Stack,
	TextField,
} from '@mui/material'
import { useFormik } from 'formik'
import { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link as RouterLink, Navigate } from 'react-router-dom'
import * as Yup from 'yup'
import { login } from '../../../actions/auth'
import 'react-toastify/dist/ReactToastify.css'
import { t } from 'i18next'
import Logo from 'src/components/Logo'
// ----------------------------------------------------------------------

const RootStyle = styled(Page)(({ theme }) => ({
	[theme.breakpoints.up('md')]: {
		display: 'flex',
	},
}))

const ContentStyle = styled('div')(({ theme }) => ({
	maxWidth: 480,
	margin: 'auto',
	display: 'flex',
	minHeight: '80vh',
	flexDirection: 'column',
	justifyContent: 'center',
	padding: theme.spacing(1, 0),
}))

// ----------------------------------------------------------------------

export default function Login() {
	const [showPassword, setShowPassword] = useState(false)

	const auth = useSelector(state => state.auth)
	const errors = useSelector(state => state.errors)
	const isSubmitting = useSelector(state => state.loading.auth_submitting)
	const dispatch = useDispatch()

	const token = localStorage.getItem('token');
    if (token){
		window.location.replace('/dashboard');
	}

	const formik = useFormik({
		enableReinitialize: true,
		initialValues: {
			email: '',
			password: '',
		},
		validationSchema: Yup.object().shape({
			email: Yup.string()
				.email("Format d'email invalide")
				.required('Ce champ est obligatoire *'),
			password: Yup.string()
				.min(8, 'Le mot de passe doit contenir au moins')
				.required('Ce champ est obligatoire *'),
		}),
		onSubmit: async (values, helpers) => {
			try {
				dispatch(login(values.email, values.password))
			} catch (err) {
				console.error(err)

				helpers.setStatus({ success: false })
				helpers.setErrors({ submit: err.message })
				helpers.setSubmitting(false)
			}
		},
	})
	const handleShowPassword = () => {
		setShowPassword(show => !show)
	}
	useEffect(() => {
		return dispatch({ type: 'CLEAR_ERRORS' })
	}, [])
	if (auth.isAuthenticated) {
		localStorage.setItem('lastActivity', new Date().getTime());
		return <Navigate to="/dashboard" replace="true" />
	}

	return (
		<RootStyle title="Se connecter">
			<Container maxWidth="sm">
				<ContentStyle>
					<Box sx={{ px: 1 }}>
					<Box
						sx={{
							display: 'flex',
							flexDirection: 'column',
							alignItems: 'center', // Center horizontally
							justifyContent: 'center', // Center vertically if necessary
							mb: 5,
						}}
>
    <Logo sx={{ height: '100%', width: 200, mb: 2 }} />
    <Stack alignItems="center"> {/* Center text in the Stack */}
        <Typography variant="h6" gutterBottom>
            Se connecter à la plateforme
        </Typography>
        <Typography sx={{ color: 'text.secondary', textAlign: 'center' }}>
            Entrez vos coordonnées ci-dessous.
        </Typography>
    </Stack>
</Box>

						<>
							<form autoComplete="off" noValidate onSubmit={formik.handleSubmit}>
								<Stack spacing={3}>
									<TextField
										fullWidth
										autoComplete="email"
										type="text"
										name="email"
										label="Email"
										onChange={formik.handleChange}
										value={formik.values.email}
										error={Boolean(formik.touched.email && formik.errors.email)}
										helperText={formik.touched.email && formik.errors.email}
									/>

									<TextField
										fullWidth
										name="password"
										onChange={formik.handleChange}
										autoComplete="current-password"
										type={showPassword ? 'text' : 'password'}
										label="Mot de passe"
										value={formik.values.password}
										InputProps={{
											endAdornment: (
												<InputAdornment position="end">
													<IconButton
														onClick={handleShowPassword}
														edge="end"
													>
														<Icon
															icon={
																showPassword ? eyeFill : eyeOffFill
															}
														/>
													</IconButton>
												</InputAdornment>
											),
										}}
										error={Boolean(
											formik.touched.password && formik.errors.password
										)}
										helperText={
											formik.touched.password && formik.errors.password
										}
									/>
								</Stack>

								<Box justifyContent="flex-end" sx={{ display: 'flex', my: 2 }}>
									<Link
										component={RouterLink}
										variant="subtitle2"
										to="/reset_password"
									>
										Mot de passe oublié?
									</Link>
								</Box>

								<LoadingButton
									fullWidth
									sx={{ textTransform: 'none' }}
									size="large"
									type="submit"
									variant="contained"
									loading={isSubmitting}
								>
									Se connecter
								</LoadingButton>
							</form>
							{errors.msg && errors.msg.length > 0 && (
								<Alert sx={{ m: 2 }} severity="error">
									{errors.msg}
								</Alert>
							)}

							<Box sx={{ py: 2, display: 'flex' }}>
								Vous n'avez pas de compte ?&nbsp;
								<Link variant="subtitle2" component={RouterLink} to="/register">
									 S'inscrire.
								</Link>
							</Box>
						</>
					</Box>
				</ContentStyle>
			</Container>
		</RootStyle>
	)
}
