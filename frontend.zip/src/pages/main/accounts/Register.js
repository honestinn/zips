import { Grid, Typography, Box, Container, Button, Link } from '@mui/material'
import React, { useState } from 'react'

import RouterLink from 'src/hooks/RouterLink'

export default function Register() {
	return (
		<Grid container spacing={2} sx={{ mt: 5 }}>
			<Grid
				item
				xs={12}
				sm={12}
				md={6}
				lg={6}
				sx={{
					p: 2,
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					flexDirection: 'column',
					background: '#1E1E1D',
					minHeight: '100%',
				}}
			>
				<Box
					sx={{
						border: '1px solid #ccc',
						p: 4,
					}}
				>
					<Box sx={{ width: 300, height: 300 }}>
						<img
							src="/statics/undraw_product_tour_re_8bai.svg"
							style={{ maxHeight: '100%', maxWidth: '100%' }}
						/>
					</Box>
					<Link
						variant="button"
						color="text.primary"
						component={RouterLink}
						underline="none"
						href="/register/pro"
						sx={{ mx: 1.5, display: 'flex', alignItems: 'center' }}
					>
						<Button
							variant="outlined"
							color="secondary"
							sx={{ width: '100%', mb: 1, textTransform: 'none' }}
						>
							Je suis un établissement
						</Button>
					</Link>
					<Typography textAlign="center" variant="h6" color="secondary">
						Je suis à la recherche de candidats qualifiés pour des missions temporaires
						afin de renforcer notre équipe.
					</Typography>
				</Box>
			</Grid>
			<Grid
				item
				xs={12}
				sm={12}
				md={6}
				lg={6}
				sx={{
					p: 2,
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					flexDirection: 'column',
					background: '#FDA92D',
				}}
			>
				<Box
					sx={{
						border: '1px solid #1E1E1D',
						p: 4,
					}}
				>
					<Box sx={{ width: 300, height: 300 }}>
						<img
							src="/statics/undraw_subscriptions_re_k7jj.svg"
							style={{ maxHeight: '100%', maxWidth: '100%' }}
						/>
					</Box>
					<Link
						variant="button"
						color="text.primary"
						component={RouterLink}
						underline="none"
						href="/register/ext"
						sx={{ mx: 1.5, display: 'flex', alignItems: 'center' }}
					>
						<Button
							variant="outlined"
							color="info"
							sx={{ width: '100%', mb: 1, textTransform: 'none' }}
						>
							Je suis un collaborateur
						</Button>
					</Link>
					<Typography textAlign="center" variant="h6">
						Je souhaite entreprendre des missions en tant que professionnel indépendant.
					</Typography>
				</Box>
			</Grid>
		</Grid>
	)
}
