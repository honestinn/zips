import { Visibility, VisibilityOff } from '@mui/icons-material'
import { LoadingButton } from '@mui/lab'
import {
	Typography,
	Button,
	Box,
	Stack,
	TextField,
	Link,
	InputAdornment,
	IconButton,
	Alert,
	MenuItem,
	Select,
	FormHelperText,
	Paper,
	Dialog,
	DialogContent,
	DialogActions,
} from '@mui/material'

import { useFormik } from 'formik'

import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Navigate } from 'react-router'
import { countries } from 'src/_mock/_countries'
import { register } from 'src/actions/auth'

import RouterLink from 'src/hooks/RouterLink'
import * as Yup from 'yup'
import TermsOfUsePage from '../../TermsOfUsePage'
import PrivacyPolicyPage from '../../PrivacyPolicyPage'

import Logo from 'src/components/Logo'
export default function Register() {
	const [showPassword, setShowPassword] = useState(false)
	const [showPasswordC, setShowPasswordC] = useState(false)
	const [openTerms, setOpenTerms] = useState(false)
	const [openPolicy, setOpenPolicy] = useState(false)
	const [country, setCountry] = useState({ code: 'FR', label: 'France', phone: '33' })
	const auth = useSelector(state => state.auth)
	const errors = useSelector(state => state.errors)
	const isSubmitting = useSelector(state => state.loading.auth_submitting)
	const dispatch = useDispatch()
	const formik = useFormik({
		enableReinitialize: true,
		initialValues: {
			email: '',
			name: '',
			phone: '',
			password: '',
			confirm_password: '',
		},
		validationSchema: Yup.object().shape({
			name: Yup.string().required('Nom est obligatoire *'),
			password: Yup.string()
				.min(
					8,
					'Le mot de passe doit contenir au moins 8 caractères, 1 chiffre, une lettre majuscule et un caractère spécial'
				)
				.matches(
					/[a-z]/,
					'Le mot de passe doit contenir au moins 8 caractères, 1 chiffre, une lettre majuscule et un caractère spécial'
				)
				.matches(
					/[A-Z]/,
					'Le mot de passe doit contenir au moins 8 caractères, 1 chiffre, une lettre majuscule et un caractère spécial'
				)
				.matches(
					/\d/,
					'Le mot de passe doit contenir au moins 8 caractères, 1 chiffre, une lettre majuscule et un caractère spécial'
				)
				.matches(
					/[!@#$%^&*(),.?":{}|<>]/,
					'Le mot de passe doit contenir au moins 8 caractères, 1 chiffre, une lettre majuscule et un caractère spécial'
				)
				.required(
					'Le mot de passe doit contenir au moins 8 caractères, 1 chiffre, une lettre majuscule et un caractère spécial'
				),
			phone: Yup.string()
				.matches(/^[0-9]\d{8}$/, "Le numéro de téléphone n'est pas valide")
				.required('Téléphone est obligatoire *'),

			confirm_password: Yup.string()
				.required('La confirmation du mot de passe est obligatoire *')
				.oneOf(
					[Yup.ref('password'), null],
					'La confirmation du mot de passe est incorrecte'
				),
			email: Yup.string()
				.email("Format d'email invalide")
				.required("l'email est obligatoire *"),
		}),
		onSubmit: async (values, helpers) => {
			try {
				dispatch(
					register({
						...values,
						type: 1,
						phone: '+' + country.phone + ' ' + values.phone,
						country,
					})
				)
			} catch (err) {
				console.error(err)
				helpers.setStatus({ success: false })
				helpers.setErrors({ submit: err.message })
				helpers.setSubmitting(false)
			}
		},
	})
	useEffect(() => {
		return dispatch({ type: 'CLEAR_ERRORS' })
	}, [])

	if (auth.user && auth.isAuthenticated) return <Navigate to="/dashboard/" />
	else
		return (
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'center',
					alignItems: 'center',
					minHeight: '100vh',
				}}
			>
				<form autoComplete="off" noValidate onSubmit={formik.handleSubmit}>
					<Paper variant="outlined">
						<Stack spacing={2} sx={{ p: 2, m: 2 }}>
							<Box 
							    sx={{
									display: 'flex',
									flexDirection: 'column',
									alignItems: 'center', // Center horizontally
									justifyContent: 'center', // Center vertically if necessary
									mb: 5,
								}}
							>
								<Logo sx={{ height: '100%', width: 200, mb: 2 }} />
							</Box>
							
							<Typography variant="body2">
								Pour créer un compte sur Honest-Inn, il vous suffit de compléter les
								champs obligatoires.
							</Typography>

							<Stack direction="row" spacing={0.5}>
								<Typography variant="body2">
									vous avez déjà un compte? Connectez vous ici
								</Typography>

								<Link component={RouterLink} href={'/login'} variant="subtitle2">
									Se connecter
								</Link>
							</Stack>

							<TextField
								size="medium"
								fullWidth
								autoComplete="name"
								type="text"
								name="name"
								label="Nom de la société"
								onChange={formik.handleChange}
								value={formik.values.name}
								error={Boolean(formik.touched.name && formik.errors.name)}
								helperText={formik.touched.name && formik.errors.name}
							/>
							<TextField
								size="medium"
								fullWidth
								autoComplete="email"
								type="text"
								name="email"
								label="Email"
								onChange={formik.handleChange}
								value={formik.values.email}
								error={Boolean(formik.touched.email && formik.errors.email)}
								helperText={formik.touched.email && formik.errors.email}
							/>

							<Stack direction="row" spacing={1}>
								<Select
									sx={{ width: 110, display: 'inline-block' }}
									size="medium"
									value={country.code}
									autoWidth
									onChange={e =>
										setCountry(
											countries.find(
												element => element.code == e.target.value
											)
										)
									}
								>
									{countries.map(element => (
										<MenuItem value={element.code}>
											<img
												loading="lazy"
												width="20"
												src={`https://flagcdn.com/w20/${element?.code.toLowerCase()}.png`}
												srcSet={`https://flagcdn.com/w40/${element?.code.toLowerCase()}.png 2x`}
												alt=""
												style={{ display: 'inline' }}
											/>
											{' ' + element?.code.toUpperCase()}
										</MenuItem>
									))}
								</Select>
								<TextField
									sx={{ display: 'inline-block' }}
									size="medium"
									type="text"
									fullWidth
									name="phone"
									label="Téléphone"
									onChange={formik.handleChange}
									value={formik.values.phone}
									error={Boolean(formik.touched.phone && formik.errors.phone)}
									InputProps={{
										startAdornment: (
											<InputAdornment position="start">
												<Typography>
													+{country?.phone.toLowerCase()}
												</Typography>
											</InputAdornment>
										),
									}}
								/>
							</Stack>
							<FormHelperText
								error={Boolean(formik.touched.phone && formik.errors.phone)}
							>
								{formik.touched.phone && formik.errors.phone}
							</FormHelperText>
							<TextField
								size="medium"
								fullWidth
								name="password"
								onChange={formik.handleChange}
								autoComplete="current-password"
								type={showPassword ? 'text' : 'password'}
								label="Mot de passe"
								InputProps={{
									endAdornment: (
										<InputAdornment position="end">
											<IconButton
												onClick={() => setShowPassword(prev => !prev)}
												edge="end"
											>
												{showPassword ? <VisibilityOff /> : <Visibility />}
											</IconButton>
										</InputAdornment>
									),
								}}
								value={formik.values.password}
								error={Boolean(formik.touched.password && formik.errors.password)}
								// helperText={formik.touched.password && formik.errors.password}
							/>
							<Typography variant="caption">
								Le mot de passe doit contenir au moins : 8 caractères, un chiffre,
								une lettre majuscule ,un caractère spécial.
							</Typography>
							<TextField
								size="medium"
								fullWidth
								name="confirm_password"
								onChange={formik.handleChange}
								autoComplete="current-password"
								type={showPasswordC ? 'text' : 'password'}
								label="Confirmation Mot de passe"
								onPaste={(e) => e.preventDefault()}
								value={formik.values.confirm_password}
								InputProps={{
									endAdornment: (
										<InputAdornment position="end">
											<IconButton
												onClick={() => setShowPasswordC(prev => !prev)}
												edge="end"
											>
												{showPasswordC ? <VisibilityOff /> : <Visibility />}
											</IconButton>
										</InputAdornment>
									),
								}}
								error={Boolean(
									formik.touched.confirm_password &&
										formik.errors.confirm_password
								)}
								helperText={
									formik.touched.confirm_password &&
									formik.errors.confirm_password
								}
							/>

							<Typography
								component="div"
								sx={{
									color: 'text.secondary',
									mt: 2.5,
									typography: 'caption',
									textAlign: 'center',
								}}
							>
								{"En m'inscrivant, j'accepte les "}
								<Link
									sx={{ cursor: 'pointer' }}
									onClick={() => setOpenTerms(true)}
									underline="always"
									color="text.primary"
								>
									Conditions d'utilisation
								</Link>
								{' et la '}
								<Link
									sx={{ cursor: 'pointer' }}
									onClick={() => setOpenPolicy(true)}
									underline="always"
									color="text.primary"
								>
									Politique de confidentialité
								</Link>
								.
							</Typography>

							{errors.msg && errors.msg.length > 0 && (
								<Alert sx={{ m: 2 }} severity="error">
									{errors.msg}
								</Alert>
							)}
							<LoadingButton
								fullWidth
								size="large"
								type="submit"
								variant="contained"
								loading={isSubmitting}
							>
								Continuer
							</LoadingButton>
						</Stack>
					</Paper>
				</form>
				<Dialog open={openTerms} onClose={() => setOpenTerms(false)} maxWidth="md">
					<DialogContent>
						<TermsOfUsePage />
					</DialogContent>
					<DialogActions>
						<Button onClick={() => setOpenTerms(false)}>Close</Button>
					</DialogActions>
				</Dialog>
				<Dialog open={openPolicy} onClose={() => setOpenPolicy(false)} maxWidth="md">
					<DialogContent>
						<PrivacyPolicyPage />
					</DialogContent>
					<DialogActions>
						<Button onClick={() => setOpenPolicy(false)}>Close</Button>
					</DialogActions>
				</Dialog>
			</Box>
		)
}
