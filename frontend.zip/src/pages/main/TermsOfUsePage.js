import React from 'react'
import { Typography, Container, Paper } from '@mui/material'

const TermsOfUsePage = () => {
	return (
		<>
			<Paper variant="outlined" sx={{ padding: 2, marginTop: 2 }}>
				<Typography variant="h5" gutterBottom>
					Conditions d'utilisation
				</Typography>
				<Typography variant="body2" paragraph>
					Bienvenue sur notre site web. Si vous continuez à naviguer et à utiliser ce
					site, vous acceptez de respecter et d'être lié par les conditions d'utilisation
					suivantes, qui, avec notre politique de confidentialité, régissent la relation
					de nom de votre entreprise avec vous en ce qui concerne ce site. Si vous n'êtes
					pas d'accord avec l'une de ces conditions, veuillez ne pas utiliser notre site
					web.
				</Typography>
				<Typography variant="body2" paragraph>
					Le terme "Nom de votre entreprise" ou "nous" ou "nous" fait référence au
					propriétaire du site web. Le terme "vous" désigne l'utilisateur ou le spectateur
					de notre site web.
				</Typography>
				<Typography variant="body2" paragraph>
					L'utilisation de ce site web est soumise aux conditions d'utilisation suivantes:
				</Typography>

				<Typography variant="body2" paragraph>
					- Le contenu des pages de ce site web est fourni à titre informatif uniquement
					et est sujet à changement sans préavis.
				</Typography>

				<Typography variant="body2" paragraph>
					- Ni nous ni aucun tiers ne fournissons aucune garantie quant à l'exactitude,
					l'exhaustivité, l'actualité ou la pertinence des informations et du matériel
					trouvés ou offerts sur ce site pour un usage particulier. Vous reconnaissez que
					de telles informations et matériaux peuvent contenir des inexactitudes ou des
					erreurs et nous excluons expressément toute responsabilité pour de telles
					inexactitudes ou erreurs dans toute la mesure permise par la loi.
				</Typography>

				<Typography variant="body2" paragraph>
					- Votre utilisation de toute information ou matériel sur ce site web est
					entièrement à vos risques et périls, pour lesquels nous ne serons pas
					responsables. Il est de votre responsabilité de vous assurer que tous les
					produits, services ou informations disponibles sur ce site répondent à vos
					besoins spécifiques.
				</Typography>

				{/* Add more terms and conditions here */}
			</Paper>
		</>
	)
}

export default TermsOfUsePage
