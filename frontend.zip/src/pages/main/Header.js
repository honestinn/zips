import {
	AppBar,
	Box,
	Button,
	Link,
	Toolbar,
	Typography,
	useMediaQuery,
	useTheme,
} from '@mui/material'
import RouterLink from 'src/hooks/RouterLink'

export default function Header() {
	const theme = useTheme()
	const isSmallScreen = useMediaQuery(theme.breakpoints.down('sm'))
	const isMediumScreen = useMediaQuery(theme.breakpoints.between('sm', 'md'))
	const isDesktop = useMediaQuery(theme.breakpoints.up('md'))
	return (
		<>
			<AppBar
				position="static"
				color="default"
				elevation={0}
				sx={{ borderBottom: theme => `1px solid ${theme.palette.divider}`, mb: 2 }}
			>
				<Toolbar sx={{ flexWrap: 'wrap' }}>
					<Typography variant="h6" color="inherit" noWrap sx={{ flexGrow: 1 }}>
						<Link component={RouterLink} href={'/'}>
							<Box
								component="img"
								src="/statics/logo.png"
								sx={
									isSmallScreen || isMediumScreen
										? { width: 80, height: 50, cursor: 'pointer' }
										: { width: 80, height: 60, cursor: 'pointer' }
								}
							/>
						</Link>
					</Typography>
					<Link
						variant="button"
						color="text.primary"
						component={RouterLink}
						underline="none"
						href="/login"
						sx={{ mx: 1.5, display: 'flex', alignItems: 'center' }}
					>
						<Button color="info" size="large" sx={{ mx: 1, textTransform: 'none' }}>
							ٍSe connecter
						</Button>
					</Link>

					<Link
						variant="button"
						color="text.primary"
						component={RouterLink}
						underline="none"
						href="/register"
						sx={{ mx: 1.5, display: 'flex', alignItems: 'center' }}
					>
						<Button size="large" variant="outlined">
							S'inscrire
						</Button>
					</Link>
				</Toolbar>
			</AppBar>
		</>
	)
}
