import Page from 'src/components/Page'
import Footer from './Footer'
import Header from './Header'
import { Container } from '@mui/material'

export default function HomeLayout({ children }) {
	return (
		<Page title="Accueil">
			<Header />
			<Container disableGutters maxWidth="lg" component="main" sx={{ minHeight: '90vh' }}>
				{children}
			</Container>
			<Footer />
		</Page>
	)
}
