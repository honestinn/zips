import React from 'react'
import { Typography, Container, Paper } from '@mui/material'

const PrivacyPolicyPage = () => {
	return (
		<Paper variant="outlined" sx={{ padding: 2, marginTop: 2 }}>
			<Typography variant="h5" gutterBottom>
				Politique de confidentialité
			</Typography>
			<Typography variant="body2" paragraph>
				Votre vie privée est importante pour nous. Il est de notre politique de respecter
				votre vie privée concernant les informations que nous pouvons collecter sur notre
				site Web, et les autres sites que nous possédons et exploitons.
			</Typography>
			<Typography variant="body2" paragraph>
				Nous ne demandons des informations personnelles que lorsque nous en avons vraiment
				besoin pour vous fournir un service. Nous collectons les informations par des moyens
				justes et légaux, avec votre connaissance et votre consentement. Nous indiquons
				également pourquoi nous collectons et comment elles sont utilisées.
			</Typography>
			<Typography variant="body2" paragraph>
				Nous ne conservons les informations collectées que le temps nécessaire pour fournir
				le service demandé. Ce que nous stockons, nous le protégeons dans des cadres
				commerciaux acceptables pour prévenir les pertes et le vol, ainsi que l'accès, la
				divulgation, la copie, l'utilisation ou la modification non autorisés.
			</Typography>
		</Paper>
	)
}

export default PrivacyPolicyPage
