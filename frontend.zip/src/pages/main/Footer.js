import { alpha } from '@mui/material/styles'
import Box from '@mui/material/Box'
import Link from '@mui/material/Link'
import Stack from '@mui/material/Stack'
import Divider from '@mui/material/Divider'
import Container from '@mui/material/Container'
import IconButton from '@mui/material/IconButton'
import Typography from '@mui/material/Typography'
import { Grid } from '@mui/material'
import { useTheme } from '@mui/material/styles'
import RouterLink from 'src/hooks/RouterLink'
import Logo from 'src/components/Logo'
import Iconify from 'src/components/Iconify'
import { useHref } from 'react-router'

const year = new Date().getFullYear()
const LINKS = [
  {
    headline: 'HONEST-INN',
    children: [
      { name: 'À Propos', href: '#' },
      { name: 'Contactez-nous', href: '#' },
      { name: 'FAQs', href: '#' },
    ],
  },
  {
    headline: 'LÉGAL',
    children: [
      { name: 'Politiques de confidentialité', href: '#' },
      { name: 'Mentions légales', href: '#' },
      { name: 'CGV', href: '#' },
    ],
  },
  {
    headline: 'CONTACT',
    children: [
      { name: '01 83 75 63 26', href: '#' },
      { name: 'contact@honest-inn.com', href: '#' },
    ],
  },
]

export default function Footer() {
  const theme = useTheme()

  return (
    <Box
      component="footer"
      sx={{
        mt: 1,
        position: 'relative',
        bgcolor: 'background.paper',
        borderTop: `1px solid ${theme.palette.divider}`,
        boxShadow: `0px -4px 12px ${alpha(theme.palette.text.primary, 0.1)}`,
      }}
    >
      <Divider sx={{ opacity: 0.2 }} />

      <Container
        sx={{
          pt: { xs: 5, sm: 8, md: 10 },
          pb: { xs: 5, sm: 8, md: 6 },
          textAlign: { xs: 'center', md: 'unset' },
        }}
      >
        <Logo sx={{ mb: 3, maxWidth: '150px' }} />

        <Grid container justifyContent="space-between" spacing={4}>
          <Grid item xs={12} md={3}>
            <Typography
              variant="body2"
              sx={{
                maxWidth: 270,
                mx: { xs: 'auto', md: 'unset' },
                color: 'text.secondary',
                fontSize: { xs: '0.75rem', sm: '0.875rem' }, // Réduit la taille
              }}
            >
              HONEST-INN - Votre source fiable pour l'hôtellerie et la restauration.
            </Typography>

            <Stack
              direction="row"
              justifyContent={{ xs: 'center', md: 'flex-start' }}
              sx={{
                mt: 3,
                mb: { xs: 5, md: 0 },
              }}
            >
              {/* Social Icons with Hover Animations */}
              <IconButton
			  onClick={() => window.open('https://www.facebook.com/p/Honest-Inn-100076855702366/', '_blank')}
                sx={{
                  '&:hover': {
                    bgcolor: alpha(theme.palette.primary.main, 0.1),
                    transform: 'scale(1.2)',
                    transition: 'transform 0.3s ease, background-color 0.3s ease',
                  },
                  mr: 2,
                }}
              >
                <Iconify icon="eva:facebook-fill" width={24} height={24} />
              </IconButton>
              <IconButton
			  onClick={() => window.location.href = ''}
                sx={{
                  '&:hover': {
                    bgcolor: alpha(theme.palette.primary.main, 0.1),
                    transform: 'scale(1.2)',
                    transition: 'transform 0.3s ease, background-color 0.3s ease',
                  },
                  mr: 2,
                }}
              >
                <Iconify icon="eva:twitter-fill" width={24} height={24} />
				
              </IconButton>
              <IconButton
			  onClick={() => window.open('https://www.linkedin.com/company/honest-inn/', '_blank')}
                sx={{
                  '&:hover': {
                    bgcolor: alpha(theme.palette.primary.main, 0.1),
                    transform: 'scale(1.2)',
                    transition: 'transform 0.3s ease, background-color 0.3s ease',
                  },
                }}
              >
                <Iconify icon="eva:linkedin-fill" width={24} height={24} />
              </IconButton>
            </Stack>
          </Grid>

          <Grid item xs={12} md={6}>
            <Stack spacing={4} direction={{ xs: 'column', md: 'row' }}>
              {LINKS.map(list => (
                <Stack
                  key={list.headline}
                  spacing={2}
                  alignItems={{ xs: 'center', md: 'flex-start' }}
                  sx={{ width: 1 }}
                >
                  <Typography
                    component="div"
                    variant="overline"
                    sx={{
                      fontWeight: 'bold',
                      color: 'text.primary',
                      fontSize: { xs: '0.875rem', sm: '1rem' }, // Réduit la taille
                    }}
                  >
                    {list.headline}
                  </Typography>
                  {list.children.map(link => (
                    <Link
                      key={link.name}
                      component={RouterLink}
                      href={link.href}
                      color="inherit"
                      variant="body2"
                      sx={{
                        '&:hover': {
                          color: theme.palette.primary.main,
                          textDecoration: 'underline',
                          transform: 'scale(1.05)',
                          transition: 'all 0.3s ease',
                        },
                        fontSize: { xs: '0.75rem', sm: '0.875rem' }, // Réduit la taille
                      }}
                    >
                      {link.name}
                    </Link>
                  ))}
                </Stack>
              ))}
            </Stack>
          </Grid>
        </Grid>

        <Divider sx={{ opacity: 0.2, my: 4 }} />

        <Typography
          variant="body2"
          sx={{
            mt: 5,
            color: 'text.secondary',
            fontSize: { xs: '0.75rem', sm: '0.875rem' }, // Réduit la taille
          }}
        >
          © {year}. Tous droits réservés.
        </Typography>
      </Container>
    </Box>
  )
}
