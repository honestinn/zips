import { Link as RouterLink } from 'react-router-dom';
// material
import { styled } from '@mui/material/styles';
import { Box, Link, Container, Typography } from '@mui/material';
// layouts
// components
import Page from '../components/Page';
import { RegisterForm } from '../components/authentication/register';
import Logo from 'src/components/Logo';

// ----------------------------------------------------------------------

const RootStyle = styled(Page)(({ theme }) => ({
  [theme.breakpoints.up('md')]: {
    display: 'flex'
  }
}));


const ContentStyle = styled('div')(({ theme }) => ({
  maxWidth: 700,
  margin: 'auto',
  display: 'flex',
  minHeight: '100vh',
  flexDirection: 'column',
  justifyContent: 'center',
  padding: theme.spacing(12, 0)
}));

// ----------------------------------------------------------------------

export default function Register() {
  return (
    <RootStyle title="S'inscrire | FULLLOYAL">
      <Container>
        <ContentStyle>
          <Box sx={{ boxShadow: 4, px: 1, py: 3 }}>
            <Logo sx={{ mb: 4 }} />
            <Typography variant="h4" gutterBottom>
              S'inscrire au plateforme.
            </Typography>
            <Typography sx={{ color: 'text.secondary', mb: 5 }}>
              Bénéficier de FULLLOYAL ERP
            </Typography>

            <RegisterForm />

          </Box>




        </ContentStyle>
      </Container>
    </RootStyle>
  );
}
