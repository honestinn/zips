import { m } from 'framer-motion'
import { Link as RouterLink } from 'react-router-dom'
// @mui
import { styled } from '@mui/material/styles'
import { Box, Button, Typography, Container } from '@mui/material'
// components
import Page from '../components/Page'
import { MotionContainer, varBounce } from '../components/animate'
// assets

// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
	display: 'flex',
	minHeight: '100%',
	alignItems: 'center',
	paddingTop: theme.spacing(15),
	paddingBottom: theme.spacing(10),
}))

// Animation config
const svgMotion = {
	animate: {
		scale: [1, 1.05, 1], // Zoom in to 1.2x and back to original size
		transition: {
			duration: 2,  // 2 seconds for one loop
			repeat: Infinity, // Repeat infinitely
			ease: 'easeInOut', // Smooth transition
		},
	},
}

// ----------------------------------------------------------------------

export default function Page404() {
	return (
		<Page title="404 Page non trouvée" sx={{ height: 1 }}>
			<RootStyle>
				<Container component={MotionContainer}>
					<Box sx={{ maxWidth: 480, margin: 'auto', textAlign: 'center' }}>
						{/* SVG with animation */}
						<m.div {...svgMotion}>
							<img
								src="/statics/undraw_page_not_found_re_e9o6.svg"
								alt="Page non trouvée"
								style={{ width: '100%', marginBottom: '20px' }}
							/>
						</m.div>

						<m.div variants={varBounce().in}>
							<Typography variant="h3" paragraph>
								Désolé, page introuvable !
							</Typography>
						</m.div>
						<Typography sx={{ color: 'text.secondary' }}>
							Nous n'avons pas pu trouver la page que vous cherchez. Peut-être que
							vous avez mal saisi l'URL ? Assurez-vous de vérifier l'orthographe.
						</Typography>

						<m.div variants={varBounce().in}></m.div>

						<Box sx={{ mt: 5 }}>
							<Button to="/" size="large" variant="contained" component={RouterLink}>
								Retour à l'accueil
							</Button>
						</Box>
					</Box>
				</Container>
			</RootStyle>
		</Page>
	)
}
