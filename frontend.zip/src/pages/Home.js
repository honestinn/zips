import { m } from 'framer-motion'
import { Link as RouterLink } from 'react-router-dom'
// @mui
import { styled } from '@mui/material/styles'
import { Box, Button, Typography, Container } from '@mui/material'
// components
import Page from '../components/Page'
import { MotionContainer, varBounce } from '../components/animate'
// assets
import { PageNotFoundIllustration } from '../assets'
import { useSelector } from 'react-redux'

// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
	display: 'flex',
	minHeight: '100%',
	alignItems: 'center',
	paddingTop: theme.spacing(15),
	paddingBottom: theme.spacing(10),
}))

// ----------------------------------------------------------------------

export default function Home() {
	const auth = useSelector(state => state.auth)
	return (
		<Page title="Accueil" sx={{ height: 1 }}>
			<RootStyle>
				<Container component={MotionContainer}>
					<Box sx={{ px: 10, margin: 'auto' }}>
						<m.div variants={varBounce().in}>
							<Typography variant="h3" paragraph>
								Bienvenue , {auth.user.name}
							</Typography>
						</m.div>
						{auth.user.role == 0 && (
							<Typography sx={{ color: 'text.secondary' }}></Typography>
						)}
						{auth.user.role != 0 && (
							<Typography sx={{ color: 'text.secondary' }}></Typography>
						)}
						<Typography variant="h5" paragraph>
							Honest-inn.
						</Typography>
					</Box>
				</Container>
			</RootStyle>
		</Page>
	)
}
