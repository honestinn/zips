import { jsPDF } from 'jspdf'
import 'jspdf-autotable'
import moment from 'moment'
// import font from './decodeFont'

var writtenNumber = require('written-number')

function somme(data) {
	var someQte = 0
	var someColis = 0
	var someArticles = data.articles.length
	for (var i = 0; i < data.articles.length; i++) {
		someQte = data.articles[i].quantite + someQte
		someColis = Math.floor(data.articles[i].quantite / data.articles[i].article.nuc) + someColis
	}
	return {
		someQte: someQte,
		someColis: someColis,
		someArticles: someArticles,
	}
}
function minToHMS(minutes) {
	//console.log(minutes)
	const hours = Math.floor(minutes / 60)
	const remainingMinutes = minutes % 60

	const formattedTime = `${String(hours).padStart(2, '0')} h :${String(remainingMinutes).padStart(
		2,
		'0'
	)} min`

	return formattedTime
}

export function print(data) {
	var doc = new jsPDF()
	let img = new Image()
	img.src = '/statics/logo.png'
	doc.addImage(img, 'png', 90, 10, 30, 25)

	var centeredText = function (text, y) {
		var textWidth =
			(doc.getStringUnitWidth(text) * doc.internal.getFontSize()) / doc.internal.scaleFactor
		var textOffset = (doc.internal.pageSize.width - textWidth) / 2
		doc.text(textOffset, y, text)
	}
	// doc.addFileToVFS('Cairo-Regular-normal.ttf', font)
	// doc.addFont('Cairo-Regular-normal.ttf', 'Cairo-Regular', 'normal')

	doc.setFont(undefined, 'normal')
	doc.setTextColor(0, 0, 0)
	doc.setFontSize(12)

	centeredText('Marie Dupont 35 Rue de la Paix 75001 Paris France', 40)
	centeredText('contact@honest-inn.com | +33 745 439 454| +33 745 439 454', 46)
	centeredText('www.honest-inn.com', 52)

	doc.setFontSize(12)
	doc.setFont(undefined, 'bold')
	centeredText(' Chez Honest-Inn, nous voulons valoriser ', 64)
	centeredText('les métiers opérationnels de l’hôtellerie', 70)
	doc.setFont(undefined, 'normal')

	doc.setFontSize(14)
	doc.setFont(undefined, 'bold')

	var text = 'Facture N° ' + new Date(data?.created_at).getTime()
	var textWidth = doc.getTextWidth(text)
	var textHeight = doc.getTextDimensions(text).h
	var textOffset = (doc.internal.pageSize.width - textWidth) / 2

	doc.setFillColor(189, 183, 102)

	doc.rect(textOffset - 5, 74, textWidth + 10, textHeight + 4, 'F')
	doc.text(textOffset, 80, text)
	doc.setFont(undefined, 'bold')

	doc.autoTable({
		margin: { right: 10, top: 90 },
		columnStyles: { 0: { fontStyle: 'bold', cellWidth: 35 } },
		theme: 'plain',

		body: [
			['Collaborateur', data?.user?.name],
			['N° Téléphone', data?.user?.phone],
			['E-mail', data?.user?.email],
		],
	})
	doc.autoTable({
		margin: { right: 10, top: 120 },
		columnStyles: { 0: { fontStyle: 'bold', cellWidth: 45 } },
		theme: 'grid',

		body: [
			['Employeure', data?.client?.name],
			[
				'Titre du mission ',
				data?.mission.job.subcategory.name + ' - ' + data?.mission.job.name,
			],
			['Addresse', data?.mission?.address],
			[
				'Duree ',
				'De ' +
					moment(data?.mission?.start_date).format('DD-MM-YYYY HH:mm') +
					' À ' +
					moment(data?.mission?.end_date).format('DD-MM-YYYY HH:mm'),
			],
			['Tarif /Heure ', data?.mission?.hour_salary + ' €'],
			['NB Total des heures', minToHMS(data?.nb_hours) || 0],
			['Total HT', data?.total.toFixed(2) + ' €'],
			['TVA', data?.tva * 100 + '%'],
			[
				'Total TTC',
				{
					content: Number(data?.ttc).toFixed(2) + '  €',
					styles: { fontStyle: 'bold' },
				},
			],
			// ...
		],
	})

	// var centimsNum = Math.ceil((((total * 100) / 100).toFixed(2) - Math.floor(total)) * 100)

	// var centims =
	// 	centimsNum == 0
	// 		? ''
	// 		: ' ET ' + writtenNumber(centimsNum, { lang: 'fr' }).toUpperCase() + ' CENTIM'

	// doc.setFont(undefined, 'normal')
	// doc.setFontSize(12)
	// doc.autoTable({
	// 	margin: { right: 10, top: 170 },
	// 	columnStyles: { 0: { halign: 'center' } },
	// 	bodyStyles: { font: 'Cairo-Regular', lineWidth: 0 },
	// 	theme: 'plain',
	// 	body: [
	// 		[
	// 			'LA PRÉSENTE DEVIS ARRETÉE À LA SOMME DE : ' +
	// 				writtenNumber(Math.floor(total), { lang: 'fr' }).toUpperCase() +
	// 				' DINARS ALGERIEN' +
	// 				centims,
	// 		],
	// 	],
	// })

	// doc.setFontSize(18)
	// centeredText('Moyens de paiement', 220)

	// doc.setDrawColor(0, 0, 0)

	// doc.setLineWidth(0.3)
	// doc.setLineDash([1.8, 1], 0)
	// doc.line(10, 224, 196, 224)

	// doc.setFontSize(12)
	// centeredText('  Virement / Versement CCP: 12581906 Clé 25 au Nom de DRISSI FATEH', 230)
	// doc.line(10, 234, 196, 234)

	// centeredText('BaridiMob RIP: 00799999001258190601', 240)
	// doc.line(10, 244, 196, 244)

	// centeredText('Virement / Versement Bancaire :', 250)
	// centeredText("BANQUE EXTERIEURE D'ALGERIE - AGONCE M'SILA 047", 256)
	// centeredText('MR. DRISSI FATEH B HOCINE', 262)
	// centeredText('00200047047220080516', 268)
	// doc.line(10, 270, 196, 272)
	// centeredText(
	// 	"Espèces : Cité EL-MOKRANI rue ICHBILIA, Face à la Fac, Local N° 01 M'Sila, Algérie",
	// 	278
	// )
	// doc.line(10, 282, 196, 282)

	doc.save('facture.pdf')
}
