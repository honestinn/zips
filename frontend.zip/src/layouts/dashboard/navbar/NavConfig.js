import { Home } from 'react-feather'

import {
	AccountBox,
	AccountBoxOutlined,
	Settings,
	Badge,
	Assignment,
	RequestQuote,
	AdminPanelSettings,
	CancelScheduleSend,
	Dashboard
} from '@mui/icons-material'

// ----------------------------------------------------------------------

const sidebarConfig = [
	// GENERAL
	// ----------------------------------------------------------------------
	{
		role: [-1, 0, 1, 2],
		subheader: '',
		items: [
			{
				title: 'Accueil',
				path: '/dashboard/home',
				icon: <Home />,

				role: [0, 1, 2],
			},
			{
				title: 'Tableau de bord',
				path: '/dashboard/home',
				icon: <Dashboard />,

				role: [-1],
			},
		],
	},
	{
		role: [-1, 0, 1, 2],
		items: [
			{
				title: 'Gestion des missions',
				path: '/dashboard/all_missions',
				icon: <Badge />,
				role: [1],
			},
			{
				title: 'Missions',
				path: '/dashboard/missions',
				icon: <Badge />,
				role: [2],
			},
			{
				title: 'Gestion des candidatures',
				path: '/dashboard/applications',
				icon: <Assignment />,
				role: [1],
			},
			{
				title: 'Candidatures',
				path: '/dashboard/my_applications',
				icon: <Badge />,
				role: [2],
			},
			{
				title: 'Gestion des factures',
				path: '/dashboard/all_invoices',
				icon: <RequestQuote />,
				role: [1],
			},
			{
				title: 'Factures',
				path: '/dashboard/invoices',
				icon: <RequestQuote />,
				role: [2],
			},
			{
				title: 'Gestion des administrateurs',
				path: '/dashboard/admins',
				icon: <AdminPanelSettings />,
				role: [-1],
			},


			{
				title: 'Gestion des partenaires',
				path: '/dashboard/clients',
				icon: <AccountBox />,
				role: [0, -1],
			},
			{
				title: "Demandes d'annulation",
				path: '/dashboard/cancel_requests_pro',
				icon: <CancelScheduleSend />,
				role: [1],
			},
			{
				title: 'Profil',
				path: '/dashboard/profile',
				icon: <AccountBox />,
				role: [2],
			},
			{
				title: 'Profil',
				path: '/dashboard/profile_pro',
				icon: <AccountBox />,
				role: [1],
			},
			// {
			// 	title: 'Paiement',
			// 	path: '/dashboard/payment',
			// 	icon: <Payment />,
			// 	role: [1],
			// },

			{
				title: 'Gestion des collaborateurs',
				path: '/dashboard/candidats',
				icon: <AccountBoxOutlined />,
				role: [0, -1],
			},

			{
				title: 'Gestion des candidatures',
				path: '/dashboard/all_applications',
				icon: <Assignment />,
				role: [0, -1],
			},
			{
				title: 'Gestion des missions',
				path: '/dashboard/admin_missions',
				icon: <Assignment />,
				role: [0, -1],
			},
			{
				title: 'Gestion des factures',
				path: '/dashboard/admin_inovices',
				icon: <Assignment />,
				role: [0, -1],
			},
			{
				title: "Demandes d'annulation",
				path: '/dashboard/cancel_requests',
				icon: <CancelScheduleSend />,
				role: [0, -1],
			},

			{
				title: 'Configuration',
				path: '/dashboard/settings',
				icon: <Settings />,
				role: [-1],
			},
		],
	},
]

export default sidebarConfig
