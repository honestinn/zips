import { useState } from 'react'

import { Typography, Button, Link } from '@mui/material'

import MenuPopover from '../../../components/MenuPopover'

import { Info } from 'react-feather'
import RouterLink from 'src/hooks/RouterLink'
import { Forward } from '@mui/icons-material'

// ----------------------------------------------------------------------

const ITEM_HEIGHT = 64

// ----------------------------------------------------------------------

export default function InfoPopover() {
	const [open, setOpen] = useState(null)

	const handleOpen = event => {
		setOpen(event.currentTarget)
	}

	const handleClose = () => {
		setOpen(null)
	}

	return (
		<>
			<Button
				color={open ? 'primary' : 'error'}
				onClick={handleOpen}
				sx={{
					width: 40,
					height: 40,
				}}
			>
				<Info />
			</Button>

			<MenuPopover
				open={Boolean(open)}
				anchorEl={open}
				onClose={handleClose}
				sx={{
					mt: 1.5,
					ml: 0.75,
					width: 320,
				}}
			>
				<Typography variant="subtitle2" sx={{ p: 1.5 }}>
					Pour une meilleure expérience, veuillez compléter votre profil
				</Typography>
				<Link
					variant="button"
					color="text.primary"
					component={RouterLink}
					underline="none"
					href="/dashboard/profile"
					sx={{
						mx: 1.5,
						display: 'flex',
						alignItems: 'center',
					}}
				>
					<Button sx={{ ml: 2 }} variant="outlined" startIcon={<Forward />}>
						<Typography sx={{ mx: 2 }}>Mon profil</Typography>
					</Button>
				</Link>
			</MenuPopover>
		</>
	)
}
