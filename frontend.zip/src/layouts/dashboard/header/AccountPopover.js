import { useState } from 'react'
// @mui
import { alpha } from '@mui/material/styles'
import { Box, Divider, Typography, Stack, MenuItem, Avatar, Link } from '@mui/material'
// components
import MenuPopover from '../../../components/MenuPopover'
import { IconButtonAnimate } from '../../../components/animate'
import { logout } from '../../../actions/auth'
import { useDispatch, useSelector } from 'react-redux'
import { Settings } from 'react-feather'
import RouterLink from 'src/hooks/RouterLink'
import { AccountBox, Logout } from '@mui/icons-material'

// ----------------------------------------------------------------------

const MENU_OPTIONS = [
	{
		label: 'Home',
		linkTo: '/',
	},
	{
		label: 'Profile',
		linkTo: '/',
	},
	{
		label: 'Settings',
		linkTo: '/',
	},
]

// ----------------------------------------------------------------------

export default function AccountPopover() {
	const [open, setOpen] = useState(null)
	const dispatch = useDispatch()
	const auth = useSelector(state => state.auth)

	const handleOpen = event => {
		setOpen(event.currentTarget)
	}

	const handleClose = () => {
		setOpen(null)
	}

	return (
		<>
			<IconButtonAnimate onClick={handleOpen}>
				<Stack direction="row" spacing={1} alignItems="center">
					<Typography variant="subtitle2">{auth.user.name}</Typography>{' '}
					<Settings size={22} />
				</Stack>
			</IconButtonAnimate>

			<MenuPopover
				open={Boolean(open)}
				anchorEl={open}
				onClose={handleClose}
				sx={{
					p: 0,
					mt: 1.5,
					ml: 0.75,
					'& .MuiMenuItem-root': {
						typography: 'body2',
						borderRadius: 0.75,
					},
				}}
			>
				<Box sx={{ my: 1.5, px: 2.5 }}>
					<Typography variant="subtitle2" noWrap>
						{auth.user.name}
					</Typography>
					<Typography variant="body2" sx={{ color: 'text.secondary' }} noWrap>
						{auth.user.email}
					</Typography>
				</Box>
				<Divider sx={{ borderStyle: 'dashed' }} />
				{auth.user.role == 1 && (
					<MenuItem onClick={handleClose}>
						<Link
							color="text.primary"
							component={RouterLink}
							underline="none"
							href="/dashboard/profile_pro"
							onClick={() => {}}
						>
							<Stack spacing={1} direction="row">
								<AccountBox /> <Typography>Profil</Typography>
							</Stack>
						</Link>
					</MenuItem>
				)}
				{auth.user.role == 2 && (
					<MenuItem onClick={handleClose}>
						<Link
							color="text.primary"
							component={RouterLink}
							underline="none"
							href="/dashboard/account"
							onClick={() => {}}
						>
							<Stack spacing={1} direction="row">
								<AccountBox /> <Typography>Mon compte</Typography>
							</Stack>
						</Link>
					</MenuItem>
				)}

				<Divider sx={{ borderStyle: 'dashed' }} />
				<MenuItem
					onClick={() => {
						dispatch(logout())
					}}
					sx={{ m: 1 }}
				>
					<Stack spacing={1} direction="row">
						<Logout /> <Typography> Se déconnecter</Typography>
					</Stack>
				</MenuItem>
			</MenuPopover>
		</>
	)
}
