import PropTypes from 'prop-types'
// @mui
import { styled } from '@mui/material/styles'
import { Box, Stack, AppBar, Toolbar, Typography, Link, Badge, IconButton } from '@mui/material'
// hooks
import useOffSetTop from '../../../hooks/useOffSetTop'
import useResponsive from '../../../hooks/useResponsive'
// utils
import cssStyles from '../../../utils/cssStyles'
// config
import { HEADER, NAVBAR } from '../../../config'
// components
import Logo from '../../../components/Logo'
import Iconify from '../../../components/Iconify'
import { IconButtonAnimate } from '../../../components/animate'
//
import AccountPopover from './AccountPopover'
import { useSelector } from 'react-redux'
import RouterLink from 'src/hooks/RouterLink'
import { Archive, CreditCard, Home, Sliders, User, XCircle, Zap } from 'react-feather'
import { useLocation } from 'react-router'
import { useEffect, useState } from 'react'
import api from 'src/Api'
import { Assignment, CancelScheduleSend, Feedback } from '@mui/icons-material'
// import ContactsPopover from './ContactsPopover'
import InfoPopover from './InfoPopover'

// ----------------------------------------------------------------------

const RootStyle = styled(AppBar, {
	shouldForwardProp: prop =>
		prop !== 'isCollapse' && prop !== 'isOffset' && prop !== 'verticalLayout',
})(({ isCollapse, isOffset, verticalLayout, theme }) => ({
	...cssStyles(theme).bgBlur(),
	boxShadow: 'none',
	height: HEADER.MOBILE_HEIGHT,
	zIndex: theme.zIndex.appBar + 1,
	transition: theme.transitions.create(['width', 'height'], {
		duration: theme.transitions.duration.shorter,
	}),
	[theme.breakpoints.up('lg')]: {
		height: HEADER.DASHBOARD_DESKTOP_HEIGHT,
		width: `calc(100% - ${NAVBAR.DASHBOARD_WIDTH + 1}px)`,
		...(isCollapse && {
			width: `calc(100% - ${NAVBAR.DASHBOARD_COLLAPSE_WIDTH}px)`,
		}),
		...(isOffset && {
			height: HEADER.DASHBOARD_DESKTOP_OFFSET_HEIGHT,
		}),
		...(verticalLayout && {
			width: '100%',
			height: HEADER.DASHBOARD_DESKTOP_OFFSET_HEIGHT,
			backgroundColor: theme.palette.background.default,
		}),
	},
}))

// ----------------------------------------------------------------------

DashboardHeader.propTypes = {
	onOpenSidebar: PropTypes.func,
	isCollapse: PropTypes.bool,
	verticalLayout: PropTypes.bool,
}

export default function DashboardHeader({
	onOpenSidebar,
	isCollapse = false,
	verticalLayout = false,
}) {
	const isOffset = useOffSetTop(HEADER.DASHBOARD_DESKTOP_HEIGHT) && !verticalLayout
	const [requestsCount, setRequestCount] = useState(0)
	const [applicationsCount, setApplicationsCount] = useState(0)
	const [unverifiedSteps, setUnverifiedSteps] = useState([])
	const isDesktop = useResponsive('up', 'lg')
	const auth = useSelector(state => state.auth)
	const { pathname } = useLocation()
	const getCountsAdmin = () => {
		api.get('/admin/get_counts_admin')
			.then(res => {
				setRequestCount(res.data.cancel_requests_count)
				setApplicationsCount(res.data.new_applications_count)
			})
			.catch(err => {})
	}
	const getCountsPro = () => {
		api.get('/admin/get_counts_pro')
			.then(res => {
				setRequestCount(res.data.cancel_requests_count)
				setApplicationsCount(res.data.new_applications_count)
			})
			.catch(err => {})
	}
	const getUnverifiedSteps = () => {
		api.get('/users/get_unverified_steps')
			.then(res => {
				setUnverifiedSteps(res.data)
			})
			.catch(err => {})
	}

	useEffect(() => {
		if (auth.user.role == 2) {
			getUnverifiedSteps()
		}

		if (auth.user.role !== 2) {
			if (auth.user.role == 1) getCountsPro()
			else getCountsAdmin()
		}
	}, [])
	return (
		<RootStyle
			isCollapse={auth.user.role == 2 ? true : isCollapse}
			isOffset={isOffset}
			verticalLayout={verticalLayout}
		>
			<Toolbar
				sx={{
					minHeight: '100% !important',
					px: { lg: 5 },
					display: 'flex',
					alignItems: 'center',
				}}
			>
				{isDesktop && verticalLayout && (
					<Link component={RouterLink} href="/" variant="subtitle2">
						<Logo sx={{ mr: 2.5 }} />
					</Link>
				)}
				{!isDesktop && (
					<IconButtonAnimate
						onClick={onOpenSidebar}
						sx={{ mr: 1, color: 'text.primary' }}
					>
						<Iconify icon="eva:menu-2-fill" />
					</IconButtonAnimate>
				)}
				{/* <Searchbar />  */}
				{auth.user.role == 2 && <Logo sx={{ height: '100%' }} />}
				<Box sx={{ flexGrow: 1 }} />

				{auth.user.role == 2 && isDesktop && (
					<Stack direction={'row'} spacing={4} sx={{ mx: 5 }}>
						<Stack
							sx={
								pathname == '/dashboard/home' && {
									border: '2px solid black',
									p: 1,
									borderRadius: '5px',
								}
							}
							direction="row"
							spacing={1}
							alignItems="center"
						>
							<Home size={22} />
							<Link component={RouterLink} href="/dashboard/home" variant="subtitle2">
								Accueil
							</Link>
						</Stack>
						<Stack
							sx={
								pathname == '/dashboard/missions' && {
									border: '2px solid black',
									p: 1,
									borderRadius: '5px',
								}
							}
							direction="row"
							spacing={1}
							alignItems="center"
						>
							<Zap size={22} />
							<Link
								component={RouterLink}
								href="/dashboard/missions"
								variant="subtitle2"
							>
								Missions
							</Link>
						</Stack>
						<Stack
							sx={
								pathname == '/dashboard/my_applications' && {
									border: '2px solid black',
									p: 1,
									borderRadius: '5px',
								}
							}
							direction="row"
							spacing={1}
							alignItems="center"
						>
							<Archive size={22} />
							<Link
								component={RouterLink}
								href="/dashboard/my_applications"
								variant="subtitle2"
							>
								Candidatures
							</Link>
						</Stack>
						<Stack
							sx={
								pathname == '/dashboard/invoices' && {
									border: '2px solid black',
									p: 1,
									borderRadius: '5px',
								}
							}
							direction="row"
							spacing={1}
							alignItems="center"
						>
							<CreditCard size={22} />
							<Link
								component={RouterLink}
								href="/dashboard/invoices"
								variant="subtitle2"
							>
								Factures
							</Link>
						</Stack>
						<Stack
							sx={
								pathname == '/dashboard/profile' && {
									border: '2px solid black',
									p: 1,
									borderRadius: '5px',
								}
							}
							direction="row"
							spacing={1}
							alignItems="center"
						>
							<Sliders size={22} />
							<Link
								component={RouterLink}
								href="/dashboard/profile"
								variant="subtitle2"
							>
								Profil
							</Link>
						</Stack>
					</Stack>
				)}
				{auth.user.role == 2 && unverifiedSteps && unverifiedSteps.length > 0 && (
					<InfoPopover />
				)}
				<Stack direction="row" alignItems="center" spacing={{ xs: 0.5, sm: 1.5 }}>
					{/* <LanguagePopover /> */}
					{/* <NotificationsPopover /> */}
					{/* <ContactsPopover /> */}
					{auth.user.role !== 2 && (
						<Stack sx={{ mx: 1 }} direction="row" spacing={2}>
							<Link
								component={RouterLink}
								href={
									auth.user.role == 1
										? '/dashboard/cancel_requests_pro'
										: '/dashboard/cancel_requests'
								}
							>
								<IconButton>
									<Badge badgeContent={requestsCount} color="error">
										<CancelScheduleSend color="red" />
									</Badge>
								</IconButton>
							</Link>
							<Link
								component={RouterLink}
								href={
									auth.user.role == 1
										? '/dashboard/applications'
										: '/dashboard/all_applications'
								}
							>
								<IconButton>
									<Badge badgeContent={applicationsCount} color="error">
										<Assignment color="red" />
									</Badge>
								</IconButton>
							</Link>
						</Stack>
					)}

					{/* <IconButton>
						<Feedback />
					</IconButton> */}

					<AccountPopover />
				</Stack>
			</Toolbar>
		</RootStyle>
	)
}
