import {
	USER_LOADED,
	USER_LOADING,
	AUTH_ERROR,
	LOGIN_SUCCESS,
	LOGIN_FAIL,
	LOGOUT,
	REGISTER_SUCCESS,
} from '../actions/types'

const initialState = {
	token: localStorage.getItem('token'),
	refresh: localStorage.getItem('refresh'),
	isAuthenticated: false,
	isLoading: false,
	user: null,
}

const auth_switch = (state = initialState, action) => {
	switch (action.type) {
		case USER_LOADING:
			return {
				...state,
				isLoading: true,
			}
		case USER_LOADED:
			return {
				...state,
				isAuthenticated: true,
				isLoading: false,
				user: action.payload.user,
			}
		case LOGIN_SUCCESS:
			localStorage.setItem('token', action.payload.accessToken)
			localStorage.setItem('refresh', action.payload.refreshToken)
			localStorage.setItem('user', JSON.stringify(action.payload.user))

			return {
				...state,
				...action.payload,
				token: action.payload.accessToken,
				refresh: action.payload.refreshToken,
				isAuthenticated: true,
				isLoading: false,
			}
		case REGISTER_SUCCESS:
			localStorage.setItem('token', action.payload.accessToken)
			localStorage.setItem('refresh', action.payload.refreshToken)
			localStorage.setItem('user', JSON.stringify(action.payload.user))

			return {
				...state,
				...action.payload,
				token: action.payload.accessToken,
				refresh: action.payload.refreshToken,
				isAuthenticated: true,
				isLoading: false,
			}
		case AUTH_ERROR:
		case LOGIN_FAIL:
		case LOGOUT:
			localStorage.removeItem('token')
			localStorage.removeItem('refresh')
			localStorage.removeItem('user')
			return {
				...state,
				token: null,
				refresh: null,
				user: null,
				isAuthenticated: false,
				isLoading: false,
			}
		default:
			return state
	}
}

export default auth_switch
