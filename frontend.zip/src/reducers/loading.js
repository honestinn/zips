import { AUTH_SUBMIT } from '../actions/types';

const initialState = {
   auth_submitting:false
};

const loading=  (state = initialState, action) => {
    switch (action.type) {
        case AUTH_SUBMIT:
            return {
              ...state,
               auth_submitting:action.status,
            };
        default:
            return state;
    }
}

export default loading
    