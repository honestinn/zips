import { GET_ERRORS, CLEAR_ERRORS } from '../actions/types'

const initialState = {
	msg: '',
}

const auth_errors = (state = initialState, action) => {
	switch (action.type) {
		case GET_ERRORS:
			return {
				msg: action.payload,
			}
		case CLEAR_ERRORS:
			return {
				msg: action.payload,
			}
		default:
			return state
	}
}

export default auth_errors
