import axios from 'axios'

import {
	USER_LOADED,
	USER_LOADING,
	AUTH_ERROR,
	LOGIN_SUCCESS,
	LOGOUT,
	AUTH_SUBMIT,
	REGISTER_FAIL,
	REGISTER_SUCCESS,
} from './types'
import { returnError } from './errors'
import { APP_URL } from 'src/config'

// CHECK TOKEN & LOAD USER
export const loadUser = () => (dispatch, getState) => {
	dispatch({ type: USER_LOADING })
	const token = localStorage.getItem('token')
	const refresh = localStorage.getItem('refresh')
	if (
		localStorage.getItem('user') === 'undefined' ||
		localStorage.getItem('token') === 'undefined' ||
		localStorage.getItem('refresh') === 'undefined'
	) {
		dispatch({
			type: AUTH_ERROR,
		})
	} else {
		const user = JSON.parse(localStorage.getItem('user'))
		if (user != null && token != null && refresh != null)
			dispatch({
				type: USER_LOADED,
				payload: { user, token, refresh },
			})
		else
			dispatch({
				type: AUTH_ERROR,
			})
	}
}

async function getIp() {
	// Fetch the public IP address
	const response = await fetch("https://api.ipify.org?format=json");
	const data = await response.json(); // Ensure you're awaiting the response
	return data.ip; // Return the IP address
  }
  const ip = getIp();
  

// LOGIN USER
export const login = (email, password) => (dispatch, getState) => {
	// Headers
	const config = {
		headers: {
			'Content-Type': 'application/json',
		},
	}
	// Request Body
	const body = JSON.stringify({ email, password, ip})
	dispatch({
		type: AUTH_SUBMIT,
		status: true,
	})
	axios
		.post(APP_URL + '/api/users/login', body, config)
		.then(res => {
			dispatch({
				type: LOGIN_SUCCESS,
				payload: res.data,
			})
			dispatch({
				type: AUTH_SUBMIT,
				status: false,
			})
		})
		.catch(err => {
			console.log(err?.response?.data?.error)
			dispatch(returnError(err?.response?.data?.error))
			dispatch({
				type: AUTH_SUBMIT,
				status: false,
			})
		})
}

export const register = values => dispatch => {
	// Headers
	const config = {
		headers: {
			'Content-Type': 'application/json',
		},
	}
	dispatch({
		type: AUTH_SUBMIT,
		status: true,
	})

	// Request Body
	const body = JSON.stringify(values)

	axios
		.post(APP_URL + '/api/users/register', body, config)
		.then(res => {
			dispatch({
				type: REGISTER_SUCCESS,
				payload: res.data,
			})
			dispatch({
				type: AUTH_SUBMIT,
				status: false,
			})
		})
		.catch(err => {
			dispatch(returnError(err.response.data.error))
			dispatch({
				type: REGISTER_FAIL,
			})
			dispatch({
				type: AUTH_SUBMIT,
				status: false,
			})
		})
}

// LOGOUT USER
export const logout = () => (dispatch, getState) => {
	dispatch({
		type: LOGOUT,
	})
	dispatch(returnError(''))
}

export const tokenConfig = getState => {
	// Get token from state
	const token = getState().auth.token

	// Headers
	const config = {
		headers: {
			'Content-Type': 'application/json',
		},
	}

	// If token, add to headers config
	if (token) {
		config.headers.Authorization = `METACODE ${token}`
	}

	return config
}
