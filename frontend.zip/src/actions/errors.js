import { GET_ERRORS, CLEAR_ERRORS } from './types'

// CREATE MESSAGE
export const returnError = (msg, status) => {
	return {
		type: GET_ERRORS,
		payload: msg,
	}
}
export const clearErrors = (msg, status) => {
	return {
		type: CLEAR_ERRORS,
		payload: '',
	}
}
